import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      // O registro do service worker é feito à mão em src/main.jsx (pra
      // conferir atualização toda vez que o app volta pra tela e recarregar
      // sozinho quando sai versão nova), então o plugin não injeta o dele.
      injectRegister: false,
      workbox: {
        // Versão nova assume o controle na hora (sem esperar fechar todas as
        // abas/o app) e o cache das versões antigas é apagado.
        skipWaiting: true,
        clientsClaim: true,
        cleanupOutdatedCaches: true
      },
      includeAssets: ['icons/icon-192.png', 'icons/icon-512.png'],
      manifest: {
        name: 'Compras Studio',
        short_name: 'Compras',
        description: 'Lista de compras interna — Cachoeira & Damha',
        theme_color: '#15110C',
        background_color: '#F7F2E7',
        display: 'standalone',
        start_url: '/',
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' }
        ]
      }
    })
  ],
  server: {
    host: true
  }
})
