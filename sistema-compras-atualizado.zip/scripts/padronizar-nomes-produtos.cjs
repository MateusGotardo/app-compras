/**
 * Padroniza o campo "nome" de todos os documentos da coleção "catalogo":
 * deixa só a primeira letra maiúscula e o resto minúsculo.
 * Ex.: "AÇÚCAR 2KG"  -> "Açúcar 2kg"
 *      "papel toalha" -> "Papel toalha"
 *
 * Por padrão roda em modo DRY-RUN: só mostra no terminal o que MUDARIA,
 * sem escrever nada no banco. Só grava de verdade quando você passar
 * --aplicar.
 *
 * COMO USAR:
 *   1. No console do Firebase: Configurações do projeto > Contas de serviço
 *      > "Gerar nova chave privada". Isso baixa um arquivo .json.
 *   2. Coloque esse arquivo na pasta scripts/ com o nome
 *      "service-account.json" (ou aponte o caminho pela env var
 *      GOOGLE_APPLICATION_CREDENTIALS).
 *   3. Instale a dependência (uma vez só):
 *        npm install firebase-admin --no-save
 *   4. Rode primeiro sem aplicar, só pra conferir o que vai mudar:
 *        node scripts/padronizar-nomes-produtos.cjs
 *   5. Se estiver tudo certo, rode de verdade:
 *        node scripts/padronizar-nomes-produtos.cjs --aplicar
 *
 * O script NÃO mexe em "fornecedorPadrao", "categoria" nem em nenhum outro
 * campo — só no "nome" do produto. Documentos cujo nome já está no formato
 * certo são pulados (não geram escrita nem aparecem no log).
 */

const path = require('path')
const admin = require('firebase-admin')

const aplicar = process.argv.includes('--aplicar')

const credPath =
  process.env.GOOGLE_APPLICATION_CREDENTIALS || path.join(__dirname, 'service-account.json')

admin.initializeApp({
  credential: admin.credential.cert(require(credPath)),
})

const db = admin.firestore()

// Só a primeira letra maiúscula, resto minúsculo — sem mexer em cada
// palavra separadamente (não vira "Title Case", vira "Sentence case").
function padronizar(nome) {
  const limpo = (nome || '').trim()
  if (!limpo) return limpo
  return limpo.charAt(0).toUpperCase() + limpo.slice(1).toLowerCase()
}

async function main() {
  console.log(aplicar ? 'Modo: APLICANDO mudanças de verdade.' : 'Modo: DRY-RUN (nada será salvo).')

  const snap = await db.collection('catalogo').get()
  console.log(`Total de produtos no catálogo: ${snap.size}`)

  const mudancas = []
  snap.forEach((docSnap) => {
    const dados = docSnap.data()
    const nomeAtual = dados.nome || ''
    const nomeNovo = padronizar(nomeAtual)
    if (nomeNovo && nomeNovo !== nomeAtual) {
      mudancas.push({ id: docSnap.id, nomeAtual, nomeNovo })
    }
  })

  console.log(`Produtos que vão mudar: ${mudancas.length}`)
  mudancas.forEach((m) => console.log(`  "${m.nomeAtual}"  ->  "${m.nomeNovo}"`))

  if (!aplicar) {
    console.log('\nNenhuma mudança foi salva (dry-run). Rode com --aplicar pra gravar de verdade.')
    return
  }

  // Firestore só aceita até 500 operações por batch.
  const LOTE = 450
  for (let i = 0; i < mudancas.length; i += LOTE) {
    const fatia = mudancas.slice(i, i + LOTE)
    const batch = db.batch()
    fatia.forEach((m) => {
      batch.update(db.collection('catalogo').doc(m.id), { nome: m.nomeNovo })
    })
    await batch.commit()
    console.log(`Salvo lote ${i / LOTE + 1} (${fatia.length} produtos).`)
  }

  console.log('\nPronto! Nomes atualizados no catálogo.')
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error('Erro ao rodar o script:', e)
    process.exit(1)
  })
