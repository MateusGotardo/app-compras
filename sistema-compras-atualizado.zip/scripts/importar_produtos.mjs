// Importa produtos direto pro Firestore (coleção "catalogo"), sem passar
// pelo cadastro do app. Lê um CSV com as colunas: nome;categoria;
// fornecedorPadrao (as duas últimas colunas do arquivo de referência,
// confianca e estoque_atual, são ignoradas — servem só pra revisão sua).
//
// Cada linha do CSV vira DOIS documentos no catálogo (um por filial:
// Cachoeira e Damha), já que a lista não precisa ser separada por filial.
//
// Como rodar:
//   1. npm install firebase-admin csv-parse   (dentro da pasta do projeto)
//   2. Gere uma chave de serviço no Firebase:
//        Console > Configurações do projeto > Contas de serviço >
//        "Gerar nova chave privada" — baixa um .json
//      Salve esse arquivo como scripts/serviceAccountKey.json
//      (NÃO suba esse arquivo pro Git — ele dá acesso total ao banco)
//   3. Revise o arquivo produtos_para_revisar.csv (gerado à parte),
//      corrigindo a coluna "categoria" onde for "confianca: baixa" e
//      preenchendo "fornecedorPadrao" onde souber. Salve como
//      scripts/produtos_revisado.csv (separador ";").
//   4. node scripts/importar_produtos.mjs

import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { parse } from 'csv-parse/sync'
import admin from 'firebase-admin'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

const CAMINHO_CSV = path.join(__dirname, 'produtos_revisado.csv')
const CAMINHO_CHAVE = path.join(__dirname, 'serviceAccountKey.json')
const FILIAIS = ['Cachoeira', 'Damha']
const CATEGORIAS_VALIDAS = [
  'Copa',
  'Bistrô',
  'Limpeza',
  'Manicures',
  'Cabeleireiros',
  'Estética',
  'Escritório',
]

if (!fs.existsSync(CAMINHO_CHAVE)) {
  console.error(`Não achei ${CAMINHO_CHAVE}. Baixe a chave de serviço do Firebase e salve com esse nome.`)
  process.exit(1)
}
if (!fs.existsSync(CAMINHO_CSV)) {
  console.error(`Não achei ${CAMINHO_CSV}. Revise o CSV gerado e salve com esse nome nessa pasta.`)
  process.exit(1)
}

admin.initializeApp({
  credential: admin.credential.cert(JSON.parse(fs.readFileSync(CAMINHO_CHAVE, 'utf-8'))),
})
const db = admin.firestore()

const conteudo = fs.readFileSync(CAMINHO_CSV, 'utf-8')
const registros = parse(conteudo, { columns: true, delimiter: ';', bom: true, trim: true })

async function main() {
  // Evita duplicar se o script for rodado mais de uma vez: busca os itens já
  // existentes por filial (nome + categoria) antes de criar.
  const existentesPorFilial = {}
  for (const filial of FILIAIS) {
    const snap = await db.collection('catalogo').where('filial', '==', filial).get()
    existentesPorFilial[filial] = new Set(
      snap.docs.map((d) => `${d.data().nome?.trim().toLowerCase()}|${d.data().categoria}`)
    )
  }

  let criados = 0
  let pulados = 0
  let comCategoriaInvalida = 0
  let lote = db.batch()
  let contadorLote = 0

  for (const linha of registros) {
    const nome = (linha.nome || '').trim()
    const categoria = (linha.categoria || '').trim()
    const fornecedorPadrao = (linha.fornecedorPadrao || '').trim()

    if (!nome) continue
    if (!CATEGORIAS_VALIDAS.includes(categoria)) {
      console.warn(`Categoria inválida, pulando: "${nome}" -> "${categoria}"`)
      comCategoriaInvalida++
      continue
    }

    for (const filial of FILIAIS) {
      const chave = `${nome.toLowerCase()}|${categoria}`
      if (existentesPorFilial[filial].has(chave)) {
        pulados++
        continue
      }
      const ref = db.collection('catalogo').doc()
      lote.set(ref, { nome, categoria, fornecedorPadrao, filial })
      existentesPorFilial[filial].add(chave)
      criados++
      contadorLote++

      // Firestore só aceita até 500 operações por lote.
      if (contadorLote === 450) {
        await lote.commit()
        lote = db.batch()
        contadorLote = 0
      }
    }
  }

  if (contadorLote > 0) await lote.commit()

  console.log(`Criados: ${criados}`)
  console.log(`Já existiam (pulados): ${pulados}`)
  console.log(`Categoria inválida (pulados): ${comCategoriaInvalida}`)
}

main().catch((e) => {
  console.error(e)
  process.exit(1)
})
