/**
 * Preenche "unidadeNecessariaPadrao" = "UN" em todos os documentos da
 * coleção "catalogo" que ainda não têm essa unidade fixa de compra definida
 * (campo vazio/ausente). Não mexe em quem já tem uma unidade definida —
 * inclusive se já for "UN" explicitamente, esse produto é pulado (não gera
 * escrita nem aparece no log).
 *
 * Contexto: agora o cadastro/edição de item no Catálogo tem um campo
 * "Unidade de compra" (UN, CX, PCTE, FT) e, quando não é UN, um "Quantas
 * unidades tem 1 CX/PCTE/FT" — isso é o que deixa o Painel somar a
 * quantidade comprada no mês como um número só e confiável (antes, sem essa
 * unidade fixa, não dava pra converter "3 cx." em unidades sem adivinhar
 * quanto cabe em cada caixa). Produtos cadastrados antes disso existir não
 * têm o campo — esse script só resolve a parte de deixá-los como "UN"
 * (que já é o padrão que o app assume sozinho quando o campo está vazio);
 * "unidadesPorEmbalagem" continua em aberto pra quando o produto realmente
 * for comprado em CX/PCTE/FT — aí é só abrir o item no Catálogo e preencher
 * na hora, o Painel já passa a contar certo dali pra frente sem precisar
 * rodar nada de novo.
 *
 * Por padrão roda em modo DRY-RUN: só mostra no terminal o que MUDARIA,
 * sem escrever nada no banco. Só grava de verdade quando você passar
 * --aplicar.
 *
 * COMO USAR:
 *   1. No console do Firebase: Configurações do projeto > Contas de serviço
 *      > "Gerar nova chave privada". Isso baixa um arquivo .json.
 *   2. Coloque esse arquivo na pasta scripts/ com o nome
 *      "service-account.json" (ou aponte o caminho pela env var
 *      GOOGLE_APPLICATION_CREDENTIALS) — o mesmo arquivo já usado pelo
 *      script de padronizar nomes serve aqui também.
 *   3. Instale a dependência (uma vez só, se ainda não tiver):
 *        npm install firebase-admin --no-save
 *   4. Rode primeiro sem aplicar, só pra conferir o que vai mudar:
 *        node scripts/definir-unidade-padrao-produtos.cjs
 *   5. Se estiver tudo certo, rode de verdade:
 *        node scripts/definir-unidade-padrao-produtos.cjs --aplicar
 */

const path = require('path')
const admin = require('firebase-admin')

const aplicar = process.argv.includes('--aplicar')

const credPath =
  process.env.GOOGLE_APPLICATION_CREDENTIALS || path.join(__dirname, 'service-account.json')

admin.initializeApp({
  credential: admin.credential.cert(require(credPath)),
})

const db = admin.firestore()

async function main() {
  console.log(aplicar ? 'Modo: APLICANDO mudanças de verdade.' : 'Modo: DRY-RUN (nada será salvo).')

  const snap = await db.collection('catalogo').get()
  console.log(`Total de produtos no catálogo: ${snap.size}`)

  const semUnidade = []
  snap.forEach((docSnap) => {
    const dados = docSnap.data()
    if (!dados.unidadeNecessariaPadrao) {
      semUnidade.push({ id: docSnap.id, nome: dados.nome || '(sem nome)' })
    }
  })

  console.log(`Produtos sem unidade fixa definida (vão virar "UN"): ${semUnidade.length}`)
  semUnidade.forEach((p) => console.log(`  "${p.nome}"`))

  if (!aplicar) {
    console.log('\nNenhuma mudança foi salva (dry-run). Rode com --aplicar pra gravar de verdade.')
    return
  }

  // Firestore só aceita até 500 operações por batch.
  const LOTE = 450
  for (let i = 0; i < semUnidade.length; i += LOTE) {
    const fatia = semUnidade.slice(i, i + LOTE)
    const batch = db.batch()
    fatia.forEach((p) => {
      batch.update(db.collection('catalogo').doc(p.id), { unidadeNecessariaPadrao: 'UN' })
    })
    await batch.commit()
    console.log(`Salvo lote ${i / LOTE + 1} (${fatia.length} produtos).`)
  }

  console.log('\nPronto! Produtos sem unidade fixa agora estão como "UN".')
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error('Erro ao rodar o script:', e)
    process.exit(1)
  })
