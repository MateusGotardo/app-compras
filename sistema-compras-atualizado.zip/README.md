# Compras Studio — v2 (com Firebase)

Mesma ideia da v1, mas agora com dados de verdade na nuvem: você e seu chefe
veem a mesma lista, de qualquer lugar, em tempo real. Login virou e-mail e
senha reais.

## O que mudou da v1 pra cá

- Login real (e-mail/senha) via Firebase Authentication
- Catálogo e carrinho sincronizados em tempo real via Firestore (banco de
  dados na nuvem) — não é mais só o navegador de cada um
- Continua PWA, instalável no celular

## Passo 1 — Criar o projeto no Firebase (grátis)

1. Acesse **console.firebase.google.com** e entre com uma conta Google
2. "Criar projeto" → dê um nome (ex: `compras-studio`) → pode desativar o
   Google Analytics, não precisa
3. Dentro do projeto, clique no ícone **</>** ("Adicionar app" > Web) →
   registre um app (ex: `compras-studio-web`) → **não** marque Firebase
   Hosting agora
4. Ele vai te mostrar um bloco `firebaseConfig` com `apiKey`, `authDomain`
   etc. — guarde essa tela aberta, você vai usar no Passo 3

## Passo 2 — Ativar Authentication e Firestore

1. No menu lateral, vá em **Authentication** → "Vamos começar" → aba
   "Sign-in method" → ative **E-mail/senha**
2. Ainda em Authentication, aba **Users** → "Add user" → cadastre você e seu
   chefe (e qualquer convidado) com e-mail e senha
3. No menu lateral, vá em **Firestore Database** → "Criar banco de dados" →
   modo produção → escolha a região mais próxima (ex: `southamerica-east1`)
4. Depois de criado, vá na aba **Regras**, apague o conteúdo e cole o
   conteúdo do arquivo `firestore.rules` (está na raiz deste projeto) →
   Publicar

## Passo 3 — Dar papel (admin/convidado) pra cada usuário

Pra cada usuário criado no Passo 2, você precisa de um documento na coleção
`usuarios` com o **mesmo ID** do usuário no Authentication:

1. Em Authentication > Users, copie o **User UID** de cada pessoa
2. Em Firestore Database > Dados, crie uma coleção chamada `usuarios`
3. Para cada pessoa, crie um documento com o ID = o UID copiado, com os
   campos:
   - `nome` (string) — ex: `"Você"`, `"Chefe"`
   - `papel` (string) — `"admin"` ou `"convidado"`

## Passo 4 — Configurar o projeto no seu PC

1. Extraia este zip, ex: `C:\projetos\app-compras`
2. Copie o arquivo `.env.example` e renomeie a cópia para `.env`
3. Abra o `.env` e cole os valores do `firebaseConfig` do Passo 1 (sem
   aspas), ex:
   ```
   VITE_FIREBASE_API_KEY=AIzaSy...
   VITE_FIREBASE_AUTH_DOMAIN=compras-studio.firebaseapp.com
   VITE_FIREBASE_PROJECT_ID=compras-studio
   VITE_FIREBASE_STORAGE_BUCKET=compras-studio.appspot.com
   VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
   VITE_FIREBASE_APP_ID=1:123456789:web:abcabc
   ```
4. No terminal, dentro da pasta:
   ```
   npm install
   npm run dev
   ```
5. Abra o link (`http://localhost:5173`) e entre com o e-mail/senha que
   você cadastrou no Passo 2

## Passo 5 — Popular o catálogo

Na primeira vez, o catálogo de cada filial estará vazio. Entre como admin,
vá na aba **Catálogo** e cadastre os itens reais manualmente com
**"+ Cadastrar item novo"**. Quantidade em estoque, prioridade e
observações não fazem parte do cadastro do item — eles são informados na
hora de adicionar o item ao pedido (clicando no **+** da lista).

## Passo 6 — Publicar de verdade (pra usar de qualquer lugar)

Quando estiver validado, publique o frontend (grátis) em uma dessas opções:

- **Vercel** (vercel.com) — conecta numa pasta ou num repositório Git e
  publica sozinho a cada mudança
- **Netlify** (netlify.com) — mesma ideia

Em ambos, ao publicar, adicione as mesmas variáveis do seu `.env` nas
configurações de "Environment Variables" do projeto lá — sem isso o app
publicado não vai saber como falar com o Firebase.

Depois de publicado, você e seu chefe acessam o mesmo link de qualquer
lugar, no celular ou no PC, com os dados sempre sincronizados.

## Estrutura do projeto

```
src/
  firebase.js             → conexão com o Firebase (lê as chaves do .env)
  data/mockData.js         → status possíveis + dados de exemplo pra importar
  context/AppContext.jsx   → login, sincronização em tempo real, ações
  components/               → peças reutilizáveis
  pages/                     → Login, Lista, Catálogo, Fornecedor, Histórico
firestore.rules             → regras de segurança pra colar no console
```
