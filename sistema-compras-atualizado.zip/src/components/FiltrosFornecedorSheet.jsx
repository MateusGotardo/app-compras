import { useEffect, useRef } from 'react'

// Folha que sobe de baixo reunindo todos os filtros da Lista da semana
// (setor, status, data do pedido e "só urgentes") num lugar só — antes
// ficavam soltos, um bloco embaixo do outro, empurrando a lista de produtos
// pra baixo mesmo quando ninguém estava filtrando nada.
//
// Os filtros continuam valendo assim que são tocados (tudo local, na mesma
// lista já carregada em memória) — o botão "Aplicar filtros" só fecha a
// folha, não recarrega nada.
export default function FiltrosFornecedorSheet({
  aberto,
  onFechar,
  fornecedorNome,
  areasDisponiveis,
  areasFiltro,
  toggleArea,
  onLimparAreas,
  statusDisponiveis,
  statusFiltro,
  toggleStatus,
  onLimparStatus,
  datasDisponiveis,
  dataFiltro,
  setDataFiltro,
  qtdUrgentes,
  soUrgentes,
  setSoUrgentes,
  onLimparTudo,
}) {
  const aplicarBtnRef = useRef(null)

  // Foca o botão "Aplicar filtros" ao abrir, igual o modal de perfil faz com
  // a primeira opção — ajuda quem navega por teclado ou leitor de tela.
  useEffect(() => {
    if (aberto) aplicarBtnRef.current?.focus()
  }, [aberto])

  useEffect(() => {
    if (!aberto) return
    function aoTeclar(e) {
      if (e.key === 'Escape') onFechar()
    }
    document.addEventListener('keydown', aoTeclar)
    return () => document.removeEventListener('keydown', aoTeclar)
  }, [aberto, onFechar])

  if (!aberto) return null

  return (
    <div className="filtro-sheet-overlay" onClick={onFechar}>
      <div
        className="filtro-sheet"
        role="dialog"
        aria-modal="true"
        aria-labelledby="filtro-sheet-titulo"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="filtro-sheet-handle" aria-hidden="true" />

        <div className="filtro-sheet-header">
          <h2 id="filtro-sheet-titulo" className="filtro-sheet-titulo">
            Filtros — {fornecedorNome}
          </h2>
          <button type="button" className="btn-link filtro-sheet-limpar" onClick={onLimparTudo}>
            Limpar tudo
          </button>
        </div>

        <div className="filtro-sheet-body">
          {areasDisponiveis.length > 1 && (
            <div className="filtro-sheet-secao">
              <label>Setor</label>
              <div className="setor-chips">
                <button
                  type="button"
                  className={`chip ${areasFiltro.length === 0 ? 'active' : ''}`}
                  onClick={onLimparAreas}
                >
                  Todos
                </button>
                {areasDisponiveis.map((area) => (
                  <button
                    type="button"
                    key={area}
                    className={`chip ${areasFiltro.includes(area) ? 'active' : ''}`}
                    aria-pressed={areasFiltro.includes(area)}
                    onClick={() => toggleArea(area)}
                  >
                    {area}
                  </button>
                ))}
              </div>
            </div>
          )}

          {statusDisponiveis.length > 1 && (
            <div className="filtro-sheet-secao">
              <label>Status</label>
              <div className="setor-chips">
                <button
                  type="button"
                  className={`chip ${statusFiltro.length === 0 ? 'active' : ''}`}
                  onClick={onLimparStatus}
                >
                  Todos
                </button>
                {statusDisponiveis.map((status) => (
                  <button
                    type="button"
                    key={status}
                    className={`chip ${statusFiltro.includes(status) ? 'active' : ''}`}
                    aria-pressed={statusFiltro.includes(status)}
                    onClick={() => toggleStatus(status)}
                  >
                    {status}
                  </button>
                ))}
              </div>
            </div>
          )}

          {datasDisponiveis.length > 1 && (
            <div className="filtro-sheet-secao">
              <label htmlFor="filtro-sheet-data">Data do pedido</label>
              <select
                id="filtro-sheet-data"
                value={dataFiltro}
                onChange={(e) => setDataFiltro(e.target.value)}
              >
                <option value="Todas">Todas</option>
                {datasDisponiveis.map((data) => (
                  <option key={data} value={data}>
                    {new Date(`${data}T00:00:00`).toLocaleDateString('pt-BR')}
                  </option>
                ))}
              </select>
            </div>
          )}

          {qtdUrgentes > 0 && (
            <div className={`filtro-sheet-urgente ${soUrgentes ? 'active' : ''}`}>
              <span>
                <span aria-hidden="true">⚠ </span>
                Só urgentes ({qtdUrgentes})
              </span>
              <button
                type="button"
                role="switch"
                aria-checked={soUrgentes}
                aria-label="Mostrar só urgentes"
                className={`theme-switch theme-switch--urgente ${soUrgentes ? 'theme-switch--on' : ''}`}
                onClick={() => setSoUrgentes((v) => !v)}
              >
                <span className="theme-switch-knob" />
              </button>
            </div>
          )}
        </div>

        <button ref={aplicarBtnRef} type="button" className="btn btn-primary filtro-sheet-aplicar" onClick={onFechar}>
          Aplicar filtros
        </button>
      </div>
    </div>
  )
}
