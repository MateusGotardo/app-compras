import { STATUS, STATUS_COLORS } from '../data/mockData'
import { useApp } from '../context/AppContext'

// `compacto` (card fechado da tela Fornecedor): o status precisa caber na
// mesma linha das quantidades no celular. O <select> nativo não quebra
// texto, então aqui a pílula visível é um <span> (que pode quebrar em duas
// linhas, tipo "Aguardando / Gleison") e o <select> real fica por cima,
// transparente, só pra receber o toque e abrir a lista de status.
export default function StatusBadge({ carrinhoItem, editable, compacto = false }) {
  const { atualizarStatus } = useApp()
  const cor = STATUS_COLORS[carrinhoItem.status] ?? 'info'

  if (compacto) {
    return (
      <span className="status-pill-wrap">
        <span className={`status-pill status-pill--compacto ${cor}`}>{carrinhoItem.status}</span>
        {editable && (
          <select
            className="status-pill-select"
            aria-label="Alterar status"
            value={carrinhoItem.status}
            onChange={(e) => atualizarStatus(carrinhoItem.id, e.target.value)}
          >
            {Object.values(STATUS).map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        )}
      </span>
    )
  }

  if (!editable) {
    return <span className={`status-pill ${cor}`}>{carrinhoItem.status}</span>
  }

  return (
    <select
      className={`status-pill ${cor}`}
      value={carrinhoItem.status}
      onChange={(e) => atualizarStatus(carrinhoItem.id, e.target.value)}
    >
      {Object.values(STATUS).map((s) => (
        <option key={s} value={s}>
          {s}
        </option>
      ))}
    </select>
  )
}
