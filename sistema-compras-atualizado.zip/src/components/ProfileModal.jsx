import { useEffect, useRef } from 'react'
import { useApp } from '../context/AppContext'
import { useTheme } from '../context/ThemeContext'

export default function ProfileModal({ aberto, onFechar }) {
  const { usuarioAtual, isAdmin } = useApp()
  const { tema, alternarTema } = useTheme()
  const fecharBtnRef = useRef(null)

  useEffect(() => {
    if (aberto) fecharBtnRef.current?.focus()
  }, [aberto])

  useEffect(() => {
    if (!aberto) return
    function aoTeclar(e) {
      if (e.key === 'Escape') onFechar()
    }
    document.addEventListener('keydown', aoTeclar)
    return () => document.removeEventListener('keydown', aoTeclar)
  }, [aberto, onFechar])

  if (!aberto) return null

  const escuro = tema === 'escuro'

  return (
    <div className="confirm-overlay" onClick={onFechar}>
      <div
        className="confirm-dialog profile-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="profile-titulo"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="profile-header">
          <div className="profile-avatar">{iniciais(usuarioAtual?.nome)}</div>
          <div>
            <h2 id="profile-titulo" className="profile-nome">
              {usuarioAtual?.nome}
            </h2>
            <span className="badge">{isAdmin ? 'Admin' : 'Convidado'}</span>
          </div>
        </div>

        <div className="profile-option">
          <div>
            <p className="profile-option-titulo">Modo escuro</p>
            <p className="profile-option-desc">Fica como você deixar, não segue o sistema.</p>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={escuro}
            aria-label="Alternar modo escuro"
            className={`theme-switch ${escuro ? 'theme-switch--on' : ''}`}
            onClick={alternarTema}
          >
            <span className="theme-switch-knob" />
          </button>
        </div>

        <div className="confirm-acoes">
          <button ref={fecharBtnRef} className="btn btn-secondary" onClick={onFechar}>
            Fechar
          </button>
        </div>
      </div>
    </div>
  )
}

function iniciais(nome) {
  if (!nome) return '?'
  const partes = nome.trim().split(/\s+/)
  const primeiras = partes.length > 1 ? [partes[0], partes[partes.length - 1]] : [partes[0]]
  return primeiras.map((p) => p[0]?.toUpperCase()).join('')
}
