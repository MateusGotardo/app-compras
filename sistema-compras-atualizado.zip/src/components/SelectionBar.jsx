import { useState } from 'react'
import { STATUS } from '../data/mockData'

// Barra fixa que aparece quando há itens selecionados. Layout em linhas
// separadas (em vez de tudo espremido numa linha só) pra ficar claro no
// celular: 1) contagem + limpar seleção, 2) trocar status em lote,
// 3) excluir em lote — cada ação com espaço e rótulo próprio, sem depender
// só de ícone pra entender o que faz.
export default function SelectionBar({ count, onAplicarStatus, onExcluir, onLimpar }) {
  const [novoStatus, setNovoStatus] = useState(Object.values(STATUS)[0])

  return (
    <div className="selection-bar">
      <div className="selection-bar-header">
        <span className="selection-count">
          {count} {count === 1 ? 'selecionado' : 'selecionados'}
        </span>
        <button type="button" className="btn-link" onClick={onLimpar}>
          Limpar seleção
        </button>
      </div>

      <div className="selection-bar-status">
        <select
          className="selection-bar-select"
          value={novoStatus}
          onChange={(e) => setNovoStatus(e.target.value)}
        >
          {Object.values(STATUS).map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>

        <button
          type="button"
          className="btn btn-primary selection-bar-apply"
          onClick={() => onAplicarStatus(novoStatus)}
        >
          Aplicar status
        </button>
      </div>

      <button type="button" className="btn-danger-block" onClick={onExcluir}>
        🗑 Excluir selecionados
      </button>
    </div>
  )
}
