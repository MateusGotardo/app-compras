import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import ProfileModal from './ProfileModal'
import HistoricoModal from './HistoricoModal'

// Menu hambúrguer do admin: concentra num só ícone a navegação que antes
// vivia espalhada (toggle "Lista da semana"/"Fornecedores cadastrados" em
// cima da página de Fornecedores) mais o Sair — pensado pra sobrar mais
// espaço de tela no celular, que é o uso principal do app.
function MenuHamburguer() {
  const { logout } = useApp()
  const navigate = useNavigate()
  const [aberto, setAberto] = useState(false)

  function ir(destino) {
    setAberto(false)
    navigate(destino)
  }

  return (
    <div className="acoes-menu topbar-menu">
      <button
        type="button"
        className="icon-btn acoes-menu-btn"
        aria-haspopup="true"
        aria-expanded={aberto}
        aria-label="Menu"
        onClick={() => setAberto((v) => !v)}
        onBlur={() => setTimeout(() => setAberto(false), 150)}
      >
        ☰
      </button>
      {aberto && (
        <div className="acoes-menu-lista">
          <button
            type="button"
            className="acoes-menu-item"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => ir('/fornecedor')}
          >
            Lista da semana
          </button>
          <button
            type="button"
            className="acoes-menu-item"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => ir('/fornecedor?modo=gerenciar')}
          >
            Fornecedores cadastrados
          </button>
          <div className="acoes-menu-divisor" />
          <button
            type="button"
            className="acoes-menu-item acoes-menu-item--perigo"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => {
              setAberto(false)
              logout()
            }}
          >
            Sair
          </button>
        </div>
      )}
    </div>
  )
}

export default function TopBar() {
  const { filial, setFilial, filiais, usuarioAtual, logout, isAdmin } = useApp()
  const [perfilAberto, setPerfilAberto] = useState(false)
  const [historicoAberto, setHistoricoAberto] = useState(false)

  return (
    <div className="topbar">
      <div className="topbar-row">
        <p className="brand">Compras Studio</p>
        {isAdmin ? (
          <div className="filial-switch">
            {filiais.map((f) => (
              <button
                key={f}
                className={f === filial ? 'active' : ''}
                onClick={() => setFilial(f)}
              >
                {f}
              </button>
            ))}
          </div>
        ) : (
          // Convidado não troca de filial — fica travado na filial do
          // próprio perfil, só mostra o nome dela pra saber onde está.
          <span className="filial-fixa">{filial}</span>
        )}
      </div>
      <div className="user-chip">
        {isAdmin && <MenuHamburguer />}
        <button className="user-chip-nome" onClick={() => setPerfilAberto(true)}>
          {usuarioAtual?.nome}
        </button>
        <span className="badge">{isAdmin ? 'Admin' : 'Convidado'}</span>
        {!isAdmin && (
          <button className="historico-btn" onClick={() => setHistoricoAberto(true)}>
            <span aria-hidden="true">↺</span> Histórico
          </button>
        )}
        {!isAdmin && (
          <button className="logout-link" onClick={logout}>
            Sair
          </button>
        )}
      </div>
      <ProfileModal aberto={perfilAberto} onFechar={() => setPerfilAberto(false)} />
      {!isAdmin && <HistoricoModal aberto={historicoAberto} onFechar={() => setHistoricoAberto(false)} />}
    </div>
  )
}
