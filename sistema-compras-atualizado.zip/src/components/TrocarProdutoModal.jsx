import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { useConfirm } from '../context/ConfirmContext'
import { CATEGORIAS, STATUS_FINAIS } from '../data/mockData'

// Mesmo tratamento de acentos/maiúsculas usado na busca do Catálogo.
function normalizar(texto) {
  return (texto || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
}

// Troca o produto de um pedido que já está na lista — pro caso do
// fornecedor mandar outra coisa no lugar do que foi pedido (ex.: pediu
// Cif, veio Sampolino). Mantém quantidade, status e observações desse
// pedido; só muda pra qual produto do catálogo ele aponta.
export default function TrocarProdutoModal({ aberto, carrinhoItem, onFechar }) {
  const { catalogoDaFilial, filial, carrinho, trocarProdutoDoCarrinho } = useApp()
  const confirmar = useConfirm()
  const [busca, setBusca] = useState('')

  if (!aberto || !carrinhoItem) return null

  const catalogo = catalogoDaFilial().filter((i) => i.id !== carrinhoItem.itemId)
  const buscaAtiva = busca.trim().length > 0
  const itens = buscaAtiva
    ? catalogo.filter((i) => normalizar(i.nome).includes(normalizar(busca)))
    : catalogo

  const porCategoria = itens.reduce((acc, item) => {
    const cat = item.categoria || 'Sem categoria'
    acc[cat] = acc[cat] || []
    acc[cat].push(item)
    return acc
  }, {})
  Object.values(porCategoria).forEach((lista) => lista.sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR')))
  const categorias = CATEGORIAS.filter((cat) => porCategoria[cat])

  function fechar() {
    setBusca('')
    onFechar()
  }

  async function escolher(novoItem) {
    // Se o produto escolhido já tem outro pedido ativo nessa filial, avisa
    // antes — trocar mesmo assim deixa dois pedidos separados do mesmo
    // produto na lista, o que pode confundir na hora de comprar.
    const duplicado = carrinho.some(
      (c) =>
        c.id !== carrinhoItem.id &&
        c.itemId === novoItem.id &&
        c.filial === filial &&
        !STATUS_FINAIS.includes(c.status)
    )
    if (duplicado) {
      const ok = await confirmar(
        `Já existe um pedido ativo de "${novoItem.nome}" nessa lista. Trocar mesmo assim deixa dois pedidos separados desse produto — considere ajustar/remover o outro depois. Trocar assim mesmo?`,
        { titulo: 'Produto já pedido', textoConfirmar: 'Trocar assim mesmo' }
      )
      if (!ok) return
    }
    await trocarProdutoDoCarrinho(carrinhoItem.id, novoItem.id)
    fechar()
  }

  return (
    <div className="confirm-overlay" onClick={fechar}>
      <div
        className="confirm-dialog consumo-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="trocar-produto-titulo"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 id="trocar-produto-titulo" className="confirm-titulo">
          Trocar produto do pedido
        </h2>
        <p className="confirm-mensagem">
          Pedido atual: <strong>{carrinhoItem.item?.nome}</strong>. Escolha o produto que entrou no lugar —
          quantidade, status e observações desse pedido continuam os mesmos, só o produto muda.
        </p>

        <div className="search-box" style={{ marginBottom: 14 }}>
          <input
            placeholder="Buscar produto..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            autoFocus
          />
        </div>

        <div className="consumo-lista">
          {categorias.length === 0 && <p className="confirm-mensagem">Nenhum produto encontrado.</p>}
          {categorias.map((cat) => (
            <div key={cat}>
              <p className="category-heading">{cat}</p>
              {porCategoria[cat].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  className="catalog-row"
                  onClick={() => escolher(item)}
                >
                  <div className="catalog-row-info">
                    <p className="item-name">{item.nome}</p>
                  </div>
                </button>
              ))}
            </div>
          ))}
        </div>

        <div className="confirm-acoes">
          <button className="btn btn-secondary" onClick={fechar}>
            Cancelar
          </button>
        </div>
      </div>
    </div>
  )
}
