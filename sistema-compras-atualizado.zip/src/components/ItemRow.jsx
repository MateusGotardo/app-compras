import { useState } from 'react'
import StatusBadge from './StatusBadge'
import TrocarProdutoModal from './TrocarProdutoModal'
import { useApp } from '../context/AppContext'
import { useConfirm } from '../context/ConfirmContext'
import { normalizarUnidade, opcoesUnidade, separarNomeEMarca, ehAlertaEstoqueCritico, classeDoSetor, dataDaCompra } from '../data/mockData'
import { converterConsumo, formatarConsumo, sanitizarConsumoDigitado, unidadeDoConsumo } from '../utils/consumo'

export default function ItemRow({
  carrinhoItem,
  selecionavel = false,
  selecionado = false,
  onToggleSelecionado,
  onExcluir,
  // Card fechado mostra só o essencial (nome, estoque, qtd a comprar,
  // status); toca em "Detalhes" pra abrir consumo/fornecedor sem sair da
  // lista.
  // Só usado na tela Fornecedores, e só faz efeito pro admin (que é quem
  // vê esses campos) — na Lista ativa e para o convidado o card continua
  // como antes.
  compacto = false,
  // Card do Histórico: só o que interessa de uma compra já feita — quanto
  // foi comprado, onde (fornecedor) e quando. Sem estoque, consumo médio,
  // status nem detalhes.
  historico = false,
}) {
  const {
    isAdmin,
    fornecedoresDaFilial,
    editarItemCarrinho,
    atualizarItemCatalogo,
    alterarEstoqueAdmin,
    fixarUnidadeEstoque,
    definirFornecedorDoPedido,
    definirUnidadeNecessariaDoPedido,
  } = useApp()
  const confirmar = useConfirm()
  const item = carrinhoItem.item
  // Consumo médio mora no catálogo (é o mesmo valor editado no modal de
  // Consumo Médio, compartilhado entre todos os pedidos desse produto na
  // filial). Guardamos aqui só o "em digitação" pra não perder o cursor a
  // cada tecla — assim que sai do campo, salva e some.
  const [consumoDigitando, setConsumoDigitando] = useState(undefined)
  // Mesma lógica pro estoque: guarda o "em digitação" separado do valor
  // salvo, senão o cursor pula pro fim a cada tecla enquanto o admin edita
  // o número informado pelo funcionário.
  const [estoqueDigitando, setEstoqueDigitando] = useState(undefined)
  const [trocarProdutoAberto, setTrocarProdutoAberto] = useState(false)
  // Só existe no modo compacto (card fechado por padrão) — controla se a
  // seção de Estoque/Consumo médio/Fornecedor está visível.
  const [detalhesAbertos, setDetalhesAbertos] = useState(false)
  if (!item) return null

  const modoCompacto = compacto && isAdmin

  // Garante que o fornecedor atual do item apareça no select mesmo que não
  // seja mais um fornecedor padrão de nenhum item do catálogo.
  const opcoesFornecedor = Array.from(
    new Set([...fornecedoresDaFilial(), carrinhoItem.fornecedorUsado].filter(Boolean))
  ).sort()

  // Escolher o fornecedor na mão também define o fornecedor padrão do
  // produto no catálogo (vale pros próximos pedidos).
  function handleFornecedorChange(e) {
    definirFornecedorDoPedido(carrinhoItem.id, item.id, e.target.value)
  }

  function handleQtdChange(valor) {
    const numero = Math.max(0, Number(valor) || 0)
    editarItemCarrinho(carrinhoItem.id, { quantidadeNecessaria: numero })
  }

  // Unidade de medida da quantidade a comprar — igual à do estoque, mas em
  // campo separado (unidadeNecessaria): o que o funcionário tem em estoque
  // pode estar numa unidade e o que o admin decide comprar pode ser em
  // outra (ex.: estoque em "un.", compra fechada em "cx."). Além de mudar
  // este pedido, grava a unidade escolhida como padrão do produto — os
  // próximos pedidos dele já nascem nela (ver definirUnidadeNecessariaDoPedido).
  function handleUnidadeNecessariaChange(valor) {
    definirUnidadeNecessariaDoPedido(carrinhoItem.id, item.id, valor)
  }

  // Unidade de medida do estoque informado — hoje o convidado já escolhe
  // isso na hora de avisar o estoque (Catálogo); aqui dá pra admin corrigir
  // depois, direto na célula, sem precisar voltar lá (ex.: foi lançado como
  // "un." mas na real é "cx."). Diferente da troca de quantidade, essa troca
  // de unidade fixa a unidade padrão de estoque do produto (e a do consumo
  // médio junto — ver fixarUnidadeEstoque), então vale pros próximos pedidos.
  function handleUnidadeChange(valor) {
    fixarUnidadeEstoque(carrinhoItem.id, item.id, valor)
  }

  const estoqueExibido =
    estoqueDigitando !== undefined ? estoqueDigitando : carrinhoItem.quantidadeAtual ?? ''

  async function handleEstoqueBlur() {
    if (estoqueDigitando === undefined) return
    const bruto = estoqueDigitando
    setEstoqueDigitando(undefined)
    // Estoque é obrigatório: apagar o campo não limpa o valor salvo, ele
    // volta pro que estava (pra zerar, digite 0).
    if (bruto === '') return
    const valor = Math.max(0, Number(bruto) || 0)
    if (valor === (carrinhoItem.quantidadeAtual ?? null)) return
    await alterarEstoqueAdmin(carrinhoItem.id, { quantidadeAtual: valor, unidadeAtual: carrinhoItem.unidadeAtual })
  }

  const consumoExibido =
    consumoDigitando !== undefined ? consumoDigitando : formatarConsumo(item.consumoMedioSemanal)
  const consumoUnidade = unidadeDoConsumo(item)

  // Salva valor + unidade juntos: assim a unidade fica gravada de forma
  // explícita e o aprendizado automático sabe em que unidade a média está.
  async function handleConsumoBlur() {
    if (consumoDigitando === undefined) return
    const bruto = consumoDigitando
    setConsumoDigitando(undefined)
    const valor = converterConsumo(bruto)
    if (valor === (item.consumoMedioSemanal ?? null)) return
    await atualizarItemCatalogo(item.id, { consumoMedioSemanal: valor, consumoMedioUnidade: consumoUnidade })
  }

  async function handleConsumoUnidadeChange(valor) {
    await atualizarItemCatalogo(item.id, { consumoMedioUnidade: valor })
  }

  // Deixa de ser destacado como alerta assim que a compra já foi resolvida
  // (Em andamento/Comprado) — só falta chegar, não precisa mais chamar
  // atenção como estoque crítico.
  const urgente = ehAlertaEstoqueCritico(carrinhoItem)
  // Esmalte de exposição é salvo no catálogo como "Esmalte {marca} - {nome}"
  // (nomeProdutoEsmalte, em mockData.js). Exibir essa string inteira como
  // nome do produto misturava marca e nome num texto só, sem destaque nenhum
  // pra marca — separamos aqui pra mostrar a marca como tag (igual à de
  // categoria) e deixar só o nome do esmalte na linha do nome do produto.
  const infoEsmalte = separarNomeEMarca(item.nome)
  const nomeExibido = infoEsmalte ? infoEsmalte.nome : item.nome
  // Usa criadoEm (fixado na criação do pedido) e só cai pra atualizadoEm
  // em itens antigos que não têm esse campo — assim a data exibida não
  // muda mais quando o status do pedido é alterado.
  const dataBaseExibida = carrinhoItem.criadoEm ?? carrinhoItem.atualizadoEm
  const dataPedidoFormatada = dataBaseExibida
    ? new Date(`${dataBaseExibida}T00:00:00`).toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
      })
    : null

  // Tags do cabeçalho (categoria, marca do esmalte, data do pedido) — sempre
  // visíveis, mesmo no card fechado do modo compacto. A data fica aqui, ao
  // lado das outras tags, em vez de escondida dentro de "Detalhes".
  const tagsCabecalho = (
    <>
      {item.categoria && <span className="item-categoria-tag">{item.categoria}</span>}
      {infoEsmalte && <span className="item-marca-tag">{infoEsmalte.marca}</span>}
      {item.foraDeLinha && <span className="item-fora-linha-tag">Fora de linha</span>}
      {dataPedidoFormatada && (
        <span className="item-data-pedido" title="Data em que este produto foi pedido">
          Pedido em {dataPedidoFormatada}
        </span>
      )}
    </>
  )

  const nomeProduto = <p className="item-name item-name--full">{nomeExibido}</p>

  // Fica sempre ao lado da lixeira (mesmo grupo de ações do card), não mais
  // colado no nome do produto.
  const botaoTrocar = isAdmin && (
    <button
      type="button"
      className="icon-btn item-acao-btn"
      title="Trocar o produto deste pedido"
      aria-label="Trocar o produto deste pedido"
      onClick={() => setTrocarProdutoAberto(true)}
    >
      🔁
    </button>
  )

  // Cor do setor (categoria): pinta só a tag do setor no topo do card —
  // ver classes `setor-*` em index.css.
  const classeSetor = classeDoSetor(item.categoria)

  if (historico) {
    const dataCompra = dataDaCompra(carrinhoItem)
    const dataCompraFormatada = dataCompra
      ? new Date(`${dataCompra}T00:00:00`).toLocaleDateString('pt-BR', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
        })
      : 'Sem data'
    const qtd = carrinhoItem.quantidadeNecessaria
    const qtdTexto = qtd ? `${qtd} ${normalizarUnidade(carrinhoItem.unidadeNecessaria).toLowerCase()}.` : '—'

    return (
      <div className={`item-row item-row--compacto item-row--historico ${classeSetor}`}>
        {selecionavel && (
          <input
            type="checkbox"
            className="item-checkbox"
            checked={selecionado}
            onChange={() => onToggleSelecionado?.(carrinhoItem.id)}
          />
        )}
        <div className="item-main">
          <div className="item-cabecalho">
            {item.categoria && <span className="item-categoria-tag">{item.categoria}</span>}
            {infoEsmalte && <span className="item-marca-tag">{infoEsmalte.marca}</span>}
            {nomeProduto}
          </div>

          <div className="historico-info">
            <span className="historico-info-campo">
              <label>Comprado</label>
              <strong>{qtdTexto}</strong>
            </span>
            <span className="historico-info-campo">
              <label>Onde</label>
              <strong>{carrinhoItem.fornecedorUsado || 'Sem fornecedor'}</strong>
            </span>
            <span className="historico-info-campo">
              <label>Quando</label>
              <strong>{dataCompraFormatada}</strong>
            </span>
          </div>
        </div>

        {isAdmin && onExcluir && (
          <div className="item-right">
            <button
              className="icon-btn danger item-acao-btn"
              title="Remover este item"
              aria-label="Remover este item"
              onClick={async () => {
                if (await confirmar(`Remover "${item.nome}" do histórico?`)) onExcluir(carrinhoItem.id)
              }}
            >
              🗑
            </button>
          </div>
        )}
      </div>
    )
  }

  if (modoCompacto) {
    return (
      <div
        className={`item-row item-row--compacto ${classeSetor} ${urgente ? 'item-row--urgente' : ''} ${
          detalhesAbertos ? 'item-row--detalhes-aberto' : ''
        }`}
      >
        {selecionavel && (
          <input
            type="checkbox"
            className="item-checkbox"
            checked={selecionado}
            onChange={() => onToggleSelecionado?.(carrinhoItem.id)}
          />
        )}
        <div className="item-main">
          {/* Só o cabeçalho reserva espaço pros botões (trocar + lixeira) no
              canto; a linha de quantidades/status abaixo usa a largura toda. */}
          <div className="item-cabecalho">
            {tagsCabecalho}
            {nomeProduto}
          </div>

          {/* Card fechado: só o essencial — qtd a comprar e status. Unidade
              e status ficam agrupados num bloco à parte (unidade-status-group)
              que não se separa ao quebrar linha no celular — se não couber
              tudo numa linha só, esse bloco inteiro desce junto pra linha de
              baixo, com o status sempre colado na unidade, nunca sozinho e
              longe dela. */}
          <div className="item-resumo-row">
            <span className="item-qtd-field">
              <label>Estoque</label>
              <span className="qty-edit">
                <input
                  className="estoque-input"
                  type="number"
                  inputMode="decimal"
                  min="0"
                  placeholder="—"
                  value={estoqueExibido}
                  onChange={(e) => setEstoqueDigitando(e.target.value)}
                  onBlur={handleEstoqueBlur}
                />
                <select
                  className="unidade-select"
                  value={normalizarUnidade(carrinhoItem.unidadeAtual)}
                  onChange={(e) => handleUnidadeChange(e.target.value)}
                  title="Alterar unidade de medida"
                >
                  {opcoesUnidade(carrinhoItem.unidadeAtual).map((u) => (
                    <option key={u.value} value={u.value}>
                      {u.label}
                    </option>
                  ))}
                </select>
              </span>
            </span>

            <span className="item-qtd-field">
              <label>Qtd Cmp</label>
              <span className="qty-edit qty-edit--destaque">
                <input
                  type="number"
                  inputMode="decimal"
                  min="0"
                  placeholder="—"
                  value={carrinhoItem.quantidadeNecessaria || ''}
                  onChange={(e) => handleQtdChange(e.target.value)}
                />
                <select
                  className="unidade-select"
                  value={normalizarUnidade(carrinhoItem.unidadeNecessaria)}
                  onChange={(e) => handleUnidadeNecessariaChange(e.target.value)}
                  title="Alterar unidade de medida"
                >
                  {opcoesUnidade(carrinhoItem.unidadeNecessaria).map((u) => (
                    <option key={u.value} value={u.value}>
                      {u.label}
                    </option>
                  ))}
                </select>
              </span>
            </span>

            <StatusBadge carrinhoItem={carrinhoItem} editable={isAdmin} compacto />
          </div>

          <button
            type="button"
            className="detalhes-toggle"
            aria-expanded={detalhesAbertos}
            onClick={() => setDetalhesAbertos((v) => !v)}
          >
            <span className="detalhes-toggle-icon" aria-hidden="true">
              {detalhesAbertos ? '▾' : '▸'}
            </span>
            Detalhes
          </button>

          {detalhesAbertos && (
            <div className="item-detalhes">
              <div className="item-detalhe-row">
                <label>Consumo médio</label>
                <span className="qty-edit">
                  <input
                    className="consumo-medio-input"
                    type="text"
                    inputMode="decimal"
                    placeholder="—"
                    value={consumoExibido}
                    onChange={(e) => setConsumoDigitando(sanitizarConsumoDigitado(e.target.value))}
                    onBlur={handleConsumoBlur}
                  />
                  <select
                    className="unidade-select unidade-select--curto"
                    value={consumoUnidade}
                    onChange={(e) => handleConsumoUnidadeChange(e.target.value)}
                    title="Unidade do consumo médio (por semana)"
                  >
                    {opcoesUnidade(consumoUnidade).map((u) => (
                      <option key={u.value} value={u.value}>
                        {u.value}
                      </option>
                    ))}
                  </select>
                </span>
              </div>

              <div className="item-detalhe-row">
                <label>Fornecedor</label>
                <select value={carrinhoItem.fornecedorUsado || ''} onChange={handleFornecedorChange}>
                  <option value="">Sem fornecedor</option>
                  {opcoesFornecedor.map((f) => (
                    <option key={f} value={f}>
                      {f}
                    </option>
                  ))}
                </select>
              </div>

              {carrinhoItem.observacoes && (
                <div className="item-detalhe-row">
                  <label>Obs</label>
                  <span className="item-obs-box">{carrinhoItem.observacoes}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {(botaoTrocar || onExcluir) && (
          <div className="item-right">
            {botaoTrocar}
            {onExcluir && (
              <button
                className="icon-btn danger item-acao-btn"
                title="Remover este item"
                aria-label="Remover este item"
                onClick={async () => {
                  if (await confirmar(`Remover "${item.nome}" desta lista?`)) onExcluir(carrinhoItem.id)
                }}
              >
                🗑
              </button>
            )}
          </div>
        )}

        <TrocarProdutoModal
          aberto={trocarProdutoAberto}
          carrinhoItem={carrinhoItem}
          onFechar={() => setTrocarProdutoAberto(false)}
        />
      </div>
    )
  }

  return (
    <div className={`item-row ${classeSetor} ${urgente ? 'item-row--urgente' : ''}`}>
      {selecionavel && (
        <input
          type="checkbox"
          className="item-checkbox"
          checked={selecionado}
          onChange={() => onToggleSelecionado?.(carrinhoItem.id)}
        />
      )}
      <div className="item-main">
        {tagsCabecalho}
        {nomeProduto}

        <div className="item-fields-row">
          <span className="item-qtd-field">
            <label>Estq</label>
            {isAdmin ? (
              <span className="qty-edit">
                <input
                  className="estoque-input"
                  type="number"
                  inputMode="decimal"
                  min="0"
                  placeholder="—"
                  value={estoqueExibido}
                  onChange={(e) => setEstoqueDigitando(e.target.value)}
                  onBlur={handleEstoqueBlur}
                />
                <select
                  className="unidade-select"
                  value={normalizarUnidade(carrinhoItem.unidadeAtual)}
                  onChange={(e) => handleUnidadeChange(e.target.value)}
                  title="Alterar unidade de medida"
                >
                  {opcoesUnidade(carrinhoItem.unidadeAtual).map((u) => (
                    <option key={u.value} value={u.value}>
                      {u.label}
                    </option>
                  ))}
                </select>
              </span>
            ) : (
              <span className="qty-destaque qty-destaque--neutro">
                {carrinhoItem.quantidadeAtual ?? '—'} {normalizarUnidade(carrinhoItem.unidadeAtual).toLowerCase()}.
              </span>
            )}
          </span>

          <span className="item-qtd-field">
            <label>Cns méd</label>
            {isAdmin ? (
              <span className="qty-edit">
                <input
                  className="consumo-medio-input"
                  type="text"
                  inputMode="decimal"
                  placeholder="—"
                  value={consumoExibido}
                  onChange={(e) => setConsumoDigitando(sanitizarConsumoDigitado(e.target.value))}
                  onBlur={handleConsumoBlur}
                />
                <select
                  className="unidade-select unidade-select--curto"
                  value={consumoUnidade}
                  onChange={(e) => handleConsumoUnidadeChange(e.target.value)}
                  title="Unidade do consumo médio (por semana)"
                >
                  {opcoesUnidade(consumoUnidade).map((u) => (
                    <option key={u.value} value={u.value}>
                      {u.value}
                    </option>
                  ))}
                </select>
              </span>
            ) : (
              <span className="qty-destaque qty-destaque--neutro">
                {item.consumoMedioSemanal == null
                  ? '—'
                  : `${formatarConsumo(item.consumoMedioSemanal)} ${consumoUnidade.toLowerCase()}.`}
              </span>
            )}
          </span>

          {carrinhoItem.observacoes && (
            <span className="item-obs-field">
              <label>Obs</label>
              <span className="item-obs-box">{carrinhoItem.observacoes}</span>
            </span>
          )}
        </div>

        <div className="item-edit-row">
          {isAdmin ? (
            <select value={carrinhoItem.fornecedorUsado || ''} onChange={handleFornecedorChange}>
              <option value="">Sem fornecedor</option>
              {opcoesFornecedor.map((f) => (
                <option key={f} value={f}>
                  {f}
                </option>
              ))}
            </select>
          ) : (
            <span className="item-meta">{carrinhoItem.fornecedorUsado || 'Sem fornecedor'}</span>
          )}
          <StatusBadge carrinhoItem={carrinhoItem} editable={isAdmin} />
        </div>
      </div>
      <div className="item-right">
        <span className="item-qtd-field">
          <label>Qtd Cmp</label>
          {isAdmin ? (
            <span className="qty-edit qty-edit--destaque">
              <input
                type="number"
                inputMode="decimal"
                min="0"
                placeholder="—"
                value={carrinhoItem.quantidadeNecessaria || ''}
                onChange={(e) => handleQtdChange(e.target.value)}
              />
              <select
                className="unidade-select"
                value={normalizarUnidade(carrinhoItem.unidadeNecessaria)}
                onChange={(e) => handleUnidadeNecessariaChange(e.target.value)}
                title="Alterar unidade de medida"
              >
                {opcoesUnidade(carrinhoItem.unidadeNecessaria).map((u) => (
                  <option key={u.value} value={u.value}>
                    {u.label}
                  </option>
                ))}
              </select>
            </span>
          ) : (
            <span className="qty-destaque">
              {carrinhoItem.quantidadeNecessaria} {normalizarUnidade(carrinhoItem.unidadeNecessaria).toLowerCase()}.
            </span>
          )}
        </span>

        {isAdmin && (botaoTrocar || onExcluir) && (
          <span className="item-acoes">
            {botaoTrocar}
            {onExcluir && (
              <button
                className="icon-btn danger item-acao-btn"
                title="Remover este item"
                aria-label="Remover este item"
                onClick={async () => {
                  if (await confirmar(`Remover "${item.nome}" desta lista?`)) onExcluir(carrinhoItem.id)
                }}
              >
                🗑
              </button>
            )}
          </span>
        )}
      </div>

      <TrocarProdutoModal
        aberto={trocarProdutoAberto}
        carrinhoItem={carrinhoItem}
        onFechar={() => setTrocarProdutoAberto(false)}
      />
    </div>
  )
}
