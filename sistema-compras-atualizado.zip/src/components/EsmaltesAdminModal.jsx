import jsPDF from 'jspdf'
import { useApp } from '../context/AppContext'
import { MARCAS_ESMALTE } from '../data/mockData'

// Agrupa os itens salvos por marca, seguindo a ordem fixa de MARCAS_ESMALTE
// (e jogando qualquer marca fora da lista fixa — não deveria acontecer, já
// que o select só oferece essas — no final, como "Outra marca").
function agruparPorMarca(itens) {
  const porMarca = itens.reduce((acc, it) => {
    const marca = it.marca || 'Outra marca'
    acc[marca] = acc[marca] || []
    acc[marca].push(it)
    return acc
  }, {})
  // Ordem alfabética por nome dentro de cada marca, mesmo critério usado no
  // resto do programa (Catálogo, Lista ativa, Histórico, Fornecedores...).
  Object.values(porMarca).forEach((lista) => lista.sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR')))
  const ordem = [...MARCAS_ESMALTE, 'Outra marca'].filter((m) => porMarca[m])
  return ordem.map((marca) => [marca, porMarca[marca]])
}

export default function EsmaltesAdminModal({ aberto, onFechar }) {
  const { filial, esmaltesDaFilial } = useApp()

  if (!aberto) return null

  const doc = esmaltesDaFilial()
  const itens = doc?.itens ?? []
  const grupos = agruparPorMarca(itens)

  function novoPDF(titulo) {
    const pdf = new jsPDF()
    pdf.setFont('helvetica', 'bold')
    pdf.setFontSize(16)
    pdf.text(titulo, 14, 18)
    pdf.setFont('helvetica', 'normal')
    pdf.setFontSize(10)
    pdf.text(`Filial: ${filial} · Data: ${new Date().toLocaleDateString('pt-BR')}`, 14, 26)
    return pdf
  }

  // Escreve a lista de um grupo de esmaltes (uma marca) a partir de y=34,
  // devolvendo o pdf pronto pra salvar.
  function preencherLista(pdf, listaItens) {
    let y = 40
    pdf.setFont('helvetica', 'normal')
    pdf.setFontSize(11)
    listaItens.forEach((it, i) => {
      if (y > 280) {
        pdf.addPage()
        y = 20
      }
      pdf.text(`${i + 1}. ${it.nome}`, 14, y)
      y += 8
    })
    return pdf
  }

  function exportarInteiro() {
    const pdf = novoPDF(`Esmaltes de exposição — ${filial}`)
    let y = 34
    pdf.setFont('helvetica', 'normal')
    pdf.setFontSize(11)
    grupos.forEach(([marca, listaItens]) => {
      if (y > 270) {
        pdf.addPage()
        y = 20
      }
      pdf.setFont('helvetica', 'bold')
      pdf.text(marca, 14, y)
      y += 7
      pdf.setFont('helvetica', 'normal')
      listaItens.forEach((it) => {
        if (y > 280) {
          pdf.addPage()
          y = 20
        }
        pdf.text(`• ${it.nome}`, 18, y)
        y += 6
      })
      y += 4
    })
    pdf.save(`esmaltes-exposicao-${filial}.pdf`)
  }

  function exportarPorMarca() {
    grupos.forEach(([marca, listaItens]) => {
      const pdf = novoPDF(`Esmaltes de exposição — ${marca}`)
      preencherLista(pdf, listaItens)
      pdf.save(`esmaltes-${marca}-${filial}.pdf`)
    })
  }

  return (
    <div className="confirm-overlay" onClick={onFechar}>
      <div
        className="confirm-dialog consumo-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="esmaltes-admin-titulo"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 id="esmaltes-admin-titulo" className="confirm-titulo">
          Esmaltes de exposição — {filial}
        </h2>
        {doc ? (
          <p className="confirm-mensagem">
            Última atualização em {formatarData(doc.atualizadoEm)}, por {doc.atualizadoPor || '—'}.
          </p>
        ) : (
          <p className="confirm-mensagem">Ninguém enviou essa lista ainda pra esta filial.</p>
        )}

        <div className="consumo-lista">
          {grupos.length === 0 && (
            <div className="empty-state">
              <h3>Nada cadastrado ainda</h3>
            </div>
          )}
          {grupos.map(([marca, listaItens]) => (
            <div key={marca}>
              <p className="category-heading">
                {marca} <span className="fornecedor-group-count">({listaItens.length})</span>
              </p>
              {listaItens.map((it, i) => (
                <div className="consumo-row" key={`${marca}-${i}`}>
                  <p className="item-name" style={{ margin: 0 }}>
                    {it.nome}
                  </p>
                </div>
              ))}
            </div>
          ))}
        </div>

        {itens.length > 0 && (
          <div className="inline-edit-actions" style={{ marginBottom: 14 }}>
            <button className="btn btn-secondary" onClick={exportarPorMarca}>
              PDF por marca
            </button>
            <button className="btn btn-primary" onClick={exportarInteiro}>
              PDF lista inteira
            </button>
          </div>
        )}

        <div className="confirm-acoes">
          <button className="btn btn-secondary" onClick={onFechar}>
            Fechar
          </button>
        </div>
      </div>
    </div>
  )
}

function formatarData(dataISO) {
  if (!dataISO) return '—'
  const [ano, mes, dia] = dataISO.split('-')
  return `${dia}/${mes}/${ano}`
}
