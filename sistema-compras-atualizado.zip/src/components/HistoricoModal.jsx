import { useEffect, useRef, useState } from 'react'
import { useApp } from '../context/AppContext'
import { STATUS, normalizar } from '../data/mockData'
import ItemRow from './ItemRow'

// Modal só de leitura pro convidado conferir o que o SETOR dele (a própria
// categoria/área, ex.: Manicures) já mandou pro admin e ainda está em
// andamento — aguardando aprovação, em andamento com o fornecedor ou sem
// estoque no fornecedor (não tinha). Não mostra o que outros setores da
// mesma filial pediram, nem o que já foi resolvido (comprado/recebido/etc.).
// Reaproveita o ItemRow, que já esconde qualquer controle de edição/exclusão
// quando quem está logado não é admin.
export default function HistoricoModal({ aberto, onFechar }) {
  const { listaAtiva, filial, categoriasPermitidas } = useApp()
  const fecharBtnRef = useRef(null)
  const [busca, setBusca] = useState('')

  useEffect(() => {
    if (aberto) fecharBtnRef.current?.focus()
  }, [aberto])

  // Limpa a busca toda vez que o modal reabre, pra não deixar filtro velho
  // escondendo pedido sem o convidado perceber.
  useEffect(() => {
    if (aberto) setBusca('')
  }, [aberto])

  useEffect(() => {
    if (!aberto) return
    function aoTeclar(e) {
      if (e.key === 'Escape') onFechar()
    }
    document.addEventListener('keydown', aoTeclar)
    return () => document.removeEventListener('keydown', aoTeclar)
  }, [aberto, onFechar])

  if (!aberto) return null

  const STATUS_VISIVEIS_CONVIDADO = [STATUS.AGUARDANDO_GLEISON, STATUS.EM_ANDAMENTO, STATUS.NAO_TINHA]
  const buscaAtiva = busca.trim().length > 0

  const pendentes = listaAtiva().filter(
    (c) =>
      STATUS_VISIVEIS_CONVIDADO.includes(c.status) &&
      categoriasPermitidas.includes(c.item?.categoria) &&
      (!buscaAtiva || normalizar(c.item?.nome ?? '').includes(normalizar(busca)))
  )

  const porCategoria = pendentes.reduce((acc, c) => {
    const cat = c.item?.categoria ?? 'Outros'
    acc[cat] = acc[cat] || []
    acc[cat].push(c)
    return acc
  }, {})
  // Ordem alfabética por nome do produto dentro de cada área, mesmo
  // critério usado no resto do programa.
  Object.values(porCategoria).forEach((lista) =>
    lista.sort((a, b) => (a.item?.nome ?? '').localeCompare(b.item?.nome ?? '', 'pt-BR'))
  )
  const grupos = Object.keys(porCategoria).map((cat) => [cat, porCategoria[cat]])

  return (
    <div className="confirm-overlay" onClick={onFechar}>
      <div
        className="confirm-dialog consumo-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="historico-titulo"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 id="historico-titulo" className="confirm-titulo">
          Histórico — {filial}
        </h2>
        <p className="confirm-mensagem">
          Pedidos do seu setor que ainda estão em andamento (aguardando aprovação, em andamento com o fornecedor ou
          sem estoque no fornecedor). Só pra conferir — aqui não dá pra editar nem apagar nada.
        </p>

        <div className="search-box" style={{ marginBottom: 10 }}>
          <input
            placeholder="Buscar produto no seu setor..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
          />
        </div>

        <div className="consumo-lista">
          {grupos.length === 0 && (
            <div className="empty-state">
              <h3>{buscaAtiva ? 'Nada encontrado' : 'Nada aguardando aprovação'}</h3>
              {buscaAtiva && <p>Nenhum produto do seu setor bate com "{busca}".</p>}
            </div>
          )}
          {grupos.map(([cat, itens]) => (
            <div key={cat}>
              <p className="item-meta" style={{ fontWeight: 700, marginTop: 10 }}>
                {cat}
              </p>
              {itens.map((c) => (
                <ItemRow key={c.id} carrinhoItem={c} />
              ))}
            </div>
          ))}
        </div>

        <div className="confirm-acoes">
          <button ref={fecharBtnRef} className="btn btn-secondary" onClick={onFechar}>
            Fechar
          </button>
        </div>
      </div>
    </div>
  )
}
