import { NavLink } from 'react-router-dom'
import { useApp } from '../context/AppContext'

const ITEMS_ADMIN = [
  { to: '/', label: 'Lista', icon: '☰' },
  { to: '/catalogo', label: 'Catálogo', icon: '⌕' },
  { to: '/fornecedor', label: 'Fornecedores', icon: '▤' },
  { to: '/historico', label: 'Histórico', icon: '↺' },
]

const ITEMS_CONVIDADO = [{ to: '/', label: 'Catálogo', icon: '⌕' }]

export default function NavBar() {
  const { isAdmin } = useApp()
  const items = isAdmin ? ITEMS_ADMIN : ITEMS_CONVIDADO

  return (
    <nav className="navbar">
      {items.map(({ to, label, icon }) => (
        <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => (isActive ? 'active' : '')}>
          <span className="nav-icon">{icon}</span>
          {label}
        </NavLink>
      ))}
    </nav>
  )
}
