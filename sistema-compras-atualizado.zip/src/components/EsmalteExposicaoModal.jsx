import { useEffect, useMemo, useState } from 'react'
import { useApp } from '../context/AppContext'
import {
  CATEGORIA_ESMALTES,
  MARCAS_ESMALTE,
  agruparEsmaltesPorMarca,
  compararNomesEsmalte,
  separarNomeEMarca,
} from '../data/mockData'

// "Bloco de notas" dos esmaltes de exposição (manicure ou admin): escolhe a
// marca no select, digita o nome do esmalte, diz quanto quer comprar e
// clica em Adicionar — e repete quantas vezes quiser, podendo trocar a
// marca a qualquer momento. Só quando clica em Salvar é que a lista vai:
// (1) o retrato da vitrine da filial é substituído por inteiro e (2) cada
// esmalte com quantidade maior que 0 vira pedido de compra normal, no
// fornecedor "Kapital" (ver salvarEsmaltesExposicao).
//
// Esmaltes que já estavam salvos da última vez voltam com a quantidade
// vazia: já foram pedidos (ou não era pra pedir), então só voltam a ser
// pedido se a quantidade for preenchida de novo. Os recém-adicionados
// começam com 1.
//
// Modo `somenteCadastro` (convidado "só esmaltes"): o modal serve só pra
// CRIAR o produto de um esmalte que ainda NÃO existe — não pede quantidade e
// não gera pedido de compra; quem quer pedir um esmalte faz isso pela lista
// da página inicial, com o "+" dele. Por isso a lista começa vazia (só os
// novos), não há sugestão de nomes nem "escolher da lista", e nome já
// cadastrado só recebe o aviso de que o esmalte já existe.
const QTD_PADRAO = '1'

// Tenta ler uma linha colada como "Nome ... quantidade" (tab, ; ou vários
// espaços separando). Sem número no final, assume quantidade padrão.
function interpretarLinha(linha) {
  const limpa = linha.trim()
  if (!limpa) return null
  const comSeparador = /^(.+?)[\t;]\s*(\d+)\s*$/.exec(limpa)
  if (comSeparador) return { nome: comSeparador[1].trim(), quantidade: comSeparador[2] }
  const comEspacos = /^(.+\S)\s{1,}(\d+)\s*$/.exec(limpa)
  if (comEspacos) return { nome: comEspacos[1].trim(), quantidade: comEspacos[2] }
  return { nome: limpa, quantidade: QTD_PADRAO }
}

export default function EsmalteExposicaoModal({ aberto, onFechar, somenteCadastro = false }) {
  const { filial, catalogo, isAdmin, esmaltesDaFilial, salvarEsmaltesExposicao } = useApp()
  const [marca, setMarca] = useState(MARCAS_ESMALTE[0])
  const [nome, setNome] = useState('')
  const [quantidade, setQuantidade] = useState(QTD_PADRAO)
  const [estoque, setEstoque] = useState('')
  const [itens, setItens] = useState([])
  const [salvando, setSalvando] = useState(false)
  const [colarAberto, setColarAberto] = useState(false)
  const [textoColado, setTextoColado] = useState('')
  const [avisoColagem, setAvisoColagem] = useState('')
  const [escolherAberto, setEscolherAberto] = useState(false)

  useEffect(() => {
    if (aberto) {
      // Modo cadastro começa vazio: a vitrine que já estava salva é
      // preservada na hora de salvar (ver salvarEsmaltesExposicao).
      const listaAtual = somenteCadastro
        ? []
        : (esmaltesDaFilial()?.itens ?? []).map((it) => ({ ...it, quantidade: '', estoque: '' }))
      setItens(listaAtual)
      setMarca(MARCAS_ESMALTE[0])
      setNome('')
      setQuantidade(QTD_PADRAO)
      setEstoque('')
      setColarAberto(false)
      setTextoColado('')
      setAvisoColagem('')
      setEscolherAberto(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [aberto])

  // Nomes já usados dessa marca — tanto o que já está cadastrado no
  // catálogo desta filial quanto o que já foi adicionado nesta sessão
  // (ainda não salvo). É contra essa lista que checamos duplicidade/nomes
  // parecidos, pra pegar erro de digitação ANTES de virar produto novo.
  const nomesDoCatalogo = useMemo(
    () =>
      catalogo
        .filter((i) => i.filial === filial && i.categoria === CATEGORIA_ESMALTES)
        .map((i) => separarNomeEMarca(i.nome))
        .filter((p) => p && p.marca === marca)
        .map((p) => p.nome),
    [catalogo, filial, marca]
  )
  const nomesDaSessao = useMemo(
    () => itens.filter((it) => it.marca === marca).map((it) => it.nome),
    [itens, marca]
  )
  const nomesDaMarca = useMemo(
    () => Array.from(new Set([...nomesDoCatalogo, ...nomesDaSessao])).sort((a, b) => a.localeCompare(b, 'pt-BR')),
    [nomesDoCatalogo, nomesDaSessao]
  )

  // Todo esmalte já cadastrado no catálogo desta filial (de qualquer marca),
  // agrupado por marca — pra quem preferir clicar em vez de digitar, sem
  // precisar ficar trocando o select de marca só pra ver o que já existe.
  const catalogoEsmaltesPorMarca = useMemo(
    () => agruparEsmaltesPorMarca(catalogo.filter((i) => i.filial === filial)),
    [catalogo, filial]
  )

  // Mesma lista de `itens`, só que em ordem alfabética pra exibição — guarda
  // o índice original de cada um pra alterarQuantidade/removerItem, que
  // continuam operando sobre a posição real no estado, não na posição
  // exibida na tela.
  const itensOrdenados = useMemo(
    () =>
      itens
        .map((it, index) => ({ ...it, index }))
        .sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR')),
    [itens]
  )

  if (!aberto) return null

  // Compara o nome digitado com os já existentes da marca. Devolve o
  // achado: {tipo: 'igual'|'parecido', nomeExistente, origem:
  // 'catalogo'|'sessao'}. Nome igual sempre ganha de nome só parecido (não
  // importa a ordem da lista), e procura primeiro no que já está cadastrado
  // e só depois no que foi adicionado nesta sessão (ainda não salvo).
  function checarParecido(nomeDigitado) {
    const fontes = [
      ['catalogo', nomesDoCatalogo],
      ['sessao', nomesDaSessao],
    ]
    let achadoParecido = null
    for (const [origem, nomes] of fontes) {
      for (const existente of nomes) {
        const tipo = compararNomesEsmalte(nomeDigitado, existente)
        if (tipo === 'igual') return { tipo, nomeExistente: existente, origem }
        if (tipo && !achadoParecido) achadoParecido = { tipo, nomeExistente: existente, origem }
      }
    }
    return achadoParecido
  }

  const parecido = nome.trim() ? checarParecido(nome) : null

  function usarNomeExistente(nomeExistente) {
    setNome(nomeExistente)
  }

  // Textos do aviso no modo cadastro. Esmalte que já está cadastrado não
  // recebe sugestão de "usar esse nome": só o aviso de que já existe e de que
  // o pedido é feito pela página inicial. Nome só parecido não bloqueia
  // (pode ser outro esmalte de verdade), mas também não empurra nenhum nome.
  function mensagemCadastro(achado) {
    const nomeEx = <strong>"{achado.nomeExistente}"</strong>
    if (achado.origem === 'catalogo') {
      return achado.tipo === 'igual' ? (
        <>
          Esse esmalte já existe, cadastrado como {nomeEx}. Não precisa cadastrar de novo — peça ele pela página
          inicial.
        </>
      ) : (
        <>
          Já existe {nomeEx} cadastrado, com um nome parecido. Se for o mesmo esmalte, peça ele pela página inicial.
          Se for outro, é só adicionar.
        </>
      )
    }
    return achado.tipo === 'igual' ? (
      <>Esse esmalte já está na lista abaixo como {nomeEx} — não precisa adicionar de novo.</>
    ) : (
      <>
        Já tem {nomeEx} na lista abaixo, com um nome parecido. Se for o mesmo esmalte, não precisa adicionar de
        novo. Se for outro, é só adicionar.
      </>
    )
  }

  function adicionar(e) {
    e.preventDefault()
    const nomeLimpo = nome.trim()
    if (!nomeLimpo) return
    setItens((atual) => [
      ...atual,
      { marca, nome: nomeLimpo, quantidade: somenteCadastro ? '' : quantidade, estoque: somenteCadastro ? '' : estoque },
    ])
    setNome('')
    setQuantidade(QTD_PADRAO)
    setEstoque('')
  }

  function alterarQuantidade(index, valor) {
    setItens((atual) => atual.map((it, i) => (i === index ? { ...it, quantidade: valor } : it)))
  }

  function alterarEstoque(index, valor) {
    setItens((atual) => atual.map((it, i) => (i === index ? { ...it, estoque: valor } : it)))
  }

  function removerItem(index) {
    setItens((atual) => atual.filter((_, i) => i !== index))
  }

  // Clique num esmalte já cadastrado (lista "escolher da lista"): adiciona
  // direto com quantidade padrão, sem precisar digitar nada. Se já estiver
  // nesta sessão, o botão já vem desabilitado — não faz nada de novo.
  function adicionarDoCatalogo(marcaClicada, nomeClicado) {
    const jaNaLista = itens.some((it) => it.marca === marcaClicada && it.nome === nomeClicado)
    if (jaNaLista) return
    setItens((atual) => [...atual, { marca: marcaClicada, nome: nomeClicado, quantidade: QTD_PADRAO, estoque: '' }])
  }

  // Cola várias linhas de uma vez (ex.: uma lista de pedido copiada de um
  // PDF/planilha), todas na marca selecionada no momento. Cada linha vira
  // um item, pulando as que já existem exatamente iguais na lista atual e
  // avisando (sem bloquear) sobre nomes parecidos, pra revisão manual.
  function adicionarLista() {
    const linhas = textoColado.split('\n').map(interpretarLinha).filter(Boolean)
    if (linhas.length === 0) return

    const parecidos = []
    let ignorados = 0
    const novos = []
    const jaNestaLista = new Set(itens.filter((it) => it.marca === marca).map((it) => it.nome.trim().toLowerCase()))

    linhas.forEach(({ nome: nomeLinha, quantidade: qtdLinha }) => {
      const chave = nomeLinha.toLowerCase()
      if (jaNestaLista.has(chave)) {
        ignorados += 1
        return
      }
      const achado = checarParecido(nomeLinha)
      if (achado?.tipo === 'igual') {
        ignorados += 1
        return
      }
      if (achado?.tipo === 'parecido') {
        parecidos.push(`"${nomeLinha}" parece com "${achado.nomeExistente}" já existente`)
      }
      jaNestaLista.add(chave)
      novos.push({ marca, nome: nomeLinha, quantidade: qtdLinha, estoque: '' })
    })

    setItens((atual) => [...atual, ...novos])
    setTextoColado('')

    const partes = [`${novos.length} ${novos.length === 1 ? 'esmalte adicionado' : 'esmaltes adicionados'}`]
    if (ignorados > 0) partes.push(`${ignorados} já estava(m) na lista e não foi(ram) duplicado(s)`)
    setAvisoColagem(
      partes.join(' · ') + (parecidos.length > 0 ? `. Confira antes de salvar: ${parecidos.join('; ')}.` : '.')
    )
  }

  function fechar() {
    onFechar()
  }

  const qtdParaComprar = itens.filter((it) => Number(it.quantidade) > 0).length

  // Estoque atual é obrigatório em todo esmalte que vai virar pedido de
  // compra (0 vale; vazio não).
  const semEstoque = (it) => !somenteCadastro && Number(it.quantidade) > 0 && String(it.estoque ?? '').trim() === ''
  const qtdSemEstoque = itens.filter(semEstoque).length

  async function handleSalvar() {
    if (qtdSemEstoque > 0) return
    setSalvando(true)
    try {
      const resultado = await salvarEsmaltesExposicao(itens, { cadastro: somenteCadastro })
      if (resultado) onFechar()
    } finally {
      setSalvando(false)
    }
  }

  return (
    <div className="confirm-overlay" onClick={fechar}>
      <div
        className="confirm-dialog consumo-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="esmaltes-titulo"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="confirm-titulo-row">
          <h2 id="esmaltes-titulo" className="confirm-titulo">
            {somenteCadastro ? 'Cadastrar esmalte novo' : 'Esmaltes de exposição'} — {filial}
          </h2>
          <button type="button" className="icon-btn modal-close-btn" title="Fechar sem salvar" onClick={fechar}>
            ✕
          </button>
        </div>
        {!somenteCadastro && (
          <p className="confirm-mensagem">
            Escolha a marca, digite o nome do esmalte, informe quantos quer comprar e clique em Adicionar. Pode ir
            adicionando quantos quiser, inclusive trocando de marca — só clique em Salvar quando terminar.
          </p>
        )}

        <form onSubmit={adicionar} className="inline-edit-form" style={{ marginBottom: 6 }}>
          <div className="field">
            <label>Marca</label>
            <select value={marca} onChange={(e) => setMarca(e.target.value)}>
              {MARCAS_ESMALTE.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Nome do esmalte</label>
            <input
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              placeholder="Ex.: Vermelho Paixão"
              autoFocus
              list={somenteCadastro ? undefined : 'esmaltes-sugestoes'}
            />
            {!somenteCadastro && (
              <datalist id="esmaltes-sugestoes">
                {nomesDaMarca.map((n) => (
                  <option key={n} value={n} />
                ))}
              </datalist>
            )}
          </div>
          {!somenteCadastro && (
            <>
              <div className="field">
                <label>Estoque atual (obrigatório)</label>
                <input
                  type="number"
                  inputMode="numeric"
                  min="0"
                  placeholder="0"
                  required={Number(quantidade) > 0}
                  value={estoque}
                  onChange={(e) => setEstoque(e.target.value)}
                />
              </div>
              <div className="field">
                <label>Qtd. a comprar</label>
                <input
                  type="number"
                  inputMode="numeric"
                  min="0"
                  value={quantidade}
                  onChange={(e) => setQuantidade(e.target.value)}
                />
              </div>
            </>
          )}
          <div className="inline-edit-actions">
            <button className="btn btn-primary" type="submit" disabled={!nome.trim() || parecido?.tipo === 'igual'}>
              Adicionar
            </button>
          </div>
        </form>

        {parecido && (
          <p
            className="item-meta"
            style={{
              marginTop: 0,
              marginBottom: 14,
              color: parecido.tipo === 'igual' ? 'var(--danger-ink)' : 'var(--warning-ink, #9a6700)',
            }}
          >
            {somenteCadastro ? (
              mensagemCadastro(parecido)
            ) : parecido.tipo === 'igual' ? (
              <>
                Esse esmalte já está na lista como <strong>"{parecido.nomeExistente}"</strong> — ajuste a quantidade
                dele em vez de adicionar de novo.
              </>
            ) : (
              <>
                Já existe <strong>"{parecido.nomeExistente}"</strong> cadastrado — parece o mesmo esmalte com o nome
                digitado diferente?{' '}
                <button
                  type="button"
                  className="icon-btn"
                  style={{ display: 'inline', width: 'auto', padding: '0 4px' }}
                  onClick={() => usarNomeExistente(parecido.nomeExistente)}
                >
                  Usar esse nome
                </button>
              </>
            )}
          </p>
        )}

        {isAdmin && !somenteCadastro && (
          <button
            type="button"
            className="btn btn-secondary"
            style={{ marginBottom: 14 }}
            onClick={() => setColarAberto((v) => !v)}
          >
            {colarAberto ? 'Fechar colar lista' : '📋 Colar lista (vários de uma vez)'}
          </button>
        )}

        {isAdmin && !somenteCadastro && colarAberto && (
          <div className="inline-edit-form" style={{ marginBottom: 14 }}>
            <p className="item-meta" style={{ marginTop: 0 }}>
              Cole uma linha por esmalte da marca <strong>{marca}</strong> — nome e quantidade, separados por espaço,
              tab ou ";". Ex.: <code>Bali 2</code>. Sem número no final, entra com quantidade 1.
            </p>
            <textarea
              rows={6}
              style={{ width: '100%', fontFamily: 'monospace' }}
              value={textoColado}
              onChange={(e) => setTextoColado(e.target.value)}
              placeholder={`Dara 1\nInspiração Divina 1\nRosa Bombom 2`}
            />
            <div className="inline-edit-actions">
              <button type="button" className="btn btn-primary" onClick={adicionarLista} disabled={!textoColado.trim()}>
                Adicionar lista à marca {marca}
              </button>
            </div>
            {avisoColagem && (
              <p className="item-meta" style={{ color: 'var(--warning-ink, #9a6700)' }}>
                {avisoColagem}
              </p>
            )}
          </div>
        )}

        {!somenteCadastro && catalogoEsmaltesPorMarca.length > 0 && (
          <button
            type="button"
            className="btn btn-secondary"
            style={{ marginBottom: 14 }}
            onClick={() => setEscolherAberto((v) => !v)}
          >
            {escolherAberto ? 'Fechar lista pra clicar' : '🖱️ Escolher da lista (sem digitar)'}
          </button>
        )}

        {!somenteCadastro && escolherAberto && (
          <div className="inline-edit-form" style={{ marginBottom: 14 }}>
            <p className="item-meta" style={{ marginTop: 0 }}>
              Esmaltes já cadastrados nesta filial, separados por marca — clique pra adicionar com quantidade{' '}
              {QTD_PADRAO} (dá pra ajustar depois, na lista abaixo).
            </p>
            <div className="esmalte-picker-lista">
              {catalogoEsmaltesPorMarca.map(([m, nomes]) => (
                <div key={m} className="esmalte-picker-grupo">
                  <p className="item-marca-tag" style={{ margin: '0 0 6px' }}>
                    {m}
                  </p>
                  <div className="esmalte-chip-grid">
                    {nomes.map((n) => {
                      const jaNaLista = itens.some((it) => it.marca === m && it.nome === n)
                      return (
                        <button
                          type="button"
                          key={n}
                          className={`esmalte-chip ${jaNaLista ? 'esmalte-chip--adicionado' : ''}`}
                          disabled={jaNaLista}
                          onClick={() => adicionarDoCatalogo(m, n)}
                        >
                          {n}
                          {jaNaLista ? ' ✓' : ''}
                        </button>
                      )
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="consumo-lista">
          <p className="category-heading" style={{ marginTop: 0 }}>
            {itens.length} {itens.length === 1 ? 'esmalte adicionado' : 'esmaltes adicionados'}
          </p>

          {itens.length === 0 && (
            <div className="empty-state">
              <h3>Nada adicionado ainda</h3>
              <p>Use o formulário acima pra começar a lista.</p>
            </div>
          )}

          {qtdSemEstoque > 0 && (
            <p className="item-meta" style={{ marginBottom: 8, color: 'var(--danger-ink)' }}>
              Preencha o estoque atual dos esmaltes marcados em vermelho (pode ser 0) para salvar.
            </p>
          )}

          {itens.length > 0 && !somenteCadastro && (
            <p className="item-meta" style={{ marginBottom: 8 }}>
              {qtdParaComprar > 0
                ? `${qtdParaComprar} ${qtdParaComprar === 1 ? 'esmalte entra' : 'esmaltes entram'} na lista de compras (fornecedor Kapital). Quantidade vazia ou 0 só mantém na lista de exposição.`
                : 'Nenhuma quantidade preenchida — nada vai pra lista de compras. Preencha a quantidade dos que quer comprar.'}
            </p>
          )}

          {itensOrdenados.map((it) => (
            <div className="consumo-row" key={`${it.marca}-${it.nome}-${it.index}`}>
              <p className="item-name" style={{ margin: 0 }}>
                {it.nome}
                <span className="item-marca-tag" style={{ marginLeft: 8 }}>
                  {it.marca}
                </span>
              </p>
              <div className="consumo-input-wrap">
                {!somenteCadastro && (
                  <>
                    <label className="consumo-mini">
                      <span>Estq</span>
                      <input
                        className={`consumo-input ${semEstoque(it) ? 'consumo-input--erro' : ''}`}
                        type="number"
                        inputMode="numeric"
                        min="0"
                        placeholder="0"
                        value={it.estoque ?? ''}
                        onChange={(e) => alterarEstoque(it.index, e.target.value)}
                        aria-label={`Estoque atual de ${it.nome}`}
                      />
                    </label>
                    <label className="consumo-mini">
                      <span>Comprar</span>
                      <input
                        className="consumo-input"
                        type="number"
                        inputMode="numeric"
                        min="0"
                        placeholder="—"
                        value={it.quantidade}
                        onChange={(e) => alterarQuantidade(it.index, e.target.value)}
                        aria-label={`Quantidade a comprar de ${it.nome}`}
                      />
                    </label>
                  </>
                )}
                <button
                  type="button"
                  className="icon-btn danger"
                  title="Remover esmalte da lista (ainda não foi salvo)"
                  onClick={() => removerItem(it.index)}
                >
                  🗑
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="confirm-acoes">
          <button className="btn btn-secondary" onClick={fechar} disabled={salvando}>
            Cancelar
          </button>
          <button className="btn btn-primary" onClick={handleSalvar} disabled={salvando || itens.length === 0 || qtdSemEstoque > 0}>
            {salvando ? 'Salvando...' : !somenteCadastro && qtdParaComprar > 0 ? 'Salvar e criar pedido' : 'Salvar'}
          </button>
        </div>
      </div>
    </div>
  )
}
