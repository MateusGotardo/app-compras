import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { CATEGORIAS, opcoesUnidade } from '../data/mockData'
import { converterConsumo, formatarConsumo, sanitizarConsumoDigitado, unidadeDoConsumo } from '../utils/consumo'

// Mesmo tratamento de acentos/maiúsculas usado na busca do Catálogo.
function normalizar(texto) {
  return (texto || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
}

// Consumo médio semanal começa manual (o admin informa um valor de
// referência), mas depois o app aprende sozinho: cada aviso de "quanto tem
// agora" é uma leitura de estoque, e o que sumiu entre duas leituras
// seguidas — descontando qualquer compra recebida no meio do caminho — é
// consumo real. Não precisa esperar zerar: comprar com pouca unidade ainda
// em estoque também gera um ponto de aprendizado (ver
// reconciliarEventosDoItem no AppContext). Quem informa a leitura é
// normalmente o convidado, mas quem escreve a média aprendida é sempre a
// sessão do admin. Editar aqui na mão continua funcionando a qualquer
// momento — serve tanto pra dar o chute inicial quanto pra corrigir o
// número se ele aprender torto.
//
// O consumo tem unidade própria (UN, PCTE, CX...) e no máximo 1 casa decimal
// (ex.: 2,5 pct/sem.). O aprendizado só compara leituras na mesma unidade
// (ver reconciliarEventosDoItem no AppContext), então a unidade escolhida
// aqui é a que a média aprendida vai respeitar.
export default function ConsumoMedioModal({ aberto, onFechar }) {
  const { catalogoDaFilial, filial, atualizarItemCatalogo } = useApp()
  const [busca, setBusca] = useState('')
  // Valor "em digitação" por item — enquanto existe aqui, ganha prioridade
  // sobre o valor salvo (evita o cursor pular/o campo "corrigir" a cada
  // tecla). Some assim que sai do campo e o salvamento é confirmado.
  const [editando, setEditando] = useState({})

  if (!aberto) return null

  const catalogo = catalogoDaFilial()
  const buscaAtiva = busca.trim().length > 0
  const itens = buscaAtiva
    ? catalogo.filter((i) => normalizar(i.nome).includes(normalizar(busca)))
    : catalogo

  const porCategoria = itens.reduce((acc, item) => {
    const cat = item.categoria || 'Sem categoria'
    acc[cat] = acc[cat] || []
    acc[cat].push(item)
    return acc
  }, {})
  Object.values(porCategoria).forEach((lista) => lista.sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR')))
  const categorias = CATEGORIAS.filter((cat) => porCategoria[cat])

  function valorExibido(item) {
    return editando[item.id] !== undefined ? editando[item.id] : formatarConsumo(item.consumoMedioSemanal)
  }

  function aoDigitar(item, valor) {
    setEditando((atual) => ({ ...atual, [item.id]: sanitizarConsumoDigitado(valor) }))
  }

  async function trocarUnidade(item, unidade) {
    await atualizarItemCatalogo(item.id, { consumoMedioUnidade: unidade })
  }

  async function salvar(item) {
    const bruto = editando[item.id]
    if (bruto === undefined) return
    const valor = converterConsumo(bruto)
    setEditando((atual) => {
      const { [item.id]: _omit, ...resto } = atual
      return resto
    })
    if (valor === (item.consumoMedioSemanal ?? null)) return
    await atualizarItemCatalogo(item.id, { consumoMedioSemanal: valor, consumoMedioUnidade: unidadeDoConsumo(item) })
  }

  function fechar() {
    setBusca('')
    setEditando({})
    onFechar()
  }

  return (
    <div className="confirm-overlay" onClick={fechar}>
      <div
        className="confirm-dialog consumo-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="consumo-titulo"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 id="consumo-titulo" className="confirm-titulo">
          Consumo médio semanal — {filial}
        </h2>
        <p className="confirm-mensagem">
          Preencha à mão quanto cada produto costuma gastar por semana (até 1 casa decimal, ex.: 2,5) e escolha a
          unidade — UN, PCTE, CX... Depois disso o app aprende sozinho comparando os avisos de estoque (não precisa
          esperar zerar) com as compras recebidas no meio do caminho, sempre na mesma unidade. Pode continuar
          corrigindo aqui sempre que achar necessário.
        </p>

        <div className="search-box" style={{ marginBottom: 14 }}>
          <input placeholder="Buscar produto..." value={busca} onChange={(e) => setBusca(e.target.value)} />
        </div>

        <div className="consumo-lista">
          {categorias.map((cat) => (
            <div key={cat}>
              <p className="category-heading">{cat}</p>
              {porCategoria[cat].map((item) => (
                <div className="consumo-row" key={item.id}>
                  <p className="item-name">{item.nome}</p>
                  <span className="consumo-input-wrap">
                    <input
                      className="consumo-input"
                      type="text"
                      inputMode="decimal"
                      placeholder="—"
                      value={valorExibido(item)}
                      onChange={(e) => aoDigitar(item, e.target.value)}
                      onBlur={() => salvar(item)}
                    />
                    <select
                      className="unidade-select unidade-select--curto"
                      value={unidadeDoConsumo(item)}
                      onChange={(e) => trocarUnidade(item, e.target.value)}
                      title="Unidade do consumo médio"
                    >
                      {opcoesUnidade(unidadeDoConsumo(item)).map((u) => (
                        <option key={u.value} value={u.value}>
                          {u.value}
                        </option>
                      ))}
                    </select>
                    <span className="consumo-input-suffix">/sem.</span>
                  </span>
                </div>
              ))}
            </div>
          ))}

          {itens.length === 0 && (
            <div className="empty-state">
              <h3>Nada encontrado</h3>
            </div>
          )}
        </div>

        <div className="confirm-acoes">
          <button className="btn btn-secondary" onClick={fechar}>
            Fechar
          </button>
        </div>
      </div>
    </div>
  )
}
