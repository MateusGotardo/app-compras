import { useState } from 'react'
import { useApp } from '../context/AppContext'

// Campo de texto com sugestões de fornecedores já cadastrados, filtradas em
// tempo real conforme o usuário digita. Se o texto digitado não bater com
// nenhum fornecedor existente, aparece uma opção pra cadastrar esse nome
// novo na hora — ele já fica disponível pra próxima vez.
export default function FornecedorAutocomplete({ value, onChange, placeholder }) {
  const { fornecedoresDaFilial, cadastrarFornecedor } = useApp()
  const [aberto, setAberto] = useState(false)
  const [cadastrando, setCadastrando] = useState(false)

  const termo = value.trim().toLowerCase()
  const sugestoes = fornecedoresDaFilial()
    .filter((nome) => nome.toLowerCase().includes(termo))
    .slice(0, 6)

  const jaExiste = fornecedoresDaFilial().some((nome) => nome.toLowerCase() === termo)
  const mostrarCadastrarNovo = termo.length > 0 && !jaExiste

  function escolher(nome) {
    onChange(nome)
    setAberto(false)
  }

  async function cadastrarNovoENoCampo() {
    setCadastrando(true)
    const nomeSalvo = await cadastrarFornecedor(value)
    setCadastrando(false)
    escolher(nomeSalvo)
  }

  return (
    <div className="autocomplete">
      <input
        value={value}
        placeholder={placeholder}
        onChange={(e) => {
          onChange(e.target.value)
          setAberto(true)
        }}
        onFocus={() => setAberto(true)}
        // Pequeno atraso pra permitir o clique numa opção antes de fechar o menu.
        onBlur={() => setTimeout(() => setAberto(false), 150)}
      />
      {aberto && (sugestoes.length > 0 || mostrarCadastrarNovo) && (
        <div className="autocomplete-menu">
          {sugestoes.map((nome) => (
            <button
              key={nome}
              type="button"
              className="autocomplete-option"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => escolher(nome)}
            >
              {nome}
            </button>
          ))}
          {mostrarCadastrarNovo && (
            <button
              type="button"
              className="autocomplete-option autocomplete-option-new"
              onMouseDown={(e) => e.preventDefault()}
              onClick={cadastrarNovoENoCampo}
              disabled={cadastrando}
            >
              {cadastrando ? 'Cadastrando...' : `+ Cadastrar novo fornecedor "${value.trim()}"`}
            </button>
          )}
        </div>
      )}
    </div>
  )
}
