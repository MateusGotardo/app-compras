import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'
import { initializeFirestore, disableNetwork, enableNetwork } from 'firebase/firestore'

// Essas chaves vêm do seu projeto Firebase (console.firebase.google.com).
// Coloque os valores reais no arquivo .env (veja .env.example) — nunca
// commite o .env de verdade num repositório público.
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
}

export const firebaseApp = initializeApp(firebaseConfig)
export const auth = getAuth(firebaseApp)
// Long polling automático: no Safari/iPhone a conexão em tempo real do
// Firestore (WebChannel) às vezes trava em silêncio, e a tela fica com dado
// velho sem dar erro. Com isso o Firestore detecta o problema e troca de
// método de conexão sozinho.
export const db = initializeFirestore(firebaseApp, {
  experimentalAutoDetectLongPolling: true,
})

// iPhone suspende o app quando ele vai pra segundo plano e a conexão em
// tempo real pode ficar "morta" ao voltar. Se ficou fora da tela por mais de
// 30s, refaz a conexão ao voltar — os dados atualizam sem precisar recarregar.
if (typeof document !== 'undefined') {
  let saiuDaTelaEm = 0
  const reconectar = async () => {
    try {
      await disableNetwork(db)
      await enableNetwork(db)
    } catch (e) {
      console.warn('Falha ao refazer a conexão com o Firestore', e)
    }
  }
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      saiuDaTelaEm = Date.now()
    } else if (saiuDaTelaEm && Date.now() - saiuDaTelaEm > 30000) {
      saiuDaTelaEm = 0
      reconectar()
    }
  })
  window.addEventListener('pageshow', (e) => {
    if (e.persisted) reconectar()
  })
}
