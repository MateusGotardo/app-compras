export const FILIAIS = ['Cachoeira', 'Damha']

// Prioridade do item: só existem esses 2 níveis. Itens Urgente são sempre
// fixados no topo das listas em que aparecem (ver listaAtiva/historico no
// AppContext) e ganham destaque visual vermelho suave no card.
export const PRIORIDADE = {
  URGENTE: 'urgente',
  NORMAL: 'normal',
}

// Categorias fixas do produto — select obrigatório no cadastro/edição pra
// evitar erro de digitação e categorias divergentes.
export const CATEGORIAS = [
  'Copa',
  'Bistrô',
  'Limpeza',
  'Manicures',
  'Cabeleireiros',
  'Estética',
  'Escritório',
  'Esmaltes expositor',
]

// Esmaltes de exposição viram pedido de compra normal: cada esmalte lançado
// com quantidade vira um item do catálogo (categoria/"setor" abaixo, usado
// nos filtros) + um pedido na lista, já apontando pro fornecedor de esmaltes
// abaixo (Kapital). Se um dia trocar de fornecedor, o admin pode trocar
// manualmente pelo pedido (definirFornecedorDoPedido, que também vira o
// fornecedor padrão do produto); a categoria continua a
// mesma, então o filtro por área segue funcionando. Os dois nomes são
// citados também em firestore.rules.
// Cada setor (categoria) tem uma cor própria — definida em index.css pelas
// classes `setor-{slug}` (com variações pro modo escuro). Esse slug é só o
// nome sem acento/espaço, ex.: "Bistrô" -> "bistro", "Esmaltes expositor" ->
// "esmaltes-expositor". Setor desconhecido devolve '' (fica sem cor).
export function classeDoSetor(categoria) {
  if (!categoria) return ''
  const slug = String(categoria)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
  return `setor-${slug}`
}

export const CATEGORIA_ESMALTES = 'Esmaltes expositor'
export const FORNECEDOR_ESMALTES = 'Kapital'

// Unidade em que a quantidade atual (informada no pedido, tanto por
// convidado quanto por admin) é contada. `value` é o que fica salvo no
// registro; `label` é só o texto mostrado no select.
export const UNIDADES_ESTOQUE = [
  { value: 'UN', label: 'UN' },
  { value: 'CX', label: 'CX' },
  { value: 'PCTE', label: 'PCTE' },
  { value: 'FT', label: 'FT' },
]

// Registros antigos podem ter "PCT" (antes o pacote era PCT/PCTE) ou uma
// das unidades que saíram da lista (FD, PAR, DZ, L, ML, GAL, KG, G). PCT é
// tratado como PCTE em toda parte (exibição, seleção e cálculo do consumo
// médio); as demais continuam sendo exibidas como estão, sem apagar o dado.
export function normalizarUnidade(unidade) {
  const u = String(unidade || 'UN').trim().toUpperCase()
  return u === 'PCT' ? 'PCTE' : u
}

// Opções do select de unidade: a lista atual + (se o valor salvo for de uma
// unidade que saiu da lista) o próprio valor, pra não parecer que mudou.
export function opcoesUnidade(unidadeAtual) {
  const atual = normalizarUnidade(unidadeAtual)
  return UNIDADES_ESTOQUE.some((u) => u.value === atual)
    ? UNIDADES_ESTOQUE
    : [...UNIDADES_ESTOQUE, { value: atual, label: atual }]
}

// Converte a quantidade comprada de um pedido pra unidades (UN) reais, usando
// o cadastro do produto — "unidadeNecessariaPadrao" (unidade fixa de compra)
// e "unidadesPorEmbalagem" (quantas UN cabem numa CX/PCTE/FT daquele
// produto), os dois definidos no cadastro/edição do item no Catálogo. Sem
// isso não dava pra somar "3 cx." com "10 un." num total só — cada produto
// tem uma quantidade de unidades por embalagem diferente (uma cx. de
// guardanapo não tem a mesma quantidade que uma cx. de polpa, por exemplo).
//
// Produto ainda não cadastrado com unidade fixa (ou pedido antigo, feito
// antes de definir isso) cai em "UN" com fator 1 — não trava o Painel, só
// fica impreciso até o item ser corrigido no Catálogo; a partir daí o
// Painel já soma certo sozinho, sem precisar mexer em nada aqui.
export function unidadesEquivalentes(carrinhoItem) {
  const qtd = Number(carrinhoItem?.quantidadeNecessaria) || 0
  const unidadePedido = normalizarUnidade(carrinhoItem?.unidadeNecessaria)
  if (unidadePedido === 'UN') return qtd

  const unidadeFixaItem = normalizarUnidade(carrinhoItem?.item?.unidadeNecessariaPadrao)
  // Se a unidade do pedido não bate com a unidade fixa atual do produto (item
  // ainda sem unidade fixa definida, ou ela mudou depois desse pedido), não
  // tem fator confiável pra converter — conta a quantidade como está, sem
  // multiplicar, em vez de arriscar um número errado.
  if (unidadePedido !== unidadeFixaItem) return qtd

  const fator = Number(carrinhoItem?.item?.unidadesPorEmbalagem)
  return fator > 0 ? qtd * fator : qtd
}

// Marcas de esmalte disponíveis no select da lista de "Esmaltes de
// exposição" (ver EsmalteExposicaoModal). Fixas, igual às categorias, pra
// evitar grafias diferentes da mesma marca.
export const MARCAS_ESMALTE = ['Colorama', 'Impala', 'Risqué', 'Risqué Gel', 'Dailus', 'Cora', 'OPI', 'Anitta']

// Nome do produto no catálogo/pedido de um esmalte de exposição — leva a
// marca junto pra aparecer completo no PDF do fornecedor e ficar em ordem
// alfabética agrupado por marca (ex.: "Esmalte Risqué Gel - Vermelho Paixão").
export function nomeProdutoEsmalte(marca, nome) {
  return `Esmalte ${marca} - ${nome.trim()}`
}

// Nome do catálogo é salvo como "Esmalte {marca} - {nome}" (ver
// nomeProdutoEsmalte acima). Pra sugerir/comparar por marca, ou pra exibir
// marca e nome do esmalte separados (em vez da string inteira misturada),
// precisamos separar essas duas partes de volta.
export function separarNomeEMarca(nomeCompleto) {
  const m = /^Esmalte\s+(.+?)\s+-\s+(.+)$/.exec(nomeCompleto || '')
  if (!m) return null
  return { marca: m[1], nome: m[2] }
}

// Agrupa itens do catálogo (já filtrados pela filial certa) que são da
// categoria "Esmaltes expositor" por marca, devolvendo pares
// [marca, nomes[]] na ordem fixa de MARCAS_ESMALTE (qualquer marca fora
// dela, o que não deveria acontecer, vai pro fim). Cada lista de nomes já
// vem em ordem alfabética. Usado tanto no lançamento de esmaltes quanto na
// busca da página "só esmaltes", pra não duplicar essa lógica nos dois
// lugares.
export function agruparEsmaltesPorMarca(itensCatalogo) {
  const porMarca = {}
  itensCatalogo
    .filter((i) => i.categoria === CATEGORIA_ESMALTES)
    .forEach((i) => {
      const p = separarNomeEMarca(i.nome)
      if (!p) return
      porMarca[p.marca] = porMarca[p.marca] || new Set()
      porMarca[p.marca].add(p.nome)
    })
  const marcasExtras = Object.keys(porMarca).filter((m) => !MARCAS_ESMALTE.includes(m))
  return [...MARCAS_ESMALTE, ...marcasExtras]
    .filter((m) => porMarca[m]?.size)
    .map((m) => [m, Array.from(porMarca[m]).sort((a, b) => a.localeCompare(b, 'pt-BR'))])
}

// Parecida com agruparEsmaltesPorMarca, mas devolve os próprios itens do
// catálogo (com id, pra poder pedir/avisar estoque), no formato
// [marca, [{ item, nome }]] — `nome` é só o nome do esmalte, sem o prefixo
// "Esmalte {marca} - ". Produto da categoria que não segue esse padrão de
// nome não some da lista: cai no grupo "Outros", com o nome inteiro.
export function agruparItensEsmaltePorMarca(itensCatalogo) {
  const porMarca = {}
  const outros = []
  itensCatalogo
    .filter((i) => i.categoria === CATEGORIA_ESMALTES)
    .forEach((i) => {
      const p = separarNomeEMarca(i.nome)
      if (!p) {
        outros.push({ item: i, nome: i.nome })
        return
      }
      porMarca[p.marca] = porMarca[p.marca] || []
      porMarca[p.marca].push({ item: i, nome: p.nome })
    })
  const ordenar = (lista) => lista.sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'))
  const marcasExtras = Object.keys(porMarca).filter((m) => !MARCAS_ESMALTE.includes(m))
  const grupos = [...MARCAS_ESMALTE, ...marcasExtras]
    .filter((m) => porMarca[m]?.length)
    .map((m) => [m, ordenar(porMarca[m])])
  if (outros.length) grupos.push(['Outros', ordenar(outros)])
  return grupos
}

export const STATUS = {
  AGUARDANDO_GLEISON: 'Aguardando Gleison',
  EM_ANDAMENTO: 'Em andamento',
  COMPRADO: 'Comprado',
  NAO_TINHA: 'Não tinha',
  RECEBIDO: 'Recebido',
  TEM_NO_ESTOQUE: 'Tem no Estoque',
}

// Status que fazem o item sair da lista ativa e virar histórico
export const STATUS_FINAIS = [STATUS.RECEBIDO, STATUS.TEM_NO_ESTOQUE]

// Status que já tiveram a compra resolvida (só falta chegar) — a partir daqui
// o item não é mais um alerta de estoque crítico (não fica mais destacado em
// vermelho nem fixado no topo, e some da contagem/filtro de "só urgentes"),
// mesmo continuando na lista ativa até ser Recebido.
export const STATUS_SEM_ALERTA_CRITICO = [STATUS.EM_ANDAMENTO, STATUS.COMPRADO]

// Um pedido é um alerta de estoque crítico quando o estoque zerou (prioridade
// Urgente) E a compra ainda não foi resolvida (não está Em andamento/Comprado
// nem finalizada). Usado pra destacar em vermelho, fixar no topo da lista
// ativa e contar/filtrar "só urgentes" na tela de Fornecedor.
export function ehAlertaEstoqueCritico(carrinhoItem) {
  return (
    carrinhoItem?.prioridade === PRIORIDADE.URGENTE &&
    !STATUS_SEM_ALERTA_CRITICO.includes(carrinhoItem?.status) &&
    !STATUS_FINAIS.includes(carrinhoItem?.status)
  )
}

// Data em que o produto foi comprado ('YYYY-MM-DD'). compradoEm é gravado
// quando o pedido vira "Comprado" (ou direto "Recebido"); pedidos antigos,
// de antes desse carimbo existir, caem na data da última atualização — que
// no histórico é o dia em que foram dados como recebidos.
export function dataDaCompra(carrinhoItem) {
  return carrinhoItem?.compradoEm || carrinhoItem?.atualizadoEm || null
}

export const STATUS_COLORS = {
  [STATUS.AGUARDANDO_GLEISON]: 'warning',
  [STATUS.EM_ANDAMENTO]: 'info',
  [STATUS.COMPRADO]: 'success-soft',
  [STATUS.NAO_TINHA]: 'danger-soft',
  [STATUS.RECEBIDO]: 'success',
  [STATUS.TEM_NO_ESTOQUE]: 'success',
}

// Deriva, a partir do nome cadastrado do usuário convidado, quais categorias
// ele pode acessar. Hoje o nome do usuário É a informação de permissão:
// - "Limpeza" → só a categoria Limpeza
// - "Copa / Bistro" → categorias Copa e Bistrô (nomes separados por "/",
//   comparação ignora acento/maiúsculas, então "Bistro" bate com "Bistrô")
// - "Escritório / Casa" → só Escritório é reconhecido como categoria; "Casa"
//   é ignorado por não corresponder a nenhuma categoria do catálogo
export function normalizar(texto) {
  return texto
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
}

// Distância de edição (Levenshtein) entre duas strings já normalizadas —
// conta quantas trocas/inserções/remoções de letra separam uma da outra.
// Usada só pra detectar nomes de esmalte parecidos (erro de digitação),
// nunca pra decidir automaticamente — a manicure sempre confirma.
function distanciaEdicao(a, b) {
  const m = a.length
  const n = b.length
  if (m === 0) return n
  if (n === 0) return m
  const linha = Array.from({ length: n + 1 }, (_, j) => j)
  for (let i = 1; i <= m; i += 1) {
    let anterior = linha[0]
    linha[0] = i
    for (let j = 1; j <= n; j += 1) {
      const temp = linha[j]
      linha[j] = a[i - 1] === b[j - 1] ? anterior : 1 + Math.min(anterior, linha[j], linha[j - 1])
      anterior = temp
    }
  }
  return linha[n]
}

// Compara um nome novo (ainda não salvo) com um nome já cadastrado da MESMA
// marca e diz se são "iguais" (iguais depois de tirar acento/maiúsculas —
// já é duplicidade certa) ou só "parecidos" (pode ser erro de digitação —
// vale perguntar antes de criar um esmalte novo). null quando não têm nada
// a ver um com o outro. A tolerância cresce um pouco com o tamanho do nome
// (nomes curtos toleram só 1 letra de diferença, pra "Bali" não bater com
// "Bela").
export function compararNomesEsmalte(nomeNovo, nomeExistente) {
  const a = normalizar(nomeNovo.trim())
  const b = normalizar(nomeExistente.trim())
  if (!a || !b) return null
  if (a === b) return 'igual'
  const tolerancia = a.length <= 5 || b.length <= 5 ? 1 : a.length <= 9 || b.length <= 9 ? 2 : 3
  return distanciaEdicao(a, b) <= tolerancia ? 'parecido' : null
}

export function derivarCategoriasDoNome(nome, categorias = CATEGORIAS) {
  if (!nome) return []
  const partes = nome.split('/').map((p) => normalizar(p)).filter(Boolean)
  const encontradas = categorias.filter((cat) => {
    const catNorm = normalizar(cat)
    return partes.some((p) => catNorm === p || catNorm.startsWith(p) || p.startsWith(catNorm))
  })
  return encontradas
}

