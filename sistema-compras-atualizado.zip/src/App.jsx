import { HashRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AppProvider, useApp } from './context/AppContext'
import { ToastProvider } from './context/ToastContext'
import { ConfirmProvider } from './context/ConfirmContext'
import { ThemeProvider } from './context/ThemeContext'
import TopBar from './components/TopBar'
import NavBar from './components/NavBar'
import Login from './pages/Login'
import ListaAtiva from './pages/ListaAtiva'
import Catalogo from './pages/Catalogo'
import Fornecedor from './pages/Fornecedor'
import Historico from './pages/Historico'

function Shell() {
  const { usuarioAtual, carregandoAuth, isAdmin } = useApp()

  if (carregandoAuth) {
    return <div className="app-shell" />
  }

  if (!usuarioAtual) {
    return (
      <div className="app-shell">
        <Login />
      </div>
    )
  }

  return (
    <div className="app-shell">
      <TopBar />
      <Routes>
        <Route path="/" element={isAdmin ? <ListaAtiva /> : <Catalogo />} />
        {isAdmin && <Route path="/catalogo" element={<Catalogo />} />}
        {isAdmin && <Route path="/fornecedor" element={<Fornecedor />} />}
        {isAdmin && <Route path="/historico" element={<Historico />} />}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <NavBar />
    </div>
  )
}

export default function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <ConfirmProvider>
          <AppProvider>
            <HashRouter>
              <Shell />
            </HashRouter>
          </AppProvider>
        </ConfirmProvider>
      </ToastProvider>
    </ThemeProvider>
  )
}
