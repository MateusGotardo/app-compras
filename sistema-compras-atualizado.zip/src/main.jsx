import React from 'react'
import ReactDOM from 'react-dom/client'
import { registerSW } from 'virtual:pwa-register'
import App from './App.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)

// ---------- Atualização automática do app (PWA) ----------
// Sem isso, o iPhone abria a versão antiga guardada no cache e só pegava a
// nova depois de fechar/atualizar a página algumas vezes. Agora:
//  1) sempre que o app volta pra tela (ou é aberto), confere se saiu versão
//     nova;
//  2) quando a versão nova assume o controle, a página recarrega sozinha
//     uma vez — esperando a pessoa sair do campo que estiver digitando, pra
//     não perder o que estava preenchendo.
if ('serviceWorker' in navigator) {
  const jaTinhaControlador = !!navigator.serviceWorker.controller
  let recarregando = false

  function recarregarQuandoSeguro() {
    if (recarregando) return
    const ativo = document.activeElement
    const digitando = ativo && ['INPUT', 'TEXTAREA', 'SELECT'].includes(ativo.tagName)
    if (digitando) {
      document.addEventListener('focusout', () => setTimeout(recarregarQuandoSeguro, 300), { once: true })
      return
    }
    recarregando = true
    window.location.reload()
  }

  // Primeira instalação (não havia controlador antes) não precisa recarregar.
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (jaTinhaControlador) recarregarQuandoSeguro()
  })

  registerSW({
    immediate: true,
    onRegisteredSW(_url, registro) {
      if (!registro) return
      const conferir = () => registro.update().catch(() => {})
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') conferir()
      })
      window.addEventListener('pageshow', (e) => {
        if (e.persisted) conferir()
      })
      conferir()
    },
  })
}
