import { createContext, useCallback, useContext, useRef, useState } from 'react'

const ToastContext = createContext(null)

const DURACAO = {
  sucesso: 1800,
  erro: 4500,
}

let proximoId = 1

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([])
  const timersRef = useRef({})

  const remover = useCallback((id) => {
    setToasts((atual) => atual.filter((t) => t.id !== id))
    clearTimeout(timersRef.current[id])
    delete timersRef.current[id]
  }, [])

  const mostrar = useCallback(
    (tipo, mensagem) => {
      const id = proximoId++
      setToasts((atual) => [...atual, { id, tipo, mensagem }])
      timersRef.current[id] = setTimeout(() => remover(id), DURACAO[tipo])
    },
    [remover]
  )

  const showSuccess = useCallback((mensagem) => mostrar('sucesso', mensagem), [mostrar])
  const showError = useCallback((mensagem) => mostrar('erro', mensagem), [mostrar])

  return (
    <ToastContext.Provider value={{ showSuccess, showError }}>
      {children}
      <div className="toast-viewport" role="status" aria-live="polite">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`toast toast--${t.tipo}`}
            onClick={() => remover(t.id)}
          >
            {t.mensagem}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}

export function useToast() {
  const ctx = useContext(ToastContext)
  if (!ctx) throw new Error('useToast precisa estar dentro de <ToastProvider>')
  return ctx
}
