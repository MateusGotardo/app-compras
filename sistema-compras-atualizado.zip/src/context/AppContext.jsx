import { createContext, useContext, useEffect, useState } from 'react'
import {
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
} from 'firebase/auth'
import {
  collection,
  onSnapshot,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  getDoc,
  setDoc,
  serverTimestamp,
  writeBatch,
  query,
  where,
} from 'firebase/firestore'
import { auth, db } from '../firebase'
import { useToast } from './ToastContext'
import { UNIDADE_CONSUMO_PADRAO, arredondarConsumo } from '../utils/consumo'
import {
  FILIAIS,
  STATUS_FINAIS,
  PRIORIDADE,
  CATEGORIAS,
  STATUS,
  CATEGORIA_ESMALTES,
  FORNECEDOR_ESMALTES,
  derivarCategoriasDoNome,
  nomeProdutoEsmalte,
  normalizar,
  normalizarUnidade,
  ehAlertaEstoqueCritico,
} from '../data/mockData'

// O campo "filial" do perfil do usuário é digitado à mão no console do
// Firebase, então casa ignorando maiúscula/minúscula e espaços com o valor
// exato usado no catálogo/carrinho ("Cachoeira" / "Damha") — um typo tipo
// "cachoeira" ou "damha " não pode deixar o convidado sem ver a lista dele.
// Sem bater com nenhuma das duas, devolve null (ver efeitos abaixo).
function normalizarFilial(valor) {
  const alvo = (valor || '').trim().toLowerCase()
  return FILIAIS.find((f) => f.toLowerCase() === alvo) || null
}

// Urgente sempre fixado no topo; entre itens de mesma prioridade, mantém a
// ordem em que já estavam (sort é estável). Prioridade agora é informada na
// hora da solicitação (item do carrinho), não é mais um dado fixo do catálogo.
// Deixa de contar como alerta assim que o status vira Em andamento/Comprado
// (ver ehAlertaEstoqueCritico) — já foi comprado, só falta chegar.
function pesoPrioridade(carrinhoItem) {
  return ehAlertaEstoqueCritico(carrinhoItem) ? 0 : 1
}

// ---------- Aprendizado do consumo médio semanal ----------
// Princípio: cada aviso de "quanto tem agora" é uma leitura real do
// estoque. Entre duas leituras seguidas de um mesmo produto, o que sumiu
// é consumo — mas se rolou compra no meio (não precisa ter zerado, pode
// ser reposição com estoque ainda baixo), a quantidade comprada tem que
// ser somada de volta antes de calcular, senão pareceria que "sobrou"
// estoque. Exemplo: leitura de 5un, compra +10un, próxima leitura de 8un,
// 20 dias depois → consumiu (5+10)-8 = 7un em 20 dias (~2,45un/semana).
// Essa taxa se mistura (média móvel) na média já salva, sem jogar fora o
// que veio antes.
//
// Unidades (UN, PCTE, CX...): só dá pra subtrair/somar quantidades na MESMA
// unidade — 3 pct e 3 un não são a mesma coisa, e sem uma tabela de
// conversão o app não sabe quantas un tem num pct. Por isso o consumo médio
// tem a sua própria unidade (consumoMedioUnidade) e o aprendizado só usa
// intervalos 100% na mesma unidade:
//  - duas leituras seguidas em unidades diferentes: não calcula, só passa a
//    usar a nova leitura como ponto de partida;
//  - compra recebida em unidade diferente da leitura de base: o intervalo
//    fica incompatível (não dá pra somar de volta) e é descartado;
//  - média já salva em outra unidade que a do intervalo: não mistura (quem
//    manda é a unidade escolhida pelo admin no campo de consumo);
//  - produto ainda sem média: adota a unidade em que o estoque foi contado.
//
// Importante: só é escrita pela sessão do admin (ver o useEffect de
// reconciliação abaixo) — o convidado só grava quantidadeAtual/
// quantidadeAtualEm no carrinho, como já fazia; é só a matéria-prima.
const PESO_DADO_NOVO = 0.4 // quanto o intervalo mais recente pesa sobre a média já salva
const MIN_SEMANAS = 0.5 // piso pra não estourar a taxa se duas leituras caírem quase no mesmo dia

function tsParaMillisOuData(dataISO, ts) {
  const millis = tsParaMillis(ts)
  if (millis !== null) return millis
  return new Date(`${dataISO}T00:00:00`).getTime()
}

// Roda por cima do histórico de carrinho de UM produto e devolve os campos
// do catálogo já atualizados (ou null se não achou nada novo pra aprender).
// `eventosNovos` já vem filtrado (só o que aconteceu depois do que a última
// reconciliação já processou) e ordenado do mais antigo pro mais novo.
function reconciliarEventosDoItem(itemAtual, eventosNovos) {
  let media = itemAtual.consumoMedioSemanal ?? null
  // Itens antigos têm média mas nenhuma unidade salva: o rótulo sempre foi
  // "un.", então é isso que assumimos.
  let unidadeMedia = itemAtual.consumoMedioUnidade
    ? normalizarUnidade(itemAtual.consumoMedioUnidade)
    : media != null
    ? UNIDADE_CONSUMO_PADRAO
    : null
  let baseQtd = itemAtual.estoqueBaseQtd ?? null
  let baseEm = itemAtual.estoqueBaseEm ?? null
  // Base antiga (de antes de guardarmos a unidade) fica sem unidade: não dá
  // pra saber em que unidade foi contada, então o primeiro intervalo com ela
  // é pulado e a próxima leitura já entra com unidade.
  let baseUnidade = itemAtual.estoqueBaseUnidade ? normalizarUnidade(itemAtual.estoqueBaseUnidade) : null
  let comprasDesdeBase = itemAtual.comprasDesdeBase ?? 0
  let comprasIncompativeis = itemAtual.comprasDesdeBaseIncompativeis ?? false
  let ultimoMomento = itemAtual.consumoUltimoEventoEm ?? null

  for (const ev of eventosNovos) {
    if (ev.tipo === 'compra') {
      if (baseUnidade && ev.unidade !== baseUnidade) {
        comprasIncompativeis = true
      } else {
        comprasDesdeBase += ev.quantidade
      }
    } else if (ev.tipo === 'leitura') {
      const mesmaUnidade = baseUnidade != null && ev.unidade === baseUnidade
      if (baseEm && ev.data > baseEm && mesmaUnidade && !comprasIncompativeis) {
        const dias = (new Date(`${ev.data}T00:00:00`) - new Date(`${baseEm}T00:00:00`)) / 86400000
        if (dias > 0) {
          const consumido = baseQtd + comprasDesdeBase - ev.quantidade
          // Se "consumido" sair negativo, o estoque subiu mais do que as
          // compras que a gente sabe explicam (correção de contagem pra
          // cima, ou uma compra que não passou pelo app) — não dá pra
          // confiar nesse intervalo, então não mexe na média.
          if (consumido > 0) {
            const semanas = Math.max(dias / 7, MIN_SEMANAS)
            const taxaSemanal = consumido / semanas
            if (media == null || unidadeMedia == null) {
              media = arredondarConsumo(taxaSemanal)
              unidadeMedia = baseUnidade
            } else if (unidadeMedia === baseUnidade) {
              media = arredondarConsumo(media * (1 - PESO_DADO_NOVO) + taxaSemanal * PESO_DADO_NOVO)
            }
            // else: a média salva está em outra unidade — não mistura.
          }
        }
      }
      baseQtd = ev.quantidade
      baseEm = ev.data
      baseUnidade = ev.unidade
      comprasDesdeBase = 0
      comprasIncompativeis = false
    }
    ultimoMomento = ev.momento
  }

  if (ultimoMomento === itemAtual.consumoUltimoEventoEm) return null // nada novo, não escreve à toa

  return {
    consumoMedioSemanal: media,
    consumoMedioUnidade: unidadeMedia,
    estoqueBaseQtd: baseQtd,
    estoqueBaseEm: baseEm,
    estoqueBaseUnidade: baseUnidade,
    comprasDesdeBase,
    comprasDesdeBaseIncompativeis: comprasIncompativeis,
    consumoUltimoEventoEm: ultimoMomento,
  }
}

// Prioridade é 100% automática a partir do estoque informado (não existe
// mais escolha manual de Urgente/Normal em nenhuma tela): estoque zerado
// vira Urgente; qualquer valor acima de 0, ou não informado (null), fica
// Normal. Recalculada tanto na criação do pedido quanto toda vez que o
// estoque é atualizado depois.
function calcularPrioridade(quantidadeAtual) {
  return quantidadeAtual === 0 ? PRIORIDADE.URGENTE : PRIORIDADE.NORMAL
}

// Converte um Timestamp do Firestore em milissegundos. Retorna null se ainda
// não tiver sido confirmado pelo servidor (escrita local pendente).
function tsParaMillis(ts) {
  if (!ts) return null
  if (typeof ts.toMillis === 'function') return ts.toMillis()
  if (typeof ts.seconds === 'number') return ts.seconds * 1000
  return null
}

const AppContext = createContext(null)

// Mensagem amigável por tipo de erro comum do Firestore. Sem rede é o caso
// mais frequente no salão (wifi instável) — por isso tem mensagem própria.
function traduzErroEscrita(e) {
  if (e?.code === 'unavailable' || e?.message?.includes('offline')) {
    return 'Sem conexão — não foi salvo. Tente de novo.'
  }
  if (e?.code === 'permission-denied') {
    return 'Sem permissão para essa ação.'
  }
  return 'Não foi possível salvar. Tente de novo.'
}

export function AppProvider({ children }) {
  const { showSuccess, showError } = useToast()
  const [firebaseUser, setFirebaseUser] = useState(null)
  const [usuarioAtual, setUsuarioAtual] = useState(null) // { nome, papel }
  const [carregandoAuth, setCarregandoAuth] = useState(true)
  const [authError, setAuthError] = useState(null)

  const [filial, setFilialState] = useState(FILIAIS[0])
  const [catalogo, setCatalogo] = useState([])
  const [carrinho, setCarrinho] = useState([])
  const [fornecedores, setFornecedores] = useState([])
  const [esmaltesExposicao, setEsmaltesExposicao] = useState([])

  // Observa login/logout e busca o perfil (nome + papel) na coleção "usuarios"
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user)
      if (user) {
        const perfilRef = doc(db, 'usuarios', user.uid)
        const snap = await getDoc(perfilRef)
        if (snap.exists()) {
          setUsuarioAtual({ uid: user.uid, ...snap.data() })
        } else {
          // Usuário existe no Firebase Auth mas ainda não tem perfil cadastrado
          // na coleção "usuarios" — trata como convidado até alguém cadastrar.
          setUsuarioAtual({ uid: user.uid, nome: user.email, papel: 'convidado' })
        }
      } else {
        setUsuarioAtual(null)
      }
      setCarregandoAuth(false)
    })
    return () => unsub()
  }, [])

  const isAdmin = usuarioAtual?.papel === 'admin'

  // Convidado agora é travado na filial cadastrada no perfil dele
  // (campo "filial" no documento em /usuarios, cadastrado direto no console
  // do Firebase junto com o funcionário) — ele nunca enxerga nem consegue
  // trocar pra outra filial. Admin continua vendo e trocando livremente
  // entre todas (ver setFilial mais abaixo e o TopBar, que só mostra o
  // seletor pra admin).
  useEffect(() => {
    if (usuarioAtual && usuarioAtual.papel !== 'admin') {
      // Sem bater com nenhuma filial conhecida, cai pra FILIAIS[0] em vez de
      // ficar sem filtro nenhum — um perfil mal cadastrado tem que ver uma
      // filial errada (fácil de perceber e corrigir), nunca as duas juntas.
      setFilialState(normalizarFilial(usuarioAtual.filial) || FILIAIS[0])
    }
  }, [usuarioAtual])

  // Sincroniza catálogo, carrinho e fornecedores cadastrados em tempo real
  // com o Firestore. Fornecedores é uma lista global (não por filial), pra
  // servir de sugestão no autocomplete em qualquer filial. Admin escuta
  // catálogo/carrinho de todas as filiais de uma vez (pra poder trocar o
  // seletor sem re-carregar); convidado só escuta a própria filial — além
  // de reforçar a separação, evita baixar dado de outra filial no celular
  // dele à toa.
  useEffect(() => {
    if (!firebaseUser || !usuarioAtual) return
    const filialTravada = usuarioAtual.papel === 'admin' ? null : normalizarFilial(usuarioAtual.filial) || FILIAIS[0]

    const refCatalogo = filialTravada
      ? query(collection(db, 'catalogo'), where('filial', '==', filialTravada))
      : collection(db, 'catalogo')
    const refCarrinho = filialTravada
      ? query(collection(db, 'carrinho'), where('filial', '==', filialTravada))
      : collection(db, 'carrinho')

    const unsubCatalogo = onSnapshot(refCatalogo, (snap) => {
      setCatalogo(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
    })
    const unsubCarrinho = onSnapshot(refCarrinho, (snap) => {
      setCarrinho(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
    })
    const unsubFornecedores = onSnapshot(collection(db, 'fornecedores'), (snap) => {
      setFornecedores(
        snap.docs
          .map((d) => ({ id: d.id, ...d.data() }))
          .sort((a, b) => a.nome.localeCompare(b.nome))
      )
    })
    // Lista de esmaltes de exposição: um documento por filial (id = nome da
    // filial). Coleção pequena (2 documentos hoje), então todo mundo escuta
    // as duas de uma vez — cada tela filtra pela filial que interessa.
    const unsubEsmaltes = onSnapshot(collection(db, 'esmaltesExposicao'), (snap) => {
      setEsmaltesExposicao(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
    })
    return () => {
      unsubCatalogo()
      unsubCarrinho()
      unsubFornecedores()
      unsubEsmaltes()
    }
  }, [firebaseUser, usuarioAtual])

  // Admin vê todas as categorias. Convidado só vê as categorias que o nome
  // dele (cadastrado em "usuarios") indica — ver derivarCategoriasDoNome.
  const categoriasPermitidas = isAdmin
    ? CATEGORIAS
    : derivarCategoriasDoNome(usuarioAtual?.nome)

  // Aprendizado do consumo médio: só roda pra admin (é quem tem permissão
  // de escrever no catálogo) e só quando catálogo e carrinho já carregaram.
  // Idempotente — cada item guarda até onde já processou (consumoUltimoEventoEm),
  // então rodar de novo com os mesmos dados não escreve nada (evita loop:
  // a própria escrita aqui reaciona esse efeito, mas na segunda passada não
  // acha evento novo e para sozinho).
  useEffect(() => {
    if (!isAdmin || !catalogo.length || !carrinho.length) return

    const batch = writeBatch(db)
    let temEscrita = false

    catalogo.forEach((item) => {
      const eventos = []
      carrinho.forEach((c) => {
        if (c.itemId !== item.id) return
        if (c.status === STATUS.RECEBIDO) {
          eventos.push({
            tipo: 'compra',
            data: c.atualizadoEm,
            quantidade: c.quantidadeNecessaria,
            unidade: normalizarUnidade(c.unidadeNecessaria),
            momento: tsParaMillisOuData(c.atualizadoEm, c.atualizadoEmTs),
          })
        }
        // Leitura de estoque: usa o carimbo próprio (quantidadeAtualEm), que
        // não muda quando o status do pedido muda depois — pedidos antigos
        // (de antes desse carimbo existir) caem no fallback de atualizadoEm
        // enquanto ainda estão ativos, já que nesse caso ele ainda reflete
        // a última vez que o estoque foi mesmo informado.
        if (c.quantidadeAtual != null) {
          const dataLeitura = c.quantidadeAtualEm || (!STATUS_FINAIS.includes(c.status) ? c.atualizadoEm : null)
          if (dataLeitura) {
            eventos.push({
              tipo: 'leitura',
              data: dataLeitura,
              quantidade: c.quantidadeAtual,
              unidade: normalizarUnidade(c.unidadeAtual),
              momento: tsParaMillisOuData(dataLeitura, c.quantidadeAtualEmTs),
            })
          }
        }
      })
      if (!eventos.length) return

      eventos.sort((a, b) => a.momento - b.momento)
      const novos = eventos.filter((ev) => ev.momento > (item.consumoUltimoEventoEm ?? -Infinity))
      if (!novos.length) return

      const patch = reconciliarEventosDoItem(item, novos)
      if (patch) {
        batch.update(doc(db, 'catalogo', item.id), patch)
        temEscrita = true
      }
    })

    if (temEscrita) batch.commit().catch((e) => console.error('Reconciliação de consumo médio falhou:', e))
  }, [isAdmin, catalogo, carrinho])

  async function login(email, senha) {
    setAuthError(null)
    try {
      await signInWithEmailAndPassword(auth, email, senha)
    } catch (e) {
      setAuthError(traduzErroFirebase(e.code))
    }
  }

  function logout() {
    signOut(auth)
  }

  function listaAtiva() {
    return carrinho
      .filter((c) => c.filial === filial && !STATUS_FINAIS.includes(c.status))
      .map((c) => ({ ...c, item: catalogo.find((i) => i.id === c.itemId) }))
      .sort((a, b) => pesoPrioridade(a) - pesoPrioridade(b))
  }

  function historico() {
    return carrinho
      .filter((c) => c.filial === filial && STATUS_FINAIS.includes(c.status))
      .map((c) => ({ ...c, item: catalogo.find((i) => i.id === c.itemId) }))
      .sort((a, b) => {
        // atualizadoEmTs (serverTimestamp) dá a ordem exata dentro do mesmo
        // dia. Enquanto a escrita ainda não foi confirmada pelo servidor ele
        // vem null — nesse caso cai pro fallback pela data (string
        // 'YYYY-MM-DD', comparável direto).
        const tsA = tsParaMillis(a.atualizadoEmTs)
        const tsB = tsParaMillis(b.atualizadoEmTs)
        if (tsA !== null && tsB !== null) return tsB - tsA
        if (a.atualizadoEm !== b.atualizadoEm) return a.atualizadoEm < b.atualizadoEm ? 1 : -1
        return 0
      })
  }

  function catalogoDaFilial() {
    return catalogo.filter((i) => i.filial === filial && categoriasPermitidas.includes(i.categoria))
  }

  // Fornecedores cadastrados de propósito (lista global) + quaisquer nomes já
  // usados em itens do catálogo desta filial que ainda não tenham sido
  // formalmente cadastrados (compatibilidade com dados antigos).
  function fornecedoresDaFilial() {
    const set = new Set(fornecedores.map((f) => f.nome))
    catalogoDaFilial().forEach((i) => {
      if (i.fornecedorPadrao) set.add(i.fornecedorPadrao)
    })
    return Array.from(set).sort((a, b) => a.localeCompare(b))
  }

  // Envolve uma escrita no Firestore com feedback visual: toast discreto de
  // sucesso (quando `mensagemSucesso` é informada) e toast de erro — com
  // mensagem amigável — se a escrita falhar (ex.: sem conexão). O erro é
  // relançado depois de exibido, para que a tela que chamou a função não
  // prossiga como se tivesse dado certo (ex.: não fecha um formulário).
  async function comFeedback(executar, mensagemSucesso) {
    try {
      const resultado = await executar()
      if (mensagemSucesso) showSuccess(mensagemSucesso)
      return resultado
    } catch (e) {
      console.error(e)
      showError(traduzErroEscrita(e))
      throw e
    }
  }

  // Cadastra um fornecedor novo na lista global, evitando duplicar (por
  // nome, sem diferenciar maiúsculas/minúsculas). Se já existir, apenas
  // devolve o nome como está cadastrado.
  async function cadastrarFornecedor(nome) {
    const nomeLimpo = nome.trim()
    if (!nomeLimpo) return nomeLimpo
    const existente = fornecedores.find((f) => f.nome.toLowerCase() === nomeLimpo.toLowerCase())
    if (existente) return existente.nome
    return comFeedback(async () => {
      await addDoc(collection(db, 'fornecedores'), { nome: nomeLimpo })
      return nomeLimpo
    }, 'Fornecedor salvo ✓')
  }

  // Renomeia um fornecedor cadastrado e propaga o nome novo pra tudo que já
  // usa o nome antigo — diferente de excluir (que não mexe nos produtos),
  // aqui o objetivo é trocar o nome em todo lugar de uma vez: o cadastro
  // (fornecedores), o fornecedor padrão de cada produto no catálogo
  // (catalogo.fornecedorPadrao) e o fornecedor usado em cada pedido, ativo
  // ou já no histórico (carrinho.fornecedorUsado). catalogo/carrinho já
  // estão carregados por completo (admin não é travado em filial), então dá
  // pra montar o lote sem precisar de outra consulta ao Firestore.
  async function editarFornecedor(fornecedorId, nomeNovo) {
    const nomeLimpo = nomeNovo.trim()
    if (!nomeLimpo) return
    const atual = fornecedores.find((f) => f.id === fornecedorId)
    if (!atual || atual.nome === nomeLimpo) return
    const duplicado = fornecedores.find(
      (f) => f.id !== fornecedorId && f.nome.toLowerCase() === nomeLimpo.toLowerCase()
    )
    if (duplicado) {
      showError(`Já existe um fornecedor cadastrado como "${duplicado.nome}".`)
      return
    }
    return comFeedback(async () => {
      const batch = writeBatch(db)
      batch.update(doc(db, 'fornecedores', fornecedorId), { nome: nomeLimpo })
      catalogo
        .filter((i) => i.fornecedorPadrao === atual.nome)
        .forEach((i) => batch.update(doc(db, 'catalogo', i.id), { fornecedorPadrao: nomeLimpo }))
      carrinho
        .filter((c) => c.fornecedorUsado === atual.nome)
        .forEach((c) => batch.update(doc(db, 'carrinho', c.id), { fornecedorUsado: nomeLimpo }))
      await batch.commit()
    }, 'Fornecedor renomeado ✓')
  }

  // Remove um fornecedor da lista de cadastrados. Não mexe nos produtos que
  // já usam esse nome — eles continuam com o texto salvo, só deixam de
  // aparecer como sugestão de fornecedor cadastrado.
  async function excluirFornecedor(fornecedorId) {
    return comFeedback(
      () => deleteDoc(doc(db, 'fornecedores', fornecedorId)),
      'Fornecedor excluído ✓'
    )
  }

  async function atualizarStatus(carrinhoId, novoStatus) {
    return comFeedback(
      () =>
        updateDoc(doc(db, 'carrinho', carrinhoId), {
          status: novoStatus,
          atualizadoPor: usuarioAtual?.nome ?? '—',
          atualizadoEm: new Date().toISOString().slice(0, 10),
          atualizadoEmTs: serverTimestamp(),
        }),
      'Status salvo ✓'
    )
  }

  async function trocarFornecedorUsado(carrinhoId, fornecedor) {
    return comFeedback(
      () => updateDoc(doc(db, 'carrinho', carrinhoId), { fornecedorUsado: fornecedor }),
      'Salvo ✓'
    )
  }

  // Troca manual do fornecedor na célula do produto (lista da semana). Além
  // de mudar o fornecedor deste pedido, grava o escolhido como fornecedor
  // padrão do produto no catálogo — a escolha manual do admin vale "daqui em
  // diante": os próximos pedidos desse produto já nascem com ele
  // (fornecedorUsado = fornecedorPadrao ao criar o pedido). Pedidos que já
  // estão na lista não são mexidos, só o que estiver sendo editado. Escolher
  // "Sem fornecedor" só limpa o do pedido, não apaga o padrão do produto.
  async function definirFornecedorDoPedido(carrinhoId, itemId, fornecedor) {
    return comFeedback(async () => {
      const batch = writeBatch(db)
      batch.update(doc(db, 'carrinho', carrinhoId), { fornecedorUsado: fornecedor })
      const itemCatalogo = catalogo.find((i) => i.id === itemId)
      if (fornecedor && itemCatalogo && (itemCatalogo.fornecedorPadrao || '') !== fornecedor) {
        batch.update(doc(db, 'catalogo', itemId), { fornecedorPadrao: fornecedor })
      }
      await batch.commit()
    }, 'Salvo ✓')
  }

  // Troca manual da unidade de "Qtd Cmp" na célula do produto (lista da
  // semana) — mesma ideia de definirFornecedorDoPedido: além de mudar a
  // unidade deste pedido, grava a escolhida como unidade padrão de compra
  // do produto no catálogo, então o próximo pedido desse produto já nasce
  // nela (ver unidadeNecessariaPadrao em adicionarAoCarrinho e no
  // lançamento de esmaltes), em vez de sempre cair em "UN".
  async function definirUnidadeNecessariaDoPedido(carrinhoId, itemId, unidade) {
    return comFeedback(async () => {
      const batch = writeBatch(db)
      batch.update(doc(db, 'carrinho', carrinhoId), { unidadeNecessaria: unidade })
      const itemCatalogo = catalogo.find((i) => i.id === itemId)
      if (unidade && itemCatalogo && (itemCatalogo.unidadeNecessariaPadrao || 'UN') !== unidade) {
        batch.update(doc(db, 'catalogo', itemId), { unidadeNecessariaPadrao: unidade })
      }
      await batch.commit()
    }, 'Salvo ✓')
  }

  // Troca o PRODUTO de um pedido que já está na lista/carrinho, mantendo
  // quantidade, observações, status etc. — só muda pra qual item do
  // catálogo esse pedido aponta. Serve pro caso do fornecedor mandar outra
  // coisa no lugar do que foi pedido (ex.: pediu Cif, veio Sampolino):
  // em vez de excluir e criar um pedido novo do zero, corrige o produto
  // aqui e o histórico/consumo médio continuam ligados ao pedido original.
  async function trocarProdutoDoCarrinho(carrinhoId, novoItemId) {
    return comFeedback(
      () => updateDoc(doc(db, 'carrinho', carrinhoId), { itemId: novoItemId }),
      'Produto trocado ✓'
    )
  }

  // Atualiza o status de vários itens do carrinho de uma vez só (uma única
  // gravação no Firestore), usada pela seleção múltipla nas telas de lista,
  // fornecedor e histórico.
  async function atualizarStatusEmLote(carrinhoIds, novoStatus) {
    if (!carrinhoIds.length) return
    return comFeedback(() => {
      const batch = writeBatch(db)
      const agora = new Date().toISOString().slice(0, 10)
      carrinhoIds.forEach((id) => {
        batch.update(doc(db, 'carrinho', id), {
          status: novoStatus,
          atualizadoPor: usuarioAtual?.nome ?? '—',
          atualizadoEm: agora,
          atualizadoEmTs: serverTimestamp(),
        })
      })
      return batch.commit()
    }, `Status salvo em ${carrinhoIds.length} ite${carrinhoIds.length > 1 ? 'ns' : 'm'} ✓`)
  }

  // Edita campos livres de um item do carrinho (quantidade, fornecedor usado...)
  async function editarItemCarrinho(carrinhoId, dados) {
    return comFeedback(() => updateDoc(doc(db, 'carrinho', carrinhoId), dados), 'Salvo ✓')
  }

  async function excluirDoCarrinho(carrinhoId) {
    return comFeedback(() => deleteDoc(doc(db, 'carrinho', carrinhoId)), 'Excluído ✓')
  }

  // Versão "crua", sem toast — usada internamente por excluirItemCatalogo
  // para não disparar um toast de sucesso no meio de uma exclusão maior que
  // ainda pode falhar na etapa seguinte.
  async function excluirDoCarrinhoEmLoteCru(carrinhoIds) {
    if (!carrinhoIds.length) return
    const batch = writeBatch(db)
    carrinhoIds.forEach((id) => batch.delete(doc(db, 'carrinho', id)))
    await batch.commit()
  }

  async function excluirDoCarrinhoEmLote(carrinhoIds) {
    if (!carrinhoIds.length) return
    return comFeedback(
      () => excluirDoCarrinhoEmLoteCru(carrinhoIds),
      `${carrinhoIds.length > 1 ? 'Itens excluídos' : 'Item excluído'} ✓`
    )
  }

  async function atualizarItemCatalogo(itemId, dados) {
    return comFeedback(() => updateDoc(doc(db, 'catalogo', itemId), dados), 'Salvo ✓')
  }

  // Exclui um item do catálogo. Se ele já tiver entradas no carrinho
  // (lista ativa ou histórico), remove essas entradas também para não
  // deixar registros "órfãos" apontando pra um item que não existe mais.
  async function excluirItemCatalogo(itemId) {
    const relacionados = carrinho.filter((c) => c.itemId === itemId).map((c) => c.id)
    return comFeedback(async () => {
      if (relacionados.length) {
        await excluirDoCarrinhoEmLoteCru(relacionados)
      }
      await deleteDoc(doc(db, 'catalogo', itemId))
    }, 'Item excluído do catálogo ✓')
  }

  // `solicitacao` = { observacoes, quantidadeAtual, unidadeAtual }. Quantidade
  // a comprar é decisão exclusiva do admin: quando quem pede é o Convidado,
  // ele nunca informa isso (só quanto ele TEM agora, em quantidadeAtual, pra
  // ajudar o admin a decidir depois) — o pedido entra com quantidadeNecessaria
  // zerada. Quando é o próprio admin pedindo (ex.: categorias que ele mesmo
  // cuida, como manicure/cabeleireiro), ele já pode informar a quantidade a
  // comprar direto. De qualquer forma — admin ou convidado — todo pedido
  // novo entra com status "Aguardando Gleison", na mesma fila de aprovação;
  // não existe mais atalho que pule direto pra "Aguardando retorno
  // fornecedor". Prioridade não é mais escolhida manualmente — ver
  // calcularPrioridade.
  //
  // Exceção: o convidado "só esmaltes" (`solicitacao.comQuantidadeCompra`)
  // também informa a quantidade a comprar — mas só em produto da categoria
  // "Esmaltes expositor". Nesse caso o pedido sai com o fornecedor Kapital,
  // que é o que as regras do Firestore exigem pra aceitar quantidade a
  // comprar vinda de convidado.
  async function adicionarAoCarrinho(itemId, quantidadeNecessaria, solicitacao = {}) {
    const item = catalogo.find((i) => i.id === itemId)
    if (!item) return
    const jaEsta = carrinho.find(
      (c) => c.itemId === itemId && c.filial === filial && !STATUS_FINAIS.includes(c.status)
    )
    if (jaEsta) return
    // Estoque atual é obrigatório em todo pedido (qualquer setor, admin ou
    // convidado). O formulário já exige, isto aqui é a trava final.
    if (
      solicitacao.quantidadeAtual === '' ||
      solicitacao.quantidadeAtual === undefined ||
      solicitacao.quantidadeAtual === null
    ) {
      showError('Informe a quantidade em estoque para lançar o pedido.')
      return
    }
    const quantidadeAtual = Math.max(0, Number(solicitacao.quantidadeAtual) || 0)
    const agora = new Date().toISOString().slice(0, 10)
    const convidadoInformaQtd =
      !isAdmin && solicitacao.comQuantidadeCompra === true && item.categoria === CATEGORIA_ESMALTES
    const qtdParaComprar = isAdmin
      ? quantidadeNecessaria || 1
      : convidadoInformaQtd
        ? Math.max(1, Number(quantidadeNecessaria) || 1)
        : 0
    return comFeedback(
      () =>
        addDoc(collection(db, 'carrinho'), {
          itemId,
          filial,
          quantidadeNecessaria: qtdParaComprar,
          // Unidade de compra do produto, aprendida da última vez que o
          // admin trocou manualmente na célula "Qtd Cmp" (ver
          // definirUnidadeNecessariaDoPedido) — sem isso, cai em "UN".
          unidadeNecessaria: item.unidadeNecessariaPadrao || 'UN',
          quantidadeAtual,
          unidadeAtual: quantidadeAtual !== null ? normalizarUnidade(solicitacao.unidadeAtual) : null,
          prioridade: calcularPrioridade(quantidadeAtual),
          observacoes: solicitacao.observacoes || '',
          fornecedorUsado: convidadoInformaQtd ? FORNECEDOR_ESMALTES : item.fornecedorPadrao ?? '',
          status: STATUS.AGUARDANDO_GLEISON,
          atualizadoPor: usuarioAtual?.nome ?? '—',
          atualizadoEm: agora,
          atualizadoEmTs: serverTimestamp(),
          // Carimbo de QUANDO o pedido foi criado, separado do atualizadoEm
          // geral — esse aqui nunca é tocado depois (nem quando o status
          // muda), então a data mostrada na célula do produto fica fixa.
          criadoEm: agora,
          criadoEmTs: serverTimestamp(),
          // Carimbo próprio de QUANDO o estoque foi informado, separado do
          // atualizadoEm geral — esse aqui não é tocado quando o status
          // muda depois (aprovado, recebido...), então o aprendizado do
          // consumo médio sempre sabe a data real da leitura, mesmo depois
          // do pedido virar histórico.
          ...(quantidadeAtual !== null
            ? { quantidadeAtualEm: agora, quantidadeAtualEmTs: serverTimestamp() }
            : {}),
        }),
      'Adicionado à lista ✓'
    )
  }

  // Convidado avisa uma mudança na quantidade em estoque de um produto que
  // já está na lista (pedido enviado). É o "alerta de estoque": não muda
  // status nem quantidade a comprar (isso continua exclusivo do admin), só
  // atualiza quantidadeAtual/unidadeAtual e recalcula a prioridade — se
  // zerou, o item vira Urgente automaticamente. Esse aviso (e o que é dado
  // já na criação do pedido, acima) é a matéria-prima do aprendizado do
  // consumo médio — mas quem lê esse dado e escreve a média aprendida é
  // sempre a sessão do admin (ver o useEffect de reconciliação), nunca esta
  // função: o convidado só grava no carrinho, como já fazia. Os campos
  // gravados aqui precisam bater com a lista de campos permitidos na regra
  // de update do carrinho em firestore.rules.
  async function atualizarEstoqueConvidado(carrinhoId, { quantidadeAtual, unidadeAtual }) {
    const valor = Math.max(0, Number(quantidadeAtual) || 0)
    const agora = new Date().toISOString().slice(0, 10)
    return comFeedback(
      () =>
        updateDoc(doc(db, 'carrinho', carrinhoId), {
          quantidadeAtual: valor,
          unidadeAtual: normalizarUnidade(unidadeAtual),
          prioridade: calcularPrioridade(valor),
          atualizadoPor: usuarioAtual?.nome ?? '—',
          atualizadoEm: agora,
          atualizadoEmTs: serverTimestamp(),
          quantidadeAtualEm: agora,
          quantidadeAtualEmTs: serverTimestamp(),
        }),
      'Estoque atualizado ✓'
    )
  }

  // Admin corrige o estoque que o funcionário informou (ex.: digitou errado,
  // ou o valor mudou desde então). Igual ao aviso do convidado, recalcula a
  // prioridade (estoque zerado => Urgente) e atualiza quantidadeAtualEm (pra
  // o consumo médio saber quando essa leitura vale). Mas, diferente do aviso
  // do convidado, NÃO mexe em atualizadoEm/atualizadoEmTs nem em criadoEm —
  // uma correção de estoque não pode fazer o pedido "mudar de data" (nem a
  // exibida na célula, nem a usada no PDF/filtro de fornecedor).
  async function alterarEstoqueAdmin(carrinhoId, { quantidadeAtual, unidadeAtual }) {
    const valor = quantidadeAtual === '' || quantidadeAtual === null ? null : Math.max(0, Number(quantidadeAtual) || 0)
    const agora = new Date().toISOString().slice(0, 10)
    return comFeedback(
      () =>
        updateDoc(doc(db, 'carrinho', carrinhoId), {
          quantidadeAtual: valor,
          unidadeAtual: normalizarUnidade(unidadeAtual),
          prioridade: calcularPrioridade(valor),
          quantidadeAtualEm: agora,
          quantidadeAtualEmTs: serverTimestamp(),
        }),
      'Estoque atualizado ✓'
    )
  }

  // Troca manual da unidade do "Estq" na célula do produto (lista da
  // semana) — mesma ideia de definirUnidadeNecessariaDoPedido: além de mudar
  // a unidade deste pedido, grava a escolhida como unidade padrão de estoque
  // do produto no catálogo (unidadeAtualPadrao), fixando-a pra esse produto.
  // Como o Consumo Médio só aprende comparando leituras na MESMA unidade (ver
  // reconciliarEventosDoItem) e é ele quem decide em que unidade o consumo
  // fica exposto, fixar a unidade do estoque aqui também fixa a unidade do
  // consumo médio (consumoMedioUnidade) — mesmo que essa unidade fique
  // diferente da de "Qtd Cmp", que é fixada à parte e não tem relação com
  // esta.
  async function fixarUnidadeEstoque(carrinhoId, itemId, unidade) {
    return comFeedback(async () => {
      const batch = writeBatch(db)
      batch.update(doc(db, 'carrinho', carrinhoId), { unidadeAtual: unidade })
      const itemCatalogo = catalogo.find((i) => i.id === itemId)
      if (unidade && itemCatalogo) {
        const dadosCatalogo = {}
        if ((itemCatalogo.unidadeAtualPadrao || 'UN') !== unidade) {
          dadosCatalogo.unidadeAtualPadrao = unidade
        }
        if ((itemCatalogo.consumoMedioUnidade || null) !== unidade) {
          dadosCatalogo.consumoMedioUnidade = unidade
        }
        if (Object.keys(dadosCatalogo).length) {
          batch.update(doc(db, 'catalogo', itemId), dadosCatalogo)
        }
      }
      await batch.commit()
    }, 'Salvo ✓')
  }

  // Cadastra um item novo no catálogo. Como as duas filiais compram os
  // mesmos produtos, o item é criado em todas as filiais de uma vez (um
  // documento por filial, mesmo nome/categoria/fornecedor padrão) — não só
  // na filial selecionada no momento. Devolve o registro da filial atual,
  // pra já abrir o pedido (quantidade/estoque) nela.
  async function cadastrarItem(novoItem) {
    return comFeedback(async () => {
      const batch = writeBatch(db)
      const refsPorFilial = {}
      FILIAIS.forEach((f) => {
        const ref = doc(collection(db, 'catalogo'))
        refsPorFilial[f] = ref
        batch.set(ref, { filial: f, ...novoItem })
      })
      await batch.commit()
      return { id: refsPorFilial[filial].id, filial, ...novoItem }
    }, 'Item cadastrado ✓')
  }

  // Devolve o documento de esmaltes de exposição da filial informada (ou da
  // filial atual, se não passar nenhuma — útil pro admin, que pode estar
  // vendo uma filial diferente da própria). null se ainda não foi salvo nada.
  function esmaltesDaFilial(nomeFilial = filial) {
    return esmaltesExposicao.find((e) => e.id === nomeFilial) || null
  }

  // Salva a lista de esmaltes de exposição da filial atual (a da manicure,
  // ou a que o admin estiver vendo) e já transforma em pedido de compra o
  // que veio com quantidade. `itens` é o array do modal:
  // [{ marca, nome, quantidade }, ...].
  //
  // Duas coisas acontecem, nessa ordem:
  // 1) O documento da filial em esmaltesExposicao é sobrescrito por
  //    inteiro com [{ marca, nome }] — sem quantidade. É o retrato da
  //    vitrine, e continua sendo o que o admin confere no modal dele. A
  //    quantidade fica de fora de propósito: ela é do pedido, não da
  //    vitrine — se ficasse salva, reabrir e salvar de novo pediria tudo
  //    outra vez.
  // 2) Cada esmalte com quantidade > 0 vira um pedido normal: procura (ou
  //    cria) o produto no catálogo da filial, na categoria "Esmaltes
  //    expositor", e cria a entrada no carrinho com o fornecedor Kapital,
  //    status "Aguardando Gleison" e a quantidade que a manicure pediu —
  //    a mesma fila de aprovação de qualquer pedido.
  //    Se o esmalte já tem pedido em aberto na filial, não mexe nele (nem
  //    duplica): o pedido em aberto é do admin, que já pode ter ajustado.
  //
  // Modo `cadastro` (convidado "só esmaltes"): `itens` traz só os esmaltes
  // NOVOS. A vitrine já salva da filial é mantida e os novos entram nela
  // (em vez de ser substituída só por eles), e todo esmalte novo vira produto
  // no catálogo, pra passar a aparecer na lista da página. Nunca cria pedido
  // de compra (mesmo que venha quantidade): pedir é feito pela lista, com o
  // "+" do esmalte.
  //
  // Devolve { criados, cadastrados, jaNaLista } pra tela poder avisar. As
  // escritas dos pedidos vão em lotes pequenos e em paralelo: as regras do
  // Firestore consultam o perfil do usuário a cada escrita e há um teto de
  // consultas por lote, então um lote grande demais seria recusado. Se algum
  // lote falhar, salvar de novo é seguro — o que já foi criado é reconhecido
  // e pulado.
  async function salvarEsmaltesExposicao(itens, { cadastro = false } = {}) {
    const chaveVitrine = (it) => `${normalizar(it.marca)}|${normalizar(it.nome)}`
    let vitrine = itens.map(({ marca, nome }) => ({ marca, nome }))
    if (cadastro) {
      const atuais = esmaltesDaFilial()?.itens ?? []
      const vistos = new Set(atuais.map(chaveVitrine))
      const novos = vitrine.filter((v) => {
        const chave = chaveVitrine(v)
        if (vistos.has(chave)) return false
        vistos.add(chave)
        return true
      })
      vitrine = [...atuais, ...novos]
    }
    const agora = new Date().toISOString().slice(0, 10)
    const autor = usuarioAtual?.nome ?? '—'

    const comQuantidade = itens.map((it) => ({
      ...it,
      quantidade: cadastro ? 0 : Math.max(0, Number(it.quantidade) || 0),
      // Estoque atual do esmalte — obrigatório em todo pedido novo (0 vale).
      estoque: it.estoque === '' || it.estoque == null ? null : Math.max(0, Number(it.estoque) || 0),
    }))
    if (!cadastro && comQuantidade.some((it) => it.quantidade > 0 && it.estoque === null)) {
      showError('Informe o estoque atual de todos os esmaltes que vão para a lista de compras.')
      return null
    }
    const paraProcessar = cadastro ? comQuantidade : comQuantidade.filter((it) => it.quantidade > 0)

    // Junta o que foi digitado duas vezes (mesma marca+nome) numa entrada só
    // — somando as quantidades — pra não brigar com a checagem de duplicidade.
    const porProduto = new Map()
    paraProcessar.forEach((it) => {
      const nomeProduto = nomeProdutoEsmalte(it.marca, it.nome)
      const chave = normalizar(nomeProduto)
      const atual = porProduto.get(chave)
      if (atual) {
        atual.quantidade += it.quantidade
        if (atual.estoque === null) atual.estoque = it.estoque
      } else porProduto.set(chave, { nomeProduto, quantidade: it.quantidade, estoque: it.estoque })
    })

    const resultado = await comFeedback(async () => {
      await setDoc(doc(db, 'esmaltesExposicao', filial), {
        itens: vitrine,
        atualizadoPor: autor,
        atualizadoEm: agora,
        atualizadoEmTs: serverTimestamp(),
      })

      const tarefas = []
      let jaNaLista = 0
      porProduto.forEach(({ nomeProduto, quantidade, estoque }, chave) => {
        const itemExistente = catalogo.find(
          (i) => i.filial === filial && i.categoria === CATEGORIA_ESMALTES && normalizar(i.nome) === chave
        )
        if (itemExistente) {
          if (quantidade === 0) return // já cadastrado e sem pedido novo: nada a fazer
          const pedidoAberto = carrinho.some(
            (c) => c.itemId === itemExistente.id && c.filial === filial && !STATUS_FINAIS.includes(c.status)
          )
          if (pedidoAberto) {
            jaNaLista += 1
            return
          }
        }
        tarefas.push({ itemExistente, nomeProduto, quantidade, estoque })
      })

      const TAMANHO_LOTE = 4 // 4 esmaltes = até 8 escritas (produto + pedido) por lote
      const lotes = []
      for (let i = 0; i < tarefas.length; i += TAMANHO_LOTE) {
        const batch = writeBatch(db)
        tarefas.slice(i, i + TAMANHO_LOTE).forEach(({ itemExistente, nomeProduto, quantidade, estoque }) => {
          let itemId = itemExistente?.id
          if (!itemId) {
            const refItem = doc(collection(db, 'catalogo'))
            itemId = refItem.id
            batch.set(refItem, {
              filial,
              nome: nomeProduto,
              categoria: CATEGORIA_ESMALTES,
              fornecedorPadrao: FORNECEDOR_ESMALTES,
            })
          }
          if (quantidade <= 0) return // só cadastro do esmalte, sem pedido
          batch.set(doc(collection(db, 'carrinho')), {
            itemId,
            filial,
            quantidadeNecessaria: quantidade,
            unidadeNecessaria: itemExistente?.unidadeNecessariaPadrao || 'UN',
            quantidadeAtual: estoque,
            unidadeAtual: estoque !== null ? 'UN' : null,
            prioridade: calcularPrioridade(estoque),
            observacoes: '',
            fornecedorUsado: FORNECEDOR_ESMALTES,
            status: STATUS.AGUARDANDO_GLEISON,
            atualizadoPor: autor,
            atualizadoEm: agora,
            atualizadoEmTs: serverTimestamp(),
            criadoEm: agora,
            criadoEmTs: serverTimestamp(),
            ...(estoque !== null ? { quantidadeAtualEm: agora, quantidadeAtualEmTs: serverTimestamp() } : {}),
          })
        })
        lotes.push(batch.commit())
      }
      await Promise.all(lotes)

      return {
        criados: tarefas.filter((t) => t.quantidade > 0).length,
        cadastrados: tarefas.filter((t) => !t.itemExistente).length,
        jaNaLista,
      }
    })

    const partes = [
      cadastro
        ? resultado.cadastrados === 1
          ? 'Esmalte cadastrado ✓'
          : 'Esmaltes cadastrados ✓'
        : 'Lista de esmaltes salva ✓',
    ]
    if (resultado.criados > 0) {
      partes.push(`${resultado.criados} ${resultado.criados === 1 ? 'pedido criado' : 'pedidos criados'}`)
    }
    if (resultado.jaNaLista > 0) {
      partes.push(`${resultado.jaNaLista} já ${resultado.jaNaLista === 1 ? 'estava' : 'estavam'} na lista de compras`)
    }
    showSuccess(partes.join(' · '))
    return resultado
  }

  // Só admin pode trocar de filial pelo seletor — convidado fica travado na
  // filial do próprio perfil (ver efeito acima). Fica aqui como uma segunda
  // trava, independente da UI esconder ou não o seletor pra ele.
  function setFilial(novaFilial) {
    if (!isAdmin) return
    setFilialState(novaFilial)
  }

  const value = {
    usuarioAtual,
    isAdmin,
    categoriasPermitidas,
    login,
    logout,
    authError,
    carregandoAuth,
    filial,
    setFilial,
    filiais: FILIAIS,
    catalogo,
    catalogoDaFilial,
    fornecedores,
    fornecedoresDaFilial,
    cadastrarFornecedor,
    editarFornecedor,
    excluirFornecedor,
    carrinho,
    listaAtiva,
    historico,
    atualizarStatus,
    atualizarStatusEmLote,
    trocarFornecedorUsado,
    definirFornecedorDoPedido,
    definirUnidadeNecessariaDoPedido,
    trocarProdutoDoCarrinho,
    editarItemCarrinho,
    excluirDoCarrinho,
    excluirDoCarrinhoEmLote,
    adicionarAoCarrinho,
    atualizarEstoqueConvidado,
    alterarEstoqueAdmin,
    fixarUnidadeEstoque,
    cadastrarItem,
    atualizarItemCatalogo,
    excluirItemCatalogo,
    esmaltesExposicao,
    esmaltesDaFilial,
    salvarEsmaltesExposicao,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

function traduzErroFirebase(code) {
  switch (code) {
    case 'auth/invalid-email':
      return 'E-mail inválido.'
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return 'E-mail ou senha incorretos.'
    case 'auth/too-many-requests':
      return 'Muitas tentativas. Aguarde um pouco e tente de novo.'
    default:
      return 'Não foi possível entrar. Tente novamente.'
  }
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp precisa estar dentro de <AppProvider>')
  return ctx
}
