import { createContext, useContext, useEffect, useState } from 'react'

const ThemeContext = createContext(null)

const CHAVE_STORAGE = 'compras-studio-tema'

// Modo escuro é 100% manual: não olha prefers-color-scheme do sistema em
// nenhum momento, nem na primeira carga nem depois. Uma vez escolhido,
// fica exatamente como a pessoa deixou (persistido no localStorage) até
// que ela mesma troque de novo.
function lerTemaSalvo() {
  const salvo = localStorage.getItem(CHAVE_STORAGE)
  return salvo === 'escuro' ? 'escuro' : 'claro'
}

export function ThemeProvider({ children }) {
  const [tema, setTema] = useState(lerTemaSalvo)

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', tema)
    localStorage.setItem(CHAVE_STORAGE, tema)
  }, [tema])

  function alternarTema() {
    setTema((atual) => (atual === 'escuro' ? 'claro' : 'escuro'))
  }

  return (
    <ThemeContext.Provider value={{ tema, alternarTema }}>{children}</ThemeContext.Provider>
  )
}

export function useTheme() {
  const ctx = useContext(ThemeContext)
  if (!ctx) throw new Error('useTheme precisa estar dentro de <ThemeProvider>')
  return ctx
}
