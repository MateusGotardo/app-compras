import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'

const ConfirmContext = createContext(null)

export function ConfirmProvider({ children }) {
  const [pedido, setPedido] = useState(null)
  const resolverRef = useRef(null)
  const confirmBtnRef = useRef(null)

  const confirmar = useCallback((mensagem, opcoes = {}) => {
    return new Promise((resolve) => {
      resolverRef.current = resolve
      setPedido({
        mensagem,
        titulo: opcoes.titulo ?? 'Confirmar',
        textoConfirmar: opcoes.textoConfirmar ?? 'Remover',
        textoCancelar: opcoes.textoCancelar ?? 'Cancelar',
        variante: opcoes.variante ?? 'perigo',
      })
    })
  }, [])

  const responder = useCallback((resultado) => {
    resolverRef.current?.(resultado)
    resolverRef.current = null
    setPedido(null)
  }, [])

  useEffect(() => {
    if (pedido) confirmBtnRef.current?.focus()
  }, [pedido])

  useEffect(() => {
    if (!pedido) return
    function aoTeclar(e) {
      if (e.key === 'Escape') responder(false)
      if (e.key === 'Enter') responder(true)
    }
    document.addEventListener('keydown', aoTeclar)
    return () => document.removeEventListener('keydown', aoTeclar)
  }, [pedido, responder])

  return (
    <ConfirmContext.Provider value={{ confirmar }}>
      {children}
      {pedido && (
        <div className="confirm-overlay" onClick={() => responder(false)}>
          <div
            className="confirm-dialog"
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="confirm-titulo"
            aria-describedby="confirm-mensagem"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 id="confirm-titulo" className="confirm-titulo">
              {pedido.titulo}
            </h2>
            <p id="confirm-mensagem" className="confirm-mensagem">
              {pedido.mensagem}
            </p>
            <div className="confirm-acoes">
              <button className="btn btn-secondary" onClick={() => responder(false)}>
                {pedido.textoCancelar}
              </button>
              <button
                ref={confirmBtnRef}
                className={`btn btn-confirm-${pedido.variante}`}
                onClick={() => responder(true)}
              >
                {pedido.textoConfirmar}
              </button>
            </div>
          </div>
        </div>
      )}
    </ConfirmContext.Provider>
  )
}

export function useConfirm() {
  const ctx = useContext(ConfirmContext)
  if (!ctx) throw new Error('useConfirm precisa estar dentro de <ConfirmProvider>')
  return ctx.confirmar
}
