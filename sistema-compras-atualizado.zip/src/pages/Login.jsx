import { useState } from 'react'
import { useApp } from '../context/AppContext'

export default function Login() {
  const { login, authError } = useApp()
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')
  const [enviando, setEnviando] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setEnviando(true)
    await login(email, senha)
    setEnviando(false)
  }

  return (
    <div className="login-screen">
      <h1 className="login-title">Compras Studio</h1>
      <p className="login-sub">Entre com o e-mail e senha cadastrados.</p>

      <form onSubmit={handleSubmit}>
        <div className="field">
          <label>E-mail</label>
          <input
            type="email"
            autoComplete="username"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="field">
          <label>Senha</label>
          <input
            type="password"
            autoComplete="current-password"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            required
          />
        </div>
        {authError && (
          <p style={{ color: 'var(--danger-ink)', fontSize: 13, marginTop: -6, marginBottom: 14 }}>
            {authError}
          </p>
        )}
        <button className="btn btn-primary" type="submit" disabled={enviando}>
          {enviando ? 'Entrando...' : 'Entrar'}
        </button>
      </form>
    </div>
  )
}
