import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { useConfirm } from '../context/ConfirmContext'
import ItemRow from '../components/ItemRow'
import SelectionBar from '../components/SelectionBar'

export default function ListaAtiva() {
  const { listaAtiva, filial, isAdmin, atualizarStatusEmLote, excluirDoCarrinho, excluirDoCarrinhoEmLote } =
    useApp()
  const confirmar = useConfirm()
  const itens = listaAtiva()

  const [modoSelecao, setModoSelecao] = useState(false)
  const [selecionados, setSelecionados] = useState([])

  function toggleSelecionado(id) {
    setSelecionados((atual) => (atual.includes(id) ? atual.filter((x) => x !== id) : [...atual, id]))
  }

  function sairModoSelecao() {
    setModoSelecao(false)
    setSelecionados([])
  }

  async function aplicarStatusEmLote(novoStatus) {
    await atualizarStatusEmLote(selecionados, novoStatus)
    sairModoSelecao()
  }

  async function excluirSelecionados() {
    if (!(await confirmar(`Remover ${selecionados.length} item(ns) da lista?`))) return
    await excluirDoCarrinhoEmLote(selecionados)
    sairModoSelecao()
  }

  const porCategoria = itens.reduce((acc, c) => {
    const cat = c.item?.categoria ?? 'Outros'
    acc[cat] = acc[cat] || []
    acc[cat].push(c)
    return acc
  }, {})
  // Ordem alfabética por nome do produto dentro de cada área, mesmo critério
  // usado no Catálogo e na aba de Fornecedores.
  Object.values(porCategoria).forEach((lista) =>
    lista.sort((a, b) => (a.item?.nome ?? '').localeCompare(b.item?.nome ?? '', 'pt-BR'))
  )

  const categorias = Object.keys(porCategoria)

  return (
    <div className="content">
      <div className="page-title-row">
        <h1 className="page-title">Lista ativa — {filial}</h1>
        {isAdmin && itens.length > 0 && (
          <button className="btn-link" onClick={() => (modoSelecao ? sairModoSelecao() : setModoSelecao(true))}>
            {modoSelecao ? 'Cancelar' : 'Selecionar vários'}
          </button>
        )}
      </div>

      {modoSelecao && (
        <div className="select-all-row">
          <button className="btn-link" onClick={() => setSelecionados(itens.map((i) => i.id))}>
            Selecionar todos
          </button>
          <button className="btn-link" onClick={() => setSelecionados([])}>
            Limpar
          </button>
        </div>
      )}

      {categorias.length === 0 && (
        <div className="empty-state">
          <h3>Nada pra comprar por aqui</h3>
          <p>Adicione itens pelo Catálogo quando precisar de algo.</p>
        </div>
      )}

      {categorias.map((cat) => (
        <div key={cat}>
          <h2 className="category-heading">{cat}</h2>
          {porCategoria[cat].map((c) => (
            <ItemRow
              key={c.id}
              carrinhoItem={c}
              selecionavel={modoSelecao}
              selecionado={selecionados.includes(c.id)}
              onToggleSelecionado={toggleSelecionado}
              onExcluir={excluirDoCarrinho}
            />
          ))}
        </div>
      ))}

      {modoSelecao && selecionados.length > 0 && (
        <SelectionBar
          count={selecionados.length}
          onAplicarStatus={aplicarStatusEmLote}
          onExcluir={excluirSelecionados}
          onLimpar={() => setSelecionados([])}
        />
      )}
    </div>
  )
}
