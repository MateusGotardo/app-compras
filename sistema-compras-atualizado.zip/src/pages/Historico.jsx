import { useEffect, useState } from 'react'
import { useApp } from '../context/AppContext'
import { useConfirm } from '../context/ConfirmContext'
import { CATEGORIAS } from '../data/mockData'
import ItemRow from '../components/ItemRow'
import SelectionBar from '../components/SelectionBar'

// Busca sem acento nem diferença de maiúscula/minúscula.
function normalizarBusca(texto) {
  return (texto || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
}

// Formata 'YYYY-MM-DD' pra 'DD/MM/YYYY'. Mantém o texto como está se não
// vier nesse formato (ex.: registros antigos sem data).
function formatarData(iso) {
  if (!iso) return 'Sem data'
  const partes = iso.split('-')
  if (partes.length !== 3) return iso
  const [ano, mes, dia] = partes
  return `${dia}/${mes}/${ano}`
}

export default function Historico() {
  const {
    historico,
    fornecedoresDaFilial,
    filial,
    isAdmin,
    atualizarStatusEmLote,
    excluirDoCarrinho,
    excluirDoCarrinhoEmLote,
  } = useApp()
  const confirmar = useConfirm()
  const fornecedores = fornecedoresDaFilial()
  const [filtroFornecedor, setFiltroFornecedor] = useState('Todos')
  const [filtroCategoria, setFiltroCategoria] = useState('Todas')
  const [filtroBusca, setFiltroBusca] = useState('')
  // Período pelo dia em que o registro foi atualizado (YYYY-MM-DD, o mesmo
  // formato de atualizadoEm — dá pra comparar como texto).
  const [dataDe, setDataDe] = useState('')
  const [dataAte, setDataAte] = useState('')
  const [modoSelecao, setModoSelecao] = useState(false)
  const [selecionados, setSelecionados] = useState([])

  // A lista fica escondida até a pessoa escolher pelo menos um filtro —
  // o histórico cresce sem parar, e mostrar tudo de cara deixava a tela
  // pesada e difícil de achar o que interessa.
  const buscaTexto = normalizarBusca(filtroBusca)
  const filtrosAtivos =
    filtroFornecedor !== 'Todos' ||
    filtroCategoria !== 'Todas' ||
    buscaTexto !== '' ||
    dataDe !== '' ||
    dataAte !== ''

  // Todos os filtros combinam com "E": só aparece o que bate com tudo que
  // estiver preenchido ao mesmo tempo.
  const itens = filtrosAtivos
    ? historico().filter(
        (c) =>
          (filtroFornecedor === 'Todos' || c.fornecedorUsado === filtroFornecedor) &&
          (filtroCategoria === 'Todas' || c.item?.categoria === filtroCategoria) &&
          (buscaTexto === '' || normalizarBusca(c.item?.nome).includes(buscaTexto)) &&
          (dataDe === '' || (c.atualizadoEm && c.atualizadoEm >= dataDe)) &&
          (dataAte === '' || (c.atualizadoEm && c.atualizadoEm <= dataAte))
      )
    : []

  function limparFiltros() {
    setFiltroFornecedor('Todos')
    setFiltroCategoria('Todas')
    setFiltroBusca('')
    setDataDe('')
    setDataAte('')
  }

  // Sem filtro, não há lista — então também não faz sentido continuar no
  // modo de seleção com itens que sumiram da tela.
  useEffect(() => {
    if (!filtrosAtivos) {
      setModoSelecao(false)
      setSelecionados([])
    }
  }, [filtrosAtivos])

  // historico() já vem ordenado por atualizadoEm decrescente (mais recente
  // primeiro); aqui só agrupamos em seções por data, mantendo essa ordem
  // entre as datas — dentro de cada data, os produtos ficam em ordem
  // alfabética, mesmo critério usado no resto do programa.
  const gruposPorData = itens.reduce((acc, c) => {
    const data = c.atualizadoEm || 'Sem data'
    acc[data] = acc[data] || []
    acc[data].push(c)
    return acc
  }, {})
  Object.values(gruposPorData).forEach((lista) =>
    lista.sort((a, b) => (a.item?.nome ?? '').localeCompare(b.item?.nome ?? '', 'pt-BR'))
  )
  const datasOrdenadas = Object.keys(gruposPorData).sort((a, b) => (a < b ? 1 : -1))

  function toggleSelecionado(id) {
    setSelecionados((atual) => (atual.includes(id) ? atual.filter((x) => x !== id) : [...atual, id]))
  }

  function sairModoSelecao() {
    setModoSelecao(false)
    setSelecionados([])
  }

  async function aplicarStatusEmLote(novoStatus) {
    // Ex.: selecionar itens marcados como "Recebido" por engano e voltar
    // pra "Aguardando retorno fornecedor" — eles somem daqui e reaparecem
    // na Lista ativa automaticamente.
    await atualizarStatusEmLote(selecionados, novoStatus)
    sairModoSelecao()
  }

  async function excluirSelecionados() {
    const ok = await confirmar(
      `Excluir ${selecionados.length} registro(s) do histórico? Essa ação não pode ser desfeita.`
    )
    if (!ok) return
    await excluirDoCarrinhoEmLote(selecionados)
    sairModoSelecao()
  }

  return (
    <div className="content">
      <div className="page-title-row">
        <h1 className="page-title">Histórico — {filial}</h1>
        {isAdmin && filtrosAtivos && itens.length > 0 && (
          <button className="btn-link" onClick={() => (modoSelecao ? sairModoSelecao() : setModoSelecao(true))}>
            {modoSelecao ? 'Cancelar' : 'Selecionar vários'}
          </button>
        )}
      </div>

      <div className="filtros-historico">
        <div className="field">
          <label>Fornecedor</label>
          <select value={filtroFornecedor} onChange={(e) => setFiltroFornecedor(e.target.value)}>
            <option>Todos</option>
            {fornecedores.map((f) => (
              <option key={f}>{f}</option>
            ))}
          </select>
        </div>

        <div className="field">
          <label>Categoria</label>
          <select value={filtroCategoria} onChange={(e) => setFiltroCategoria(e.target.value)}>
            <option>Todas</option>
            {CATEGORIAS.map((cat) => (
              <option key={cat}>{cat}</option>
            ))}
          </select>
        </div>

        <div className="field filtros-historico-busca">
          <label>Produto</label>
          <input
            type="search"
            placeholder="Buscar pelo nome..."
            value={filtroBusca}
            onChange={(e) => setFiltroBusca(e.target.value)}
          />
        </div>

        <div className="field filtros-historico-data">
          <label>De</label>
          <input type="date" value={dataDe} max={dataAte || undefined} onChange={(e) => setDataDe(e.target.value)} />
        </div>

        <div className="field filtros-historico-data">
          <label>Até</label>
          <input type="date" value={dataAte} min={dataDe || undefined} onChange={(e) => setDataAte(e.target.value)} />
        </div>
      </div>

      {filtrosAtivos && (
        <div className="filtros-historico-resumo">
          <span className="item-meta">
            {itens.length} {itens.length === 1 ? 'registro encontrado' : 'registros encontrados'}
          </span>
          <button type="button" className="btn-link" onClick={limparFiltros}>
            Limpar filtros
          </button>
        </div>
      )}

      {isAdmin && filtrosAtivos && (
        <p className="hint-text">
          Dica: se marcou algo como "Recebido" por engano, mude o status aqui — o item volta pra
          Lista ativa sozinho.
        </p>
      )}

      {modoSelecao && (
        <div className="select-all-row">
          <button className="btn-link" onClick={() => setSelecionados(itens.map((i) => i.id))}>
            Selecionar todos
          </button>
          <button className="btn-link" onClick={() => setSelecionados([])}>
            Limpar
          </button>
        </div>
      )}

      {!filtrosAtivos && (
        <div className="empty-state">
          <h3>Escolha um filtro para ver o histórico</h3>
          <p>Filtre por fornecedor, categoria, produto ou período — os registros aparecem assim que você escolher.</p>
        </div>
      )}

      {filtrosAtivos && itens.length === 0 && (
        <div className="empty-state">
          <h3>Nada encontrado</h3>
          <p>Nenhum registro do histórico bate com esses filtros. Itens marcados como Recebido ou Tem no Estoque aparecem aqui.</p>
        </div>
      )}

      {datasOrdenadas.map((data) => (
        <div key={data} className="historico-grupo-data">
          <h2 className="category-heading">{formatarData(data)}</h2>
          {gruposPorData[data].map((c) => (
            <ItemRow
              key={c.id}
              carrinhoItem={c}
              selecionavel={modoSelecao}
              selecionado={selecionados.includes(c.id)}
              onToggleSelecionado={toggleSelecionado}
              onExcluir={excluirDoCarrinho}
            />
          ))}
        </div>
      ))}

      {filtrosAtivos && modoSelecao && selecionados.length > 0 && (
        <SelectionBar
          count={selecionados.length}
          onAplicarStatus={aplicarStatusEmLote}
          onExcluir={excluirSelecionados}
          onLimpar={() => setSelecionados([])}
        />
      )}
    </div>
  )
}
