import { useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import jsPDF from 'jspdf'
import { useApp } from '../context/AppContext'
import { useConfirm } from '../context/ConfirmContext'
import { CATEGORIAS, CATEGORIA_ESMALTES, STATUS, ehAlertaEstoqueCritico, normalizarUnidade } from '../data/mockData'
import ItemRow from '../components/ItemRow'
import SelectionBar from '../components/SelectionBar'
import ConsumoMedioModal from '../components/ConsumoMedioModal'
import FiltrosFornecedorSheet from '../components/FiltrosFornecedorSheet'

const SEM_FORNECEDOR = ''
// Sentinela do chip "Todos" — mostra os pedidos de todos os fornecedores
// juntos, sem filtrar por nenhum específico. Não é um nome de fornecedor de
// verdade, então não bate com nada cadastrado no Firestore.
const TODOS = '__todos__'

// CNPJ de cada filial, usado só na exportação do PDF (cabeçalho do pedido).
const CNPJ_POR_FILIAL = {
  Cachoeira: '24.584.758/0001-82',
  Damha: '07.656.884/0001-86',
}

// Mesmo tratamento de maiúsculas/acentos usado na busca do Catálogo — aqui
// serve pra agrupar corretamente "Açúcar" cadastrado em Copa com "açúcar"
// cadastrado em Estética, por exemplo, mesmo que a digitação tenha variado.
function normalizarNome(texto) {
  return (texto || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
}

// Agrupa os itens pendentes por nome de produto, mantendo cada pedido
// (setor/categoria) como um card independente dentro do grupo — sem somar
// quantidades nem misturar status entre setores diferentes. O grupo só
// existe pra deixar visualmente claro que é o mesmo produto pedido por
// mais de um setor (ex.: café pedido tanto pelo Escritório quanto pela
// Copa), evitando a impressão de duplicidade/erro na lista.
function agruparPorProduto(itens) {
  const mapa = new Map()
  itens.forEach((c) => {
    const chave = normalizarNome(c.item?.nome)
    if (!mapa.has(chave)) mapa.set(chave, [])
    mapa.get(chave).push(c)
  })
  return Array.from(mapa.values())
}

export default function Fornecedor() {
  const {
    listaAtiva,
    fornecedores,
    fornecedoresDaFilial,
    filial,
    isAdmin,
    atualizarStatusEmLote,
    excluirDoCarrinho,
    excluirDoCarrinhoEmLote,
    cadastrarFornecedor,
    editarFornecedor,
    excluirFornecedor,
  } = useApp()

  // "Lista da semana" (visão original, filtrando o pedido atual por
  // fornecedor) e "Fornecedores cadastrados" (gerenciar a lista global —
  // cadastrar/excluir) são dois modos da mesma tela. Fica na URL (?modo=)
  // pra dar pra entrar direto num modo pelo menu hambúrguer do TopBar, de
  // qualquer página do app — é por ele que se entra e sai do modo
  // "gerenciar" agora, então essa página não repete esse controle.
  const [searchParams] = useSearchParams()
  const modo = searchParams.get('modo') === 'gerenciar' ? 'gerenciar' : 'lista'
  // Vindo do Painel (clique numa pendência): ?status= seleciona "Todos" e já
  // filtra por aquele status; ?urgente=1 seleciona "Todos" com "só urgentes"
  // ligado (usado pela pendência "Estoque crítico", que não é um status).
  const filtroStatusInicial = searchParams.get('status') || null
  const filtroUrgenteInicial = searchParams.get('urgente') === '1'
  const [mostrarConsumo, setMostrarConsumo] = useState(false)
  // Mostrar também fornecedores sem pendência agora — antes era um botão de
  // texto próprio ("Ver todos os fornecedores (N)") solto no meio da lista;
  // vive aqui, no ícone de papel ao lado do título, junto com o consumo
  // médio. Só controla a exibição dos chips, nunca a lista de fornecedores
  // cadastrados (cadastrar/excluir já é só pelo menu hambúrguer).
  const [verTodos, setVerTodos] = useState(false)
  // Mesmo cálculo que a "Lista da semana" usa pra decidir os chips — só
  // pra saber se vale a pena mostrar o ícone de "ver todos" (não faz
  // sentido oferecer o toggle se já está tudo visível de qualquer jeito).
  const itensParaChip = listaAtiva()
  const baseParaChip = fornecedoresDaFilial()
  const listaParaChip = itensParaChip.some((c) => !c.fornecedorUsado)
    ? [...baseParaChip, SEM_FORNECEDOR]
    : baseParaChip
  const comPendenciaParaChip = listaParaChip.filter((f) =>
    itensParaChip.some((c) => (c.fornecedorUsado || '') === (f || ''))
  )
  const podeVerTodos =
    comPendenciaParaChip.length > 0 && comPendenciaParaChip.length < listaParaChip.length

  return (
    <div className="content">
      {/* Título e ícones na mesma linha, sempre — o título usa uma fonte
          um pouco menor nesta página (.page-title-compacto) especificamente
          pra "Fornecedores — Nome da filial" nunca quebrar em duas linhas
          no celular e empurrar os ícones pra baixo com um vão vazio do
          lado direito. */}
      <div className="page-title-row">
        <h1 className="page-title page-title-compacto">Fornecedores — {filial}</h1>
        {isAdmin && (
          <div className="fornecedor-icon-toolbar">
            <button
              type="button"
              className="icon-btn"
              title="Consumo médio semanal"
              onClick={() => setMostrarConsumo(true)}
            >
              📊
            </button>
            {modo === 'lista' && podeVerTodos && (
              <button
                type="button"
                className={`icon-btn ${verTodos ? 'icon-btn--ativo' : ''}`}
                title={verTodos ? 'Ver só quem tem pendência' : 'Ver todos os fornecedores'}
                onClick={() => setVerTodos((v) => !v)}
              >
                🧾
              </button>
            )}
          </div>
        )}
      </div>

      <ConsumoMedioModal aberto={mostrarConsumo} onFechar={() => setMostrarConsumo(false)} />

      {modo === 'gerenciar' && isAdmin ? (
        <GerenciarFornecedores
          fornecedores={fornecedores}
          cadastrarFornecedor={cadastrarFornecedor}
          editarFornecedor={editarFornecedor}
          excluirFornecedor={excluirFornecedor}
        />
      ) : (
        <ListaDaSemana
          listaAtiva={listaAtiva}
          fornecedoresDaFilial={fornecedoresDaFilial}
          filial={filial}
          isAdmin={isAdmin}
          atualizarStatusEmLote={atualizarStatusEmLote}
          excluirDoCarrinho={excluirDoCarrinho}
          excluirDoCarrinhoEmLote={excluirDoCarrinhoEmLote}
          verTodos={verTodos}
          filtroStatusInicial={filtroStatusInicial}
          filtroUrgenteInicial={filtroUrgenteInicial}
        />
      )}
    </div>
  )
}

// ---------- Fornecedores cadastrados (cadastrar / editar / excluir) ----------
function GerenciarFornecedores({ fornecedores, cadastrarFornecedor, editarFornecedor, excluirFornecedor }) {
  const [nome, setNome] = useState('')
  const [salvando, setSalvando] = useState(false)
  const confirmar = useConfirm()

  // Fornecedor com o nome em edição no momento (só um por vez) — o nome
  // digitado fica separado do da lista até salvar, pra não mudar o texto na
  // tela a cada tecla.
  const [editandoId, setEditandoId] = useState(null)
  const [nomeEdicao, setNomeEdicao] = useState('')
  const [salvandoEdicao, setSalvandoEdicao] = useState(false)

  async function handleCadastrar(e) {
    e.preventDefault()
    const nomeLimpo = nome.trim()
    if (!nomeLimpo) return
    setSalvando(true)
    await cadastrarFornecedor(nomeLimpo)
    setNome('')
    setSalvando(false)
  }

  function iniciarEdicao(fornecedor) {
    setEditandoId(fornecedor.id)
    setNomeEdicao(fornecedor.nome)
  }

  function cancelarEdicao() {
    setEditandoId(null)
    setNomeEdicao('')
  }

  async function handleSalvarEdicao(e) {
    e.preventDefault()
    const nomeLimpo = nomeEdicao.trim()
    if (!nomeLimpo) return
    setSalvandoEdicao(true)
    try {
      await editarFornecedor(editandoId, nomeLimpo)
      cancelarEdicao()
    } finally {
      setSalvandoEdicao(false)
    }
  }

  async function handleExcluir(fornecedor) {
    const ok = await confirmar(
      `Remover "${fornecedor.nome}" da lista de fornecedores cadastrados? Produtos que já usam esse nome não são afetados, só deixa de aparecer como sugestão.`
    )
    if (!ok) return
    await excluirFornecedor(fornecedor.id)
  }

  return (
    <>
      <form className="novo-fornecedor-form" onSubmit={handleCadastrar}>
        <input
          value={nome}
          onChange={(e) => setNome(e.target.value)}
          placeholder="Nome do novo fornecedor"
        />
        <button className="btn btn-primary" type="submit" disabled={salvando || !nome.trim()}>
          {salvando ? 'Cadastrando...' : 'Cadastrar'}
        </button>
      </form>

      <div className="fornecedor-group-heading">
        <span className="category-heading" style={{ margin: 0, padding: 0, border: 'none' }}>
          Cadastrados
        </span>
        <span className="fornecedor-group-count">
          {fornecedores.length} {fornecedores.length === 1 ? 'fornecedor' : 'fornecedores'}
        </span>
      </div>

      {fornecedores.length === 0 && (
        <div className="empty-state">
          <h3>Nenhum fornecedor cadastrado ainda</h3>
          <p>Cadastre acima ou pelo campo de fornecedor no Catálogo.</p>
        </div>
      )}

      {fornecedores.map((f) =>
        editandoId === f.id ? (
          <form key={f.id} onSubmit={handleSalvarEdicao} className="inline-edit-form">
            <div className="field">
              <label>Nome do fornecedor</label>
              <input
                value={nomeEdicao}
                onChange={(e) => setNomeEdicao(e.target.value)}
                autoFocus
                required
              />
            </div>
            <div className="inline-edit-actions">
              <button className="btn btn-primary" type="submit" disabled={salvandoEdicao || !nomeEdicao.trim()}>
                {salvandoEdicao ? 'Salvando...' : 'Salvar alterações'}
              </button>
              <button className="btn btn-secondary" type="button" onClick={cancelarEdicao} disabled={salvandoEdicao}>
                Cancelar
              </button>
            </div>
          </form>
        ) : (
          <div className="catalog-row" key={f.id}>
            <div className="catalog-row-info">
              <p className="item-name">{f.nome}</p>
            </div>
            <div className="catalog-row-actions">
              <button className="icon-btn" title="Editar nome do fornecedor" onClick={() => iniciarEdicao(f)}>
                ✎
              </button>
              <button className="icon-btn danger" title="Excluir fornecedor" onClick={() => handleExcluir(f)}>
                🗑
              </button>
            </div>
          </div>
        )
      )}
    </>
  )
}

// Menu "⋮" com as ações secundárias da lista (por enquanto só "Selecionar
// vários", mas fica pronto pra receber mais sem empilhar botão na tela).
function AcoesMenu({ onSelecionarVarios }) {
  const [aberto, setAberto] = useState(false)

  return (
    <div className="acoes-menu">
      <button
        type="button"
        className="icon-btn acoes-menu-btn"
        aria-haspopup="true"
        aria-expanded={aberto}
        aria-label="Mais ações"
        onClick={() => setAberto((v) => !v)}
        // Pequeno atraso pra permitir o clique num item antes do menu fechar.
        onBlur={() => setTimeout(() => setAberto(false), 150)}
      >
        ⋮
      </button>
      {aberto && (
        <div className="acoes-menu-lista">
          <button
            type="button"
            className="acoes-menu-item"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => {
              onSelecionarVarios()
              setAberto(false)
            }}
          >
            Selecionar vários
          </button>
        </div>
      )}
    </div>
  )
}

// ---------- Lista da semana ----------
function ListaDaSemana({
  listaAtiva,
  fornecedoresDaFilial,
  filial,
  isAdmin,
  atualizarStatusEmLote,
  excluirDoCarrinho,
  excluirDoCarrinhoEmLote,
  verTodos,
  filtroStatusInicial,
  filtroUrgenteInicial,
}) {
  const todosItens = listaAtiva()
  const fornecedoresBase = fornecedoresDaFilial()
  const temSemFornecedor = todosItens.some((c) => !c.fornecedorUsado)
  // "Sem fornecedor" entra como mais uma opção de filtro, pro admin conseguir
  // ver e organizar os itens que ainda não têm fornecedor definido.
  const fornecedores = temSemFornecedor ? [...fornecedoresBase, SEM_FORNECEDOR] : fornecedoresBase

  // Só entra nos chips por padrão quem tem pelo menos um item pendente agora
  // — é o que importa navegar no dia a dia. O resto (cadastrado mas sem
  // nada pra comprar essa semana) fica escondido, a não ser que "verTodos"
  // (ícone 🧾 lá em cima, ao lado do título) esteja ligado.
  const fornecedoresComPendencia = fornecedores.filter((f) =>
    todosItens.some((c) => (c.fornecedorUsado || '') === (f || ''))
  )
  const semPendenciaNenhuma = fornecedoresComPendencia.length === 0

  const mostrarTodos = verTodos || semPendenciaNenhuma

  // Chegando do Painel com um filtro na URL (?status= ou ?urgente=1), abre
  // direto no chip "Todos" já com esse filtro aplicado. Sem filtro, mantém o
  // comportamento de sempre: primeiro fornecedor com pendência.
  const temFiltroDaUrl = Boolean(filtroStatusInicial || filtroUrgenteInicial)
  const [selecionado, setSelecionado] = useState(() =>
    temFiltroDaUrl ? TODOS : fornecedoresComPendencia[0] ?? fornecedores[0] ?? null
  )
  const [modoSelecao, setModoSelecao] = useState(false)
  const [selecionados, setSelecionados] = useState([])
  const [soUrgentes, setSoUrgentes] = useState(() => Boolean(filtroUrgenteInicial))
  const [busca, setBusca] = useState('')
  const buscaAtiva = busca.trim().length > 0
  // Setores (áreas) selecionados no filtro — pode ser mais de um ao mesmo
  // tempo. Lista vazia = todos os setores.
  const [areasSelecionadas, setAreasSelecionadas] = useState([])
  const [dataFiltro, setDataFiltro] = useState('Todas')
  // Status selecionados no filtro (pode marcar mais de um) — ajuda a não
  // duplicar pedido por engano: o PDF só sai com "Aguardando Gleison", mas a
  // lista na tela mistura todos os status, então dá pra achar sem querer um
  // item que já está "Comprado" ou "Em andamento" e pedir de novo. Lista
  // vazia = todos os status.
  const [statusSelecionados, setStatusSelecionados] = useState(() =>
    filtroStatusInicial ? [filtroStatusInicial] : []
  )
  // Controla a folha (bottom sheet) que reúne setor, status, data e "só
  // urgentes" num lugar só — os filtros em si continuam vivendo nos estados
  // acima, essa flag só decide se a folha está visível.
  const [filtrosAbertos, setFiltrosAbertos] = useState(false)
  const confirmar = useConfirm()

  // Se o fornecedor selecionado não tem mais pendência (ex.: acabou de
  // resolver tudo dele) mas ainda é o que está ativo no filtro, mantém o
  // chip dele visível mesmo com a lista recolhida — senão a seleção fica
  // "invisível" (nenhum chip aceso, mas a lista abaixo ainda filtrada por ele).
  const chipSelecionadoAusente =
    selecionado !== null && selecionado !== TODOS && !fornecedoresComPendencia.includes(selecionado)
  const fornecedoresExibidos = [
    TODOS,
    ...(mostrarTodos
      ? fornecedores
      : chipSelecionadoAusente
      ? [...fornecedoresComPendencia, selecionado]
      : fornecedoresComPendencia),
  ]

  // "Todos" junta os pedidos de todos os fornecedores num só lugar — os
  // filtros de setor/status/data/urgência abaixo continuam funcionando
  // normalmente em cima desse conjunto maior.
  const itens =
    selecionado === TODOS
      ? todosItens
      : todosItens.filter((c) => (c.fornecedorUsado || '') === (selecionado || ''))

  // Rótulo exibido pro fornecedor selecionado (mensagens de busca vazia,
  // título dos filtros etc.) — trata os dois casos especiais: "Todos" e
  // "Sem fornecedor" (string vazia).
  function rotuloFornecedor(f, rotuloVazio = 'Sem fornecedor') {
    if (f === TODOS) return 'Todos'
    return f || rotuloVazio
  }

  // Áreas (setores) que têm pelo menos um item pendente com esse fornecedor
  // — mesma lógica dos chips de fornecedor, só entra na lista quem tem uso,
  // mantendo a ordem fixa de CATEGORIAS.
  const areasDisponiveis = CATEGORIAS.filter((cat) => itens.some((c) => c.item?.categoria === cat))
  // Só vale o que ainda existe nesse fornecedor (um setor selecionado pode
  // ter sumido da lista depois de resolver os pedidos dele).
  const areasFiltro = areasSelecionadas.filter((a) => areasDisponiveis.includes(a))
  const filtrandoPorArea = areasFiltro.length > 0
  const textoAreasFiltro = areasFiltro.join(' + ')

  function toggleArea(area) {
    setAreasSelecionadas((atual) => (atual.includes(area) ? atual.filter((a) => a !== area) : [...atual, area]))
  }
  // Status que têm pelo menos um item pendente com esse fornecedor — mesma
  // lógica dos chips de setor, na ordem em que aparecem no cadastro (STATUS).
  const statusDisponiveis = Object.values(STATUS).filter((st) => itens.some((c) => c.status === st))
  const statusFiltro = statusSelecionados.filter((st) => statusDisponiveis.includes(st))
  const filtrandoPorStatus = statusFiltro.length > 0
  const textoStatusFiltro = statusFiltro.join(' + ')

  function toggleStatus(status) {
    setStatusSelecionados((atual) => (atual.includes(status) ? atual.filter((s) => s !== status) : [...atual, status]))
  }
  // Datas em que os pedidos desse fornecedor foram feitos (criadoEm, que
  // fica fixo mesmo quando o status muda depois — cai pra atualizadoEm só
  // em itens antigos sem esse campo), da mais antiga pra mais recente
  // (só filtro da tela — o PDF usa a data em que foi gerado).
  const datasDisponiveis = Array.from(
    new Set(itens.map((c) => c.criadoEm ?? c.atualizadoEm).filter(Boolean))
  ).sort()
  const itensPorArea = itens.filter(
    (c) =>
      (!filtrandoPorArea || areasFiltro.includes(c.item?.categoria || '')) &&
      (!filtrandoPorStatus || statusFiltro.includes(c.status)) &&
      (dataFiltro === 'Todas' || (c.criadoEm ?? c.atualizadoEm) === dataFiltro)
  )

  // Filtro rápido pra quem vai comprar enxergar de cara só o que é urgente
  // (estoque zerado) dentro do fornecedor (e área, se filtrada) selecionado,
  // sem precisar procurar pela borda vermelha item por item. Só aparece
  // quando tem pelo menos um urgente nesse recorte — senão é um botão sem
  // função na tela.
  const qtdUrgentes = itensPorArea.filter(ehAlertaEstoqueCritico).length
  // Quantos filtros estão ativos ao mesmo tempo — vira o número no badge do
  // botão "Filtros", pra dar pra notar de longe que tem filtro aplicado sem
  // precisar abrir a folha pra conferir.
  const filtrosAtivosCount = [filtrandoPorArea, filtrandoPorStatus, dataFiltro !== 'Todas', soUrgentes].filter(
    Boolean
  ).length
  const temFiltrosDisponiveis =
    areasDisponiveis.length > 1 || statusDisponiveis.length > 1 || datasDisponiveis.length > 1 || qtdUrgentes > 0

  function limparTodosFiltros() {
    setAreasSelecionadas([])
    setStatusSelecionados([])
    setDataFiltro('Todas')
    setSoUrgentes(false)
  }

  const itensFiltradosPorUrgencia = soUrgentes
    ? itensPorArea.filter(ehAlertaEstoqueCritico)
    : itensPorArea
  // Busca por nome do produto dentro do fornecedor selecionado (ex.: achar
  // "limão" dentro da lista do Assaí sem precisar rolar tudo) — mesma
  // normalização usada pra agrupar, então ignora acento e caixa.
  const itensExibidos = buscaAtiva
    ? itensFiltradosPorUrgencia.filter((c) => normalizarNome(c.item?.nome).includes(normalizarNome(busca)))
    : itensFiltradosPorUrgencia
  // Ordem alfabética por nome do produto, igual ao Catálogo e ao PDF.
  const grupos = agruparPorProduto(itensExibidos).sort((a, b) =>
    normalizarNome(a[0].item?.nome).localeCompare(normalizarNome(b[0].item?.nome), 'pt-BR')
  )

  function toggleSelecionado(id) {
    setSelecionados((atual) => (atual.includes(id) ? atual.filter((x) => x !== id) : [...atual, id]))
  }

  function sairModoSelecao() {
    setModoSelecao(false)
    setSelecionados([])
  }

  async function aplicarStatusEmLote(novoStatus) {
    await atualizarStatusEmLote(selecionados, novoStatus)
    sairModoSelecao()
  }

  async function excluirSelecionados() {
    if (!(await confirmar(`Remover ${selecionados.length} item(ns) da lista?`))) return
    await excluirDoCarrinhoEmLote(selecionados)
    sairModoSelecao()
  }

  // Só entram no PDF os itens com status "Aguardando Gleison" — o resto já
  // foi comprado, recebido ou tratado de outra forma, então não faz sentido
  // pedir de novo. Respeita os filtros já aplicados na tela (área, só
  // urgentes, busca).
  const itensParaExportar = itensExibidos.filter((c) => c.status === STATUS.AGUARDANDO_GLEISON)

  function exportarPDF() {
    const doc = new jsPDF()
    const dataHoje = new Date().toLocaleDateString('pt-BR')
    const nomeFornecedor = rotuloFornecedor(selecionado)

    // A data do cabeçalho é sempre a de criação do PDF (o dia em que o
    // Exportar PDF foi clicado), não a data em que os itens foram pedidos.

    doc.setFont('helvetica', 'bold')
    doc.setFontSize(16)
    // Status não entra nos sufixos: o PDF já só traz "Aguardando Gleison"
    // (ver itensParaExportar), então repetir isso no título é redundante.
    const sufixos = [filtrandoPorArea ? textoAreasFiltro : null, soUrgentes ? 'só urgentes' : null].filter(Boolean)
    doc.text(
      `Pedido de compra — ${nomeFornecedor}${sufixos.length ? ` (${sufixos.join(', ')})` : ''}`,
      14,
      18
    )

    doc.setFont('helvetica', 'bold')
    doc.setFontSize(12)
    doc.text(`Filial: ${filial}`, 14, 27)
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(10)
    const cnpjFilial = CNPJ_POR_FILIAL[filial]
    if (cnpjFilial) doc.text(`CNPJ: ${cnpjFilial}`, 14, 33)
    doc.text(`Data do pedido: ${dataHoje}`, 14, cnpjFilial ? 39 : 33)

    // Ordem alfabética por nome do item, igual ao critério usado no Catálogo,
    // pra facilitar achar o produto na hora da compra.
    const itensOrdenados = [...itensParaExportar].sort((a, b) =>
      normalizarNome(a.item?.nome).localeCompare(normalizarNome(b.item?.nome), 'pt-BR')
    )

    // Pedido só de esmaltes de exposição: o estoque não faz sentido pra esses
    // itens (sempre 0), então saem só Item e Qtd Cmp. O consumo médio não sai
    // no PDF em nenhum caso.
    const soEsmaltes = itensOrdenados.length > 0 && itensOrdenados.every((c) => c.item?.categoria === CATEGORIA_ESMALTES)

    // Quantidades saem como texto, do jeito que aparecem no app: número +
    // unidade (ex.: "3 un.", "2 cx.", "1,5 pcte."). Sem valor preenchido,
    // mostra 0 na unidade do pedido em vez de deixar em branco.
    const textoQtd = (valor, unidade) =>
      `${String(valor ?? 0).replace('.', ',')} ${normalizarUnidade(unidade).toLowerCase()}.`

    const colItem = 14
    const colEstoque = 160
    const colQtd = 196
    const larguraItem = soEsmaltes ? 150 : 118

    let y = cnpjFilial ? 52 : 46
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(11)
    doc.text('Item', colItem, y)
    if (!soEsmaltes) {
      doc.text('Estoque', colEstoque, y, { align: 'right' })
    }
    doc.text('Qtd Cmp', colQtd, y, { align: 'right' })
    y += 4
    doc.setDrawColor(200)
    doc.line(14, y, 196, y)
    y += 6

    doc.setFont('helvetica', 'normal')
    doc.setFontSize(10)
    itensOrdenados.forEach((c) => {
      // Nome longo quebra em mais de uma linha — calcula antes pra empurrar
      // o y na medida certa (senão a linha separadora cortaria o texto).
      const linhasNome = doc.splitTextToSize(c.item?.nome ?? '—', larguraItem)
      const alturaLinha = 5
      const alturaItem = linhasNome.length * alturaLinha
      if (y + alturaItem > 280) {
        doc.addPage()
        y = 20
      }
      doc.text(linhasNome, colItem, y)
      if (!soEsmaltes) {
        doc.text(textoQtd(c.quantidadeAtual, c.unidadeAtual), colEstoque, y, { align: 'right' })
      }
      doc.text(textoQtd(c.quantidadeNecessaria, c.unidadeNecessaria), colQtd, y, { align: 'right' })
      y += alturaItem + 1
      doc.setDrawColor(225)
      doc.line(14, y, 196, y)
      y += 6
    })

    doc.save(`pedido-${nomeFornecedor}-${filial}-${dataHoje.replace(/\//g, '-')}.pdf`)
  }

  return (
    <>
      <div className="supplier-chips fornecedor-chips">
        {fornecedoresExibidos.map((f) => {
          const temPendente =
            f === TODOS
              ? todosItens.length > 0
              : todosItens.some((c) => (c.fornecedorUsado || '') === (f || ''))
          return (
            <button
              key={f === TODOS ? '__todos__' : f || '__sem_fornecedor__'}
              className={`chip ${f === selecionado ? 'active' : ''}`}
              title={rotuloFornecedor(f)}
              onClick={() => {
                setSelecionado(f)
                setBusca('')
                setAreasSelecionadas([])
                setStatusSelecionados([])
                setDataFiltro('Todas')
                setSoUrgentes(false)
              }}
            >
              {rotuloFornecedor(f)}
              {temPendente && <span className="chip-dot" aria-label="Tem produto pendente de compra" />}
            </button>
          )
        })}
      </div>

      {selecionado !== null && selecionado !== TODOS && (
        <button
          className="btn btn-primary btn-exportar-pdf"
          onClick={exportarPDF}
          disabled={itensParaExportar.length === 0}
          title={`Exporta só os itens com status Aguardando Gleison para ${rotuloFornecedor(selecionado)}`}
        >
          <span aria-hidden="true">📄</span> Exportar PDF
        </button>
      )}

      {selecionado !== null && (itens.length > 0 || temFiltrosDisponiveis) && (
        <div className="busca-filtros-row">
          {itens.length > 0 && (
            <div className="search-box">
              <input
                placeholder={`Buscar produto em ${rotuloFornecedor(selecionado)}...`}
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
              />
            </div>
          )}
          {temFiltrosDisponiveis && (
            <button
              type="button"
              className="filtros-btn"
              onClick={() => setFiltrosAbertos(true)}
              aria-haspopup="dialog"
            >
              <span aria-hidden="true">🎚</span> Filtros
              {filtrosAtivosCount > 0 && (
                <span className="filtros-btn-badge">{filtrosAtivosCount}</span>
              )}
            </button>
          )}
          {isAdmin && itensExibidos.length > 0 && !modoSelecao && (
            <AcoesMenu onSelecionarVarios={() => setModoSelecao(true)} />
          )}
        </div>
      )}

      <FiltrosFornecedorSheet
        aberto={filtrosAbertos}
        onFechar={() => setFiltrosAbertos(false)}
        fornecedorNome={rotuloFornecedor(selecionado)}
        areasDisponiveis={areasDisponiveis}
        areasFiltro={areasFiltro}
        toggleArea={toggleArea}
        onLimparAreas={() => setAreasSelecionadas([])}
        statusDisponiveis={statusDisponiveis}
        statusFiltro={statusFiltro}
        toggleStatus={toggleStatus}
        onLimparStatus={() => setStatusSelecionados([])}
        datasDisponiveis={datasDisponiveis}
        dataFiltro={dataFiltro}
        setDataFiltro={setDataFiltro}
        qtdUrgentes={qtdUrgentes}
        soUrgentes={soUrgentes}
        setSoUrgentes={setSoUrgentes}
        onLimparTudo={limparTodosFiltros}
      />

      {modoSelecao && (
        <div className="select-all-row">
          {/* Um único checkbox faz o papel de "selecionar todos" e "limpar"
              ao mesmo tempo (marca tudo / desmarca tudo) — igual ao checkbox
              de cada item, então fica óbvio pelo celular o que ele faz.
              "Cancelar" (sair do modo de seleção) fica isolado do outro lado,
              longe do checkbox, pra não ser confundido com ele. */}
          <label className="select-all-check">
            <input
              type="checkbox"
              checked={itensExibidos.length > 0 && selecionados.length === itensExibidos.length}
              ref={(el) => {
                if (el) el.indeterminate = selecionados.length > 0 && selecionados.length < itensExibidos.length
              }}
              onChange={(e) =>
                setSelecionados(e.target.checked ? itensExibidos.map((i) => i.id) : [])
              }
            />
            {selecionados.length === 0
              ? 'Selecionar todos'
              : `${selecionados.length} de ${itensExibidos.length} selecionado${
                  itensExibidos.length === 1 ? '' : 's'
                }`}
          </label>
          <button type="button" className="btn-link" onClick={sairModoSelecao}>
            Cancelar
          </button>
        </div>
      )}

      {itensExibidos.length === 0 && (
        <div className="empty-state">
          <h3>
            {buscaAtiva
              ? `Nenhum produto encontrado para "${busca}" em ${rotuloFornecedor(selecionado, 'esse fornecedor')}`
              : filtrandoPorArea
              ? `Nada pendente em ${textoAreasFiltro} com ${rotuloFornecedor(selecionado, 'esse fornecedor')}`
              : filtrandoPorStatus
              ? `Nada com status ${textoStatusFiltro} em ${rotuloFornecedor(selecionado, 'esse fornecedor')}`
              : dataFiltro !== 'Todas'
              ? `Nada pedido em ${new Date(`${dataFiltro}T00:00:00`).toLocaleDateString('pt-BR')} com ${rotuloFornecedor(selecionado, 'esse fornecedor')}`
              : soUrgentes
              ? `Nada urgente pendente com ${rotuloFornecedor(selecionado, 'esse fornecedor')}`
              : `Nada pendente com ${rotuloFornecedor(selecionado, 'esse fornecedor')}`}
          </h3>
        </div>
      )}

      {grupos.map((grupo) => {
        const pedidoPorVariosSetores = grupo.length > 1
        return (
          <div
            key={grupo[0].id}
            className={pedidoPorVariosSetores ? 'item-group' : undefined}
          >
            {pedidoPorVariosSetores && (
              <p className="item-group-heading">
                {grupo[0].item?.nome} — pedido por {grupo.length} setores diferentes
              </p>
            )}
            {grupo.map((c) => (
              <ItemRow
                key={c.id}
                carrinhoItem={c}
                selecionavel={modoSelecao}
                selecionado={selecionados.includes(c.id)}
                onToggleSelecionado={toggleSelecionado}
                onExcluir={excluirDoCarrinho}
                compacto
              />
            ))}
          </div>
        )
      })}

      {modoSelecao && selecionados.length > 0 && (
        <SelectionBar
          count={selecionados.length}
          onAplicarStatus={aplicarStatusEmLote}
          onExcluir={excluirSelecionados}
          onLimpar={() => setSelecionados([])}
        />
      )}
    </>
  )
}
