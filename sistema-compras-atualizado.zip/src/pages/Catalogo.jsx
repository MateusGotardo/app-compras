import { useMemo, useState } from 'react'
import { useApp } from '../context/AppContext'
import { useConfirm } from '../context/ConfirmContext'
import { CATEGORIAS, CATEGORIA_ESMALTES, normalizarUnidade, opcoesUnidade, agruparItensEsmaltePorMarca } from '../data/mockData'
import FornecedorAutocomplete from '../components/FornecedorAutocomplete'
import EsmalteExposicaoModal from '../components/EsmalteExposicaoModal'
import EsmaltesAdminModal from '../components/EsmaltesAdminModal'
import StatusBadge from '../components/StatusBadge'

const ITEM_VAZIO = { nome: '', categoria: '', fornecedorPadrao: '', foraDeLinha: false }
const SOLICITACAO_VAZIA = {
  quantidadeNecessaria: '',
  quantidadeAtual: '',
  unidadeAtual: 'UN',
  observacoes: '',
}
const ESTOQUE_VAZIO = { quantidadeAtual: '', unidadeAtual: 'UN' }

// Remove acentuação e caixa para a busca não ser sensível a maiúsculas nem
// a acentos (ex.: "agua" encontra "Água", "CAFE" encontra "café").
function normalizar(texto) {
  return texto
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
}

export default function Catalogo() {
  const {
    catalogoDaFilial,
    carrinho,
    filial,
    adicionarAoCarrinho,
    atualizarEstoqueConvidado,
    cadastrarItem,
    atualizarItemCatalogo,
    excluirItemCatalogo,
    isAdmin,
    categoriasPermitidas,
    esmaltesDaFilial,
  } = useApp()
  const confirmar = useConfirm()
  const [busca, setBusca] = useState('')
  const [categoriaAtiva, setCategoriaAtiva] = useState(categoriasPermitidas[0])
  const [mostrarForm, setMostrarForm] = useState(false)
  const [novo, setNovo] = useState(ITEM_VAZIO)

  // Esmaltes de exposição: modal de lançamento (manicure e admin) e modal de
  // conferência da vitrine (só admin) — ver EsmalteExposicaoModal /
  // EsmaltesAdminModal. O admin lança pela filial que estiver selecionada.
  const [esmaltesFormAberto, setEsmaltesFormAberto] = useState(false)
  const [esmaltesAdminAberto, setEsmaltesAdminAberto] = useState(false)
  const podeLancarEsmaltes =
    isAdmin || categoriasPermitidas.includes('Manicures') || categoriasPermitidas.includes(CATEGORIA_ESMALTES)
  const listaEsmaltes = esmaltesDaFilial()

  // Login "só esmaltes": convidado cuja única categoria permitida é
  // "Esmaltes expositor" (nome cadastrado como "Esmaltes" ou "Esmaltes /
  // <nome da manicure>", ver derivarCategoriasDoNome). Vê a lista de todos
  // os esmaltes cadastrados, separada por marca, com a mesma busca e o mesmo
  // "+" / "✓" dos outros setores — a diferença é que, no pedido, ele informa
  // a quantidade em estoque E a quantidade a comprar (as duas obrigatórias).
  // Depois de enviado, ele só pode avisar o estoque de novo (pelo "✓"); a
  // quantidade a comprar fica com o admin. O botão "Cadastrar esmalte novo"
  // só cria o produto que ainda não existe na lista, sem gerar pedido.
  const somenteEsmaltes =
    !isAdmin && categoriasPermitidas.length === 1 && categoriasPermitidas[0] === CATEGORIA_ESMALTES

  const [editandoId, setEditandoId] = useState(null)
  const [edicao, setEdicao] = useState(ITEM_VAZIO)

  // Item que está com o formulário de solicitação aberto (prioridade e
  // observações são pedidas aqui, na hora do pedido — não fazem parte do
  // cadastro fixo do produto no catálogo).
  const [solicitandoId, setSolicitandoId] = useState(null)
  const [solicitacao, setSolicitacao] = useState(SOLICITACAO_VAZIA)

  // Item (do carrinho) com o formulário de "alerta de estoque" aberto —
  // opção do convidado pra avisar a quantidade atual de um produto que já
  // está na lista, sem precisar do admin. Prioridade é recalculada sozinha:
  // zerou o estoque, o item vira Urgente.
  const [atualizandoId, setAtualizandoId] = useState(null)
  const [estoqueForm, setEstoqueForm] = useState(ESTOQUE_VAZIO)

  const catalogoFilial = catalogoDaFilial()
  const buscaAtiva = busca.trim().length > 0

  // Lista do convidado "só esmaltes": todos os esmaltes cadastrados na
  // filial, por marca. A busca ignora acento/maiúscula e casa com o nome do
  // esmalte ou com a marca (ex.: "opi" mostra tudo da marca OPI).
  const esmaltesPorMarca = useMemo(() => {
    const grupos = agruparItensEsmaltePorMarca(catalogoFilial)
    if (!buscaAtiva) return grupos
    const alvo = normalizar(busca)
    return grupos
      .map(([m, lista]) => [m, lista.filter((e) => normalizar(e.nome).includes(alvo) || normalizar(m).includes(alvo))])
      .filter(([, lista]) => lista.length > 0)
  }, [catalogoFilial, busca, buscaAtiva])

  // Com busca preenchida, ignora a aba selecionada e procura em todas as
  // categorias ao mesmo tempo. Sem busca, mostra só a categoria da aba ativa.
  const itens = buscaAtiva
    ? catalogoFilial.filter((i) => normalizar(i.nome).includes(normalizar(busca)))
    : catalogoFilial.filter((i) => i.categoria === categoriaAtiva)

  const porCategoria = itens.reduce((acc, item) => {
    const cat = item.categoria || 'Sem categoria'
    acc[cat] = acc[cat] || []
    acc[cat].push(item)
    return acc
  }, {})
  // Produtos em ordem alfabética dentro de cada categoria.
  Object.values(porCategoria).forEach((lista) => lista.sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR')))
  // Segue a ordem fixa das categorias (não alfabética).
  const categorias = CATEGORIAS.filter((cat) => porCategoria[cat])

  function pedidoAtivo(itemId) {
    return carrinho.find(
      (c) => c.itemId === itemId && c.filial === filial && !['Recebido', 'Tem no Estoque'].includes(c.status)
    )
  }

  function iniciarSolicitacao(item) {
    setEditandoId(null)
    setAtualizandoId(null)
    setSolicitandoId(item.id)
    setSolicitacao(SOLICITACAO_VAZIA)
  }

  function cancelarSolicitacao() {
    setSolicitandoId(null)
    setSolicitacao(SOLICITACAO_VAZIA)
  }

  async function confirmarSolicitacao(e, itemId) {
    e.preventDefault()
    // Estoque atual é obrigatório pra qualquer pedido, de qualquer setor e
    // de qualquer perfil (0 vale; vazio não).
    if (String(solicitacao.quantidadeAtual).trim() === '') return
    await adicionarAoCarrinho(itemId, solicitacao.quantidadeNecessaria || 1, {
      quantidadeAtual: solicitacao.quantidadeAtual,
      unidadeAtual: solicitacao.unidadeAtual,
      observacoes: solicitacao.observacoes,
      comQuantidadeCompra: somenteEsmaltes,
    })
    cancelarSolicitacao()
  }

  function iniciarAtualizacaoEstoque(pedido) {
    setEditandoId(null)
    setSolicitandoId(null)
    setAtualizandoId(pedido.id)
    setEstoqueForm({
      quantidadeAtual: pedido.quantidadeAtual ?? '',
      unidadeAtual: normalizarUnidade(pedido.unidadeAtual),
    })
  }

  function cancelarAtualizacaoEstoque() {
    setAtualizandoId(null)
    setEstoqueForm(ESTOQUE_VAZIO)
  }

  async function confirmarAtualizacaoEstoque(e) {
    e.preventDefault()
    await atualizarEstoqueConvidado(atualizandoId, estoqueForm)
    cancelarAtualizacaoEstoque()
  }

  async function handleNovoItem(e) {
    e.preventDefault()
    if (!novo.nome || !novo.categoria) return
    const criado = await cadastrarItem({ ...novo })
    setNovo(ITEM_VAZIO)
    setMostrarForm(false)
    // Recém-cadastrado: já abre o pedido pra informar quantidade/prioridade/observações.
    iniciarSolicitacao(criado)
  }

  function iniciarEdicao(item) {
    setEditandoId(item.id)
    setEdicao({
      nome: item.nome,
      categoria: item.categoria,
      fornecedorPadrao: item.fornecedorPadrao || '',
      foraDeLinha: item.foraDeLinha || false,
    })
    setMostrarForm(false)
    cancelarSolicitacao()
    cancelarAtualizacaoEstoque()
  }

  function cancelarEdicao() {
    setEditandoId(null)
    setEdicao(ITEM_VAZIO)
  }

  async function salvarEdicao(e) {
    e.preventDefault()
    if (!edicao.nome || !edicao.categoria) return
    await atualizarItemCatalogo(editandoId, { ...edicao })
    cancelarEdicao()
  }

  async function handleExcluirItem(item) {
    const relacionados = carrinho.filter((c) => c.itemId === item.id)
    const aviso =
      relacionados.length > 0
        ? `"${item.nome}" tem ${relacionados.length} registro(s) na lista ativa ou histórico. Excluir do catálogo vai remover tudo isso também. Continuar?`
        : `Excluir "${item.nome}" do catálogo?`
    if (!(await confirmar(aviso))) return
    await excluirItemCatalogo(item.id)
  }

  // Linha de um produto do catálogo (com os formulários inline de editar,
  // pedir e avisar estoque). Usada tanto na lista por categoria quanto na
  // lista por marca do convidado "só esmaltes". `rotulo` troca só o nome
  // mostrado na linha (ex.: só "Vermelho Paixão", já que a marca aparece no
  // título do grupo); os formulários seguem mostrando o nome completo.
  function renderizarItem(item, rotulo = item.nome) {
    if (editandoId === item.id) {
      return (
        <form key={item.id} onSubmit={salvarEdicao} className="inline-edit-form">
          <div className="field">
            <label>Nome do item</label>
            <input
              value={edicao.nome}
              onChange={(e) => setEdicao({ ...edicao, nome: e.target.value })}
              required
            />
          </div>
          <div className="field">
            <label>Categoria</label>
            <select
              value={edicao.categoria}
              onChange={(e) => setEdicao({ ...edicao, categoria: e.target.value })}
              required
            >
              <option value="" disabled>
                Selecione uma categoria
              </option>
              {CATEGORIAS.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Fornecedor padrão (opcional)</label>
            <FornecedorAutocomplete
              placeholder="Deixe em branco se ainda não souber"
              value={edicao.fornecedorPadrao}
              onChange={(nome) => setEdicao({ ...edicao, fornecedorPadrao: nome })}
            />
          </div>
          <div className="field field--checkbox">
            <label>
              <input
                type="checkbox"
                checked={edicao.foraDeLinha}
                onChange={(e) => setEdicao({ ...edicao, foraDeLinha: e.target.checked })}
              />
              Fora de linha (não deixa pedir de novo)
            </label>
          </div>
          <div className="inline-edit-actions">
            <button className="btn btn-primary" type="submit">
              Salvar alterações
            </button>
            <button className="btn btn-secondary" type="button" onClick={cancelarEdicao}>
              Cancelar
            </button>
          </div>
        </form>
      )
    }

    if (solicitandoId === item.id) {
      return (
        <form
          key={item.id}
          onSubmit={(e) => confirmarSolicitacao(e, item.id)}
          className="inline-edit-form"
        >
          <p className="item-name" style={{ marginBottom: 4 }}>
            Adicionar "{item.nome}" ao pedido
          </p>
          {(isAdmin || somenteEsmaltes) && (
            <div className="field">
              <label>Quantidade a comprar</label>
              <input
                type="number"
                inputMode="decimal"
                min={isAdmin ? '0' : '1'}
                placeholder="—"
                required={!isAdmin}
                value={solicitacao.quantidadeNecessaria}
                onChange={(e) => setSolicitacao({ ...solicitacao, quantidadeNecessaria: e.target.value })}
              />
            </div>
          )}
          <div className="field">
            <label>
              {isAdmin ? 'Quantidade atual em estoque' : 'Quantidade que você tem agora'} (obrigatório)
            </label>
            <span className="qty-edit qty-edit--form">
              <input
                type="number"
                inputMode="decimal"
                min="0"
                placeholder="0"
                required
                value={solicitacao.quantidadeAtual}
                onChange={(e) => setSolicitacao({ ...solicitacao, quantidadeAtual: e.target.value })}
              />
              <select
                className="unidade-select"
                value={solicitacao.unidadeAtual}
                onChange={(e) => setSolicitacao({ ...solicitacao, unidadeAtual: e.target.value })}
              >
                {opcoesUnidade(solicitacao.unidadeAtual).map((u) => (
                  <option key={u.value} value={u.value}>
                    {u.label}
                  </option>
                ))}
              </select>
            </span>
          </div>
          <div className="field">
            <label>Observações (opcional)</label>
            <input
              value={solicitacao.observacoes}
              onChange={(e) => setSolicitacao({ ...solicitacao, observacoes: e.target.value })}
            />
          </div>
          <div className="inline-edit-actions">
            <button className="btn btn-primary" type="submit">
              Adicionar à lista
            </button>
            <button className="btn btn-secondary" type="button" onClick={cancelarSolicitacao}>
              Cancelar
            </button>
          </div>
        </form>
      )
    }

    const pedido = pedidoAtivo(item.id)

    if (pedido && atualizandoId === pedido.id) {
      return (
        <form key={item.id} onSubmit={confirmarAtualizacaoEstoque} className="inline-edit-form">
          <p className="item-name" style={{ marginBottom: 4 }}>
            Avisar estoque de "{item.nome}"
          </p>
          <div className="field">
            <label>Quantidade que você tem agora</label>
            <span className="qty-edit qty-edit--form">
              <input
                type="number"
                inputMode="decimal"
                min="0"
                placeholder="—"
                required
                value={estoqueForm.quantidadeAtual}
                onChange={(e) => setEstoqueForm({ ...estoqueForm, quantidadeAtual: e.target.value })}
                autoFocus
              />
              <select
                className="unidade-select"
                value={estoqueForm.unidadeAtual}
                onChange={(e) => setEstoqueForm({ ...estoqueForm, unidadeAtual: e.target.value })}
              >
                {opcoesUnidade(estoqueForm.unidadeAtual).map((u) => (
                  <option key={u.value} value={u.value}>
                    {u.label}
                  </option>
                ))}
              </select>
            </span>
          </div>
          <div className="inline-edit-actions">
            <button className="btn btn-primary" type="submit">
              Enviar aviso
            </button>
            <button className="btn btn-secondary" type="button" onClick={cancelarAtualizacaoEstoque}>
              Cancelar
            </button>
          </div>
        </form>
      )
    }

    const noCarrinho = !!pedido
    // Fora de linha só impede pedir DE NOVO — não mexe num pedido que já
    // esteja na lista ativa (ex.: foi marcado fora de linha depois de já
    // pedido). Vale tanto pro convidado quanto pro admin.
    const bloqueadoPorForaDeLinha = item.foraDeLinha && !noCarrinho
    return (
      <div className="catalog-row" key={item.id}>
        <div className="catalog-row-info">
          <p className="item-name">
            {rotulo}
            {item.foraDeLinha && <span className="item-fora-linha-tag">Fora de linha</span>}
          </p>
          {!somenteEsmaltes && <p className="item-meta">{item.fornecedorPadrao || 'Sem fornecedor'}</p>}
          {noCarrinho && !isAdmin && (
            <p className="item-meta">
              <StatusBadge carrinhoItem={pedido} />
            </p>
          )}
        </div>
        <div className="catalog-row-actions">
          {isAdmin && (
            <>
              <button className="icon-btn" title="Editar item" onClick={() => iniciarEdicao(item)}>
                ✎
              </button>
              <button
                className="icon-btn danger"
                title="Excluir item"
                onClick={() => handleExcluirItem(item)}
              >
                🗑
              </button>
            </>
          )}
          <button
            className={`add-btn ${noCarrinho ? 'in-cart' : ''}`}
            onClick={() => {
              if (bloqueadoPorForaDeLinha) return
              if (noCarrinho) {
                if (!isAdmin) iniciarAtualizacaoEstoque(pedido)
                return
              }
              iniciarSolicitacao(item)
            }}
            disabled={(noCarrinho && isAdmin) || bloqueadoPorForaDeLinha}
            title={
              bloqueadoPorForaDeLinha
                ? 'Produto fora de linha — não é possível pedir'
                : noCarrinho
                ? isAdmin
                  ? 'Já está na lista da semana'
                  : 'Avisar quantidade atual em estoque'
                : 'Adicionar ao pedido'
            }
          >
            {noCarrinho ? '✓' : '+'}
          </button>
        </div>
      </div>
    )
  }

  if (somenteEsmaltes) {
    return (
      <div className="content">
        <h1 className="page-title">Esmaltes de exposição — {filial}</h1>
        <p className="confirm-mensagem" style={{ marginBottom: 16 }}>
          Peça os esmaltes que já estão cadastrados pela lista abaixo. Se o esmalte ainda não existe, use o botão
          pra cadastrá-lo.
        </p>
        <button className="btn btn-primary" style={{ width: '100%', marginBottom: 16 }} onClick={() => setEsmaltesFormAberto(true)}>
          💅 Cadastrar esmalte novo
        </button>

        <div className="search-box">
          <input
            placeholder="Buscar esmalte por nome ou marca..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
          />
        </div>

        {esmaltesPorMarca.map(([marca, lista]) => (
          <div key={marca}>
            <h2 className="category-heading">{marca}</h2>
            {lista.map(({ item, nome }) => renderizarItem(item, nome))}
          </div>
        ))}

        {esmaltesPorMarca.length === 0 && (
          <div className="empty-state">
            <h3>{buscaAtiva ? 'Nada encontrado' : 'Nenhum esmalte cadastrado ainda'}</h3>
            {buscaAtiva && <p>Nenhum esmalte bate com "{busca}".</p>}
          </div>
        )}

        <EsmalteExposicaoModal aberto={esmaltesFormAberto} somenteCadastro onFechar={() => setEsmaltesFormAberto(false)} />
      </div>
    )
  }

  return (
    <div className="content">
      <h1 className="page-title">Catálogo — {filial}</h1>

      {isAdmin && (
        <button
          className="catalog-row"
          style={{
            width: '100%',
            textAlign: 'left',
            marginBottom: 10,
            cursor: 'pointer',
            font: 'inherit',
            color: 'inherit',
          }}
          onClick={() => setEsmaltesAdminAberto(true)}
        >
          <div className="catalog-row-info">
            <p className="item-name">💅 Lista de esmaltes de exposição</p>
            <p className="item-meta">
              {listaEsmaltes
                ? `${listaEsmaltes.itens?.length ?? 0} esmalte(s) · atualizado em ${listaEsmaltes.atualizadoEm?.split('-').reverse().join('/')}`
                : 'Ninguém enviou essa lista ainda'}
            </p>
          </div>
        </button>
      )}

      {podeLancarEsmaltes && (
        <button
          className="btn btn-secondary"
          style={{ marginBottom: 16, width: '100%' }}
          onClick={() => setEsmaltesFormAberto(true)}
        >
          💅 {isAdmin ? 'Lançar esmaltes de exposição' : 'Esmaltes de exposição'}
        </button>
      )}

      <div className="search-box">
        <input
          placeholder="Buscar item em todas as categorias..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
        />
      </div>

      {!buscaAtiva && (
        <div className="supplier-chips">
          {categoriasPermitidas.map((cat) => (
            <button
              key={cat}
              className={`chip ${cat === categoriaAtiva ? 'active' : ''}`}
              onClick={() => setCategoriaAtiva(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
      )}

      {isAdmin && (
        <button
          className="btn btn-secondary"
          style={{ marginBottom: 16, width: '100%' }}
          onClick={() => {
            cancelarEdicao()
            cancelarSolicitacao()
            setMostrarForm((v) => !v)
          }}
        >
          {mostrarForm ? 'Cancelar' : '+ Cadastrar item novo'}
        </button>
      )}

      {mostrarForm && (
        <form onSubmit={handleNovoItem} className="inline-edit-form">
          <div className="field">
            <label>Nome do item</label>
            <input value={novo.nome} onChange={(e) => setNovo({ ...novo, nome: e.target.value })} required />
          </div>
          <div className="field">
            <label>Categoria</label>
            <select
              value={novo.categoria}
              onChange={(e) => setNovo({ ...novo, categoria: e.target.value })}
              required
            >
              <option value="" disabled>
                Selecione uma categoria
              </option>
              {CATEGORIAS.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Fornecedor padrão (opcional)</label>
            <FornecedorAutocomplete
              placeholder="Deixe em branco se ainda não souber"
              value={novo.fornecedorPadrao}
              onChange={(nome) => setNovo({ ...novo, fornecedorPadrao: nome })}
            />
          </div>
          <button className="btn btn-primary" type="submit">
            Cadastrar item
          </button>
        </form>
      )}

      {buscaAtiva && itens.length > 0 && (
        <p className="item-meta" style={{ marginBottom: 12 }}>
          Resultado da busca em todas as categorias
        </p>
      )}

      {categorias.map((cat) => (
        <div key={cat}>
          {buscaAtiva && <h2 className="category-heading">{cat}</h2>}
          {porCategoria[cat].map((item) => renderizarItem(item))}
        </div>
      ))}

      {itens.length === 0 && (
        <div className="empty-state">
          <h3>{buscaAtiva ? 'Nada encontrado' : `Nada em ${categoriaAtiva}`}</h3>
          {!buscaAtiva && <p>Cadastre um item novo nesta categoria.</p>}
        </div>
      )}

      {podeLancarEsmaltes && (
        <EsmalteExposicaoModal aberto={esmaltesFormAberto} onFechar={() => setEsmaltesFormAberto(false)} />
      )}
      {isAdmin && (
        <EsmaltesAdminModal aberto={esmaltesAdminAberto} onFechar={() => setEsmaltesAdminAberto(false)} />
      )}
    </div>
  )
}
