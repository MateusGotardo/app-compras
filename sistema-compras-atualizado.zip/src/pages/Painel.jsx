import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import { STATUS, dataDaCompra, ehAlertaEstoqueCritico, normalizarUnidade, unidadesEquivalentes } from '../data/mockData'

// Status que contam como "compra feita": o pedido foi comprado (ainda a
// caminho) ou já chegou. "Tem no Estoque" e "Não tinha" não são compra.
const STATUS_COMPRA = [STATUS.COMPRADO, STATUS.RECEBIDO]

const NOMES_MES = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro',
]

function chaveMes(ano, mesZeroBase) {
  return `${ano}-${String(mesZeroBase + 1).padStart(2, '0')}`
}

function mesAtual() {
  const hoje = new Date()
  return chaveMes(hoje.getFullYear(), hoje.getMonth())
}

function deslocarMes(chave, delta) {
  const [ano, mes] = chave.split('-').map(Number)
  const d = new Date(ano, mes - 1 + delta, 1)
  return chaveMes(d.getFullYear(), d.getMonth())
}

function nomeDoMes(chave) {
  const [ano, mes] = chave.split('-').map(Number)
  return `${NOMES_MES[mes - 1]} de ${ano}`
}

function formatarNumero(n) {
  return String(Number(n.toFixed(2))).replace('.', ',')
}

// As quantidades vêm em unidades diferentes (un., cx., pcte...), então
// somar tudo num número só não faria sentido. Somamos separado por unidade.
function somarPorUnidade(compras) {
  const totais = {}
  compras.forEach((c) => {
    const qtd = Number(c.quantidadeNecessaria) || 0
    if (qtd <= 0) return
    const un = normalizarUnidade(c.unidadeNecessaria)
    totais[un] = (totais[un] || 0) + qtd
  })
  return Object.entries(totais)
    .sort((a, b) => b[1] - a[1])
    .map(([un, total]) => `${formatarNumero(total)} ${un.toLowerCase()}.`)
}

function agruparPor(compras, chaveDe) {
  const grupos = {}
  compras.forEach((c) => {
    const chave = chaveDe(c)
    grupos[chave] = grupos[chave] || []
    grupos[chave].push(c)
  })
  return Object.entries(grupos)
    .map(([nome, lista]) => ({ nome, itens: lista.length, quantidades: somarPorUnidade(lista) }))
    .sort((a, b) => b.itens - a.itens || a.nome.localeCompare(b.nome, 'pt-BR'))
}

function BlocoRanking({ titulo, linhas, vazio }) {
  const maior = linhas.length ? linhas[0].itens : 0
  return (
    <section className="painel-bloco">
      <h2 className="painel-bloco-titulo">{titulo}</h2>
      {linhas.length === 0 && <p className="item-meta">{vazio}</p>}
      {linhas.map((l) => (
        <div key={l.nome} className="painel-linha">
          <div className="painel-linha-topo">
            <span className="painel-linha-nome">{l.nome}</span>
            <span className="painel-linha-valor">
              {l.itens} {l.itens === 1 ? 'item' : 'itens'}
            </span>
          </div>
          <div className="painel-barra" aria-hidden="true">
            <div className="painel-barra-preenchimento" style={{ width: `${(l.itens / maior) * 100}%` }} />
          </div>
          {l.quantidades.length > 0 && <p className="painel-linha-qtds">{l.quantidades.join(' · ')}</p>}
        </div>
      ))}
    </section>
  )
}

export default function Painel() {
  const { listaAtiva, historico, filial } = useApp()
  const [mes, setMes] = useState(mesAtual())

  const ativos = listaAtiva()
  const todos = [...ativos, ...historico()]

  // ----- Pendências (foto de agora, não depende do mês escolhido) -----
  const contar = (status) => ativos.filter((c) => c.status === status).length
  // Cada pendência leva direto pra aba de Fornecedores, já filtrada pelo
  // status clicado (chip "Todos" + filtro de status). "Estoque crítico" não
  // é um status em si, então usa o filtro de urgência (?urgente=1) em vez de
  // ?status=.
  const pendencias = [
    {
      rotulo: 'Aguardando aprovação',
      valor: contar(STATUS.AGUARDANDO_GLEISON),
      to: `/fornecedor?status=${encodeURIComponent(STATUS.AGUARDANDO_GLEISON)}`,
    },
    {
      rotulo: 'Em andamento',
      valor: contar(STATUS.EM_ANDAMENTO),
      to: `/fornecedor?status=${encodeURIComponent(STATUS.EM_ANDAMENTO)}`,
    },
    {
      rotulo: 'Comprado, a receber',
      valor: contar(STATUS.COMPRADO),
      to: `/fornecedor?status=${encodeURIComponent(STATUS.COMPRADO)}`,
    },
    {
      rotulo: 'Não tinha',
      valor: contar(STATUS.NAO_TINHA),
      to: `/fornecedor?status=${encodeURIComponent(STATUS.NAO_TINHA)}`,
    },
    {
      rotulo: 'Estoque crítico',
      valor: ativos.filter(ehAlertaEstoqueCritico).length,
      alerta: true,
      to: '/fornecedor?urgente=1',
    },
  ]

  // ----- Compras do mês escolhido -----
  const compras = todos.filter((c) => STATUS_COMPRA.includes(c.status) && dataDaCompra(c))
  const doMes = (chave) => compras.filter((c) => dataDaCompra(c).slice(0, 7) === chave)
  const comprasMes = doMes(mes)
  const comprasMesAnterior = doMes(deslocarMes(mes, -1))

  const porFornecedor = agruparPor(comprasMes, (c) => c.fornecedorUsado || 'Sem fornecedor')
  const porSetor = agruparPor(comprasMes, (c) => c.item?.categoria ?? 'Outros')

  // Total de unidades compradas no mês, já convertido pra uma contagem só —
  // usa a unidade fixa + fator de conversão cadastrados no produto (ver
  // unidadesEquivalentes). Substitui os dois campos antigos ("Itens
  // comprados" e "Quantidade comprada no mês" por unidade solta), que não
  // dava pra comparar entre si nem somar direito sem saber quanto cabe em
  // cada cx./pcte. de cada produto.
  const unidadesMes = comprasMes.reduce((soma, c) => soma + unidadesEquivalentes(c), 0)
  const unidadesMesAnterior = comprasMesAnterior.reduce((soma, c) => soma + unidadesEquivalentes(c), 0)

  const diferenca = unidadesMes - unidadesMesAnterior
  const nomeMesAnterior = NOMES_MES[Number(deslocarMes(mes, -1).split('-')[1]) - 1].toLowerCase()
  let comparacao
  if (comprasMesAnterior.length === 0) comparacao = `Sem compras em ${nomeMesAnterior}`
  else if (diferenca === 0) comparacao = `Igual a ${nomeMesAnterior}`
  else comparacao = `${formatarNumero(Math.abs(diferenca))} ${diferenca > 0 ? 'a mais' : 'a menos'} que em ${nomeMesAnterior}`

  const ehMesAtual = mes >= mesAtual()

  return (
    <div className="content">
      <div className="page-title-row">
        <h1 className="page-title">Painel — {filial}</h1>
      </div>

      <div className="painel-pendencias">
        {pendencias.map((p) => (
          <Link
            key={p.rotulo}
            to={p.to}
            className={`painel-pendencia ${p.alerta && p.valor > 0 ? 'painel-pendencia--alerta' : ''}`}
            aria-label={`Ver em Fornecedores: ${p.rotulo}`}
          >
            <strong>{p.valor}</strong>
            <span>{p.rotulo}</span>
          </Link>
        ))}
      </div>

      <div className="painel-mes">
        <button type="button" className="icon-btn" aria-label="Mês anterior" onClick={() => setMes(deslocarMes(mes, -1))}>
          ‹
        </button>
        <span className="painel-mes-nome">{nomeDoMes(mes)}</span>
        <button
          type="button"
          className="icon-btn"
          aria-label="Próximo mês"
          disabled={ehMesAtual}
          onClick={() => setMes(deslocarMes(mes, 1))}
        >
          ›
        </button>
      </div>

      <div className="painel-resumo">
        <div className="painel-card">
          <span className="painel-card-rotulo">Unidades compradas</span>
          <strong className="painel-card-numero">{formatarNumero(unidadesMes)}</strong>
          <span className="item-meta">{comparacao}</span>
        </div>
        <div className="painel-card">
          <span className="painel-card-rotulo">Fornecedores usados</span>
          <strong className="painel-card-numero">{porFornecedor.length}</strong>
          <span className="item-meta">no mês</span>
        </div>
      </div>

      <BlocoRanking titulo="Por fornecedor" linhas={porFornecedor} vazio="Nenhuma compra neste mês." />
      <BlocoRanking titulo="Por setor" linhas={porSetor} vazio="Nenhuma compra neste mês." />
    </div>
  )
}
