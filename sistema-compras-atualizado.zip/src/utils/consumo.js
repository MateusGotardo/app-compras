// Helpers do consumo médio semanal (campo digitado à mão pelo admin, e o
// valor aprendido automaticamente pelo AppContext).
//
// Regras: no máximo 1 casa decimal (consumo quase nunca é número inteiro —
// ex.: 2,5 pct por semana), aceita vírgula ou ponto na digitação, e sempre
// exibe com vírgula (pt-BR).

import { normalizarUnidade } from '../data/mockData'

export const CASAS_DECIMAIS_CONSUMO = 1

// Unidade em que o consumo é medido quando nada foi escolhido ainda. É
// também a unidade que o app assumia (rótulo "un.") antes de existir o
// seletor — então itens antigos continuam fazendo sentido.
export const UNIDADE_CONSUMO_PADRAO = 'UN'

export function unidadeDoConsumo(item) {
  return normalizarUnidade(item?.consumoMedioUnidade || UNIDADE_CONSUMO_PADRAO)
}

// Limpa o texto enquanto o usuário digita: só dígitos e uma vírgula, com no
// máximo 1 dígito depois dela. Ponto vira vírgula. Sem isso o campo aceitaria
// "2,55" ou "2,5,5" e só arredondaríamos depois de sair do campo.
export function sanitizarConsumoDigitado(texto) {
  const limpo = String(texto ?? '')
    .replace(/\./g, ',')
    .replace(/[^\d,]/g, '')
  const posVirgula = limpo.indexOf(',')
  if (posVirgula === -1) return limpo
  const inteiro = limpo.slice(0, posVirgula) || '0'
  const decimais = limpo
    .slice(posVirgula + 1)
    .replace(/,/g, '')
    .slice(0, CASAS_DECIMAIS_CONSUMO)
  return `${inteiro},${decimais}`
}

// Texto digitado -> número pronto pra salvar (1 casa decimal, nunca
// negativo). Campo vazio vira null (= "sem consumo informado").
export function converterConsumo(texto) {
  const t = String(texto ?? '').trim().replace(',', '.')
  if (t === '') return null
  const n = Number(t)
  if (!Number.isFinite(n)) return 0
  return arredondarConsumo(Math.max(0, n))
}

export function arredondarConsumo(numero) {
  const fator = 10 ** CASAS_DECIMAIS_CONSUMO
  return Math.round(numero * fator) / fator
}

// Número salvo -> texto pra mostrar no campo/tela ("2,5", "3"). Vazio se
// não houver valor.
export function formatarConsumo(numero) {
  if (numero === null || numero === undefined || numero === '') return ''
  return Number(numero).toLocaleString('pt-BR', {
    minimumFractionDigits: 0,
    maximumFractionDigits: CASAS_DECIMAIS_CONSUMO,
    useGrouping: false,
  })
}
